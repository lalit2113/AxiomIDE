import Page from "components/page";
import alert from "dialogs/alert";
import prompt from "dialogs/prompt";
import actionStack from "lib/actionStack";

const STATE_KEY = "axiom_plugins_suite_v15";
const AI_CFG_KEY = "axiom_byok_ai_cfg";

function loadState() {
	try {
		return JSON.parse(localStorage.getItem(STATE_KEY) || "{}");
	} catch {
		return {};
	}
}

function saveState(state) {
	localStorage.setItem(STATE_KEY, JSON.stringify(state));
}

function getActiveText() {
	return editorManager?.editor?.getValue?.() || "";
}

function setActiveText(text) {
	if (editorManager?.editor?.setValue) {
		editorManager.editor.setValue(text);
		return true;
	}
	return false;
}

function insertAtCursor(text) {
	if (editorManager?.editor?.insert) {
		editorManager.editor.insert(text);
		return true;
	}
	return setActiveText(getActiveText() + text);
}

function basicBraceFormat(raw, indentSize = 2) {
	const unit = " ".repeat(indentSize);
	let depth = 0;
	return raw
		.split("\n")
		.map((line) => {
			const t = line.trim();
			if (!t) return "";
			if (/^[}\])]/.test(t)) depth = Math.max(0, depth - 1);
			const out = unit.repeat(depth) + t;
			if (/[{\[(]$/.test(t)) depth++;
			return out;
		})
		.join("\n");
}

function formatXml(xml) {
	let formatted = "";
	let indent = 0;
	const tokens = xml.replace(/>\s*</g, ">\n<").split("\n");
	for (const raw of tokens) {
		const line = raw.trim();
		if (!line) continue;
		if (/^<\//.test(line)) indent = Math.max(0, indent - 1);
		formatted += "  ".repeat(indent) + line + "\n";
		if (/^<[^!?/][^>]*[^/]>$/.test(line) && !line.includes("</")) indent++;
	}
	return formatted.trim();
}

const AXIOM_PLUGINS = [
	// === CORE & RUNTIME (Modeled on Acode's Top Official Plugins) ===
	{
		id: "axiom.runner.js",
		name: "Axiom Code Runner",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Runner",
		defaultInstalled: true,
		description: "Runs JavaScript in the active tab locally with captured console.log output, or launches Live Preview for HTML.",
		run: async () => {
			const fileName = editorManager?.activeFile?.filename || "";
			if (/\.html?$/i.test(fileName)) {
				acode.exec("run");
				return;
			}
			const code = getActiveText();
			if (!code.trim()) return alert("Axiom Code Runner", "Open a JavaScript or HTML file first.");
			const logs = [];
			const mockConsole = {
				log: (...args) => logs.push(args.map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a))).join(" ")),
				warn: (...args) => logs.push("[WARN] " + args.join(" ")),
				error: (...args) => logs.push("[ERR] " + args.join(" ")),
			};
			try {
				const fn = new Function("console", code);
				const ret = fn(mockConsole);
				if (ret !== undefined) logs.push("=> " + String(ret));
				alert("Axiom Runner Output", logs.length ? logs.join("\n") : "(Executed cleanly, no console output)");
			} catch (e) {
				alert("Runtime Error", e.message);
			}
		},
	},
	{
		id: "axiom.preview.live",
		name: "Axiom Live Preview",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Runner",
		defaultInstalled: true,
		description: "Launches the integrated local server preview for the active HTML, CSS, JS, or Markdown file.",
		run: async () => {
			acode.exec("run");
		},
	},
	{
		id: "axiom.terminal.quick",
		name: "AxiomX Terminal",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Runner",
		defaultInstalled: true,
		description: "Opens a new integrated Axiom Code terminal session in 1 tap.",
		run: async () => {
			acode.exec("new-terminal");
		},
	},
	{
		id: "axiom.ai.assistant",
		name: "Axiom AI Assistant (BYOK)",
		author: "Axiom Core",
		version: "1.5.0",
		category: "AI & Git",
		defaultInstalled: false,
		description: "Connect your own OpenAI-compatible HTTPS API key to explain, fix, or refactor the active file.",
		run: async () => {
			let cfg = {};
			try {
				cfg = JSON.parse(localStorage.getItem(AI_CFG_KEY) || "{}");
			} catch {}
			const baseUrl = await prompt("HTTPS OpenAI-Compatible Base URL", cfg.baseUrl || "https://api.openai.com/v1", "url");
			if (!baseUrl || !baseUrl.startsWith("https://")) return alert("HTTPS Required", "Enter a valid https:// base URL.");
			const model = await prompt("Model Name", cfg.model || "gpt-4o-mini", "text");
			if (!model) return;
			const apiKey = await prompt("API Key (stored locally)", cfg.apiKey || "", "password");
			if (!apiKey) return;
			localStorage.setItem(AI_CFG_KEY, JSON.stringify({ baseUrl: baseUrl.trim().replace(/\/$/, ""), model: model.trim(), apiKey: apiKey.trim() }));
			const ask = await prompt("Ask Axiom AI about active file", "Explain this code and suggest improvements", "text");
			if (!ask) return;
			try {
				const resp = await fetch(`${baseUrl.trim().replace(/\/$/, "")}/chat/completions`, {
					method: "POST",
					headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` },
					body: JSON.stringify({
						model: model.trim(),
						messages: [{ role: "user", content: `${ask}\n\nCode:\n${getActiveText().slice(0, 6000)}` }],
					}),
				});
				const data = await resp.json();
				const reply = data?.choices?.[0]?.message?.content || JSON.stringify(data).slice(0, 2000);
				alert("Axiom AI Response", reply);
			} catch (e) {
				alert("AI Request Failed", e.message);
			}
		},
	},
	{
		id: "axiom.github.explorer",
		name: "Axiom GitHub Explorer",
		author: "Axiom Core",
		version: "1.5.0",
		category: "AI & Git",
		defaultInstalled: false,
		description: "Browse live public GitHub repositories for any username via GitHub REST API.",
		run: async () => {
			const user = await prompt("GitHub Username", "", "text");
			if (!user) return;
			try {
				const resp = await fetch(`https://api.github.com/users/${encodeURIComponent(user.trim())}/repos?sort=updated&per_page=15`);
				if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
				const repos = await resp.json();
				const list = repos.map((r) => `• ${r.name} (${r.language || "N/A"}) ★${r.stargazers_count}`).join("\n");
				alert(`GitHub: @${user.trim()}`, list || "No public repositories found.");
			} catch (e) {
				alert("GitHub Error", e.message);
			}
		},
	},

	// === FORMATTERS & LINTERS ===
	{
		id: "axiom.prettier.code",
		name: "Axiom Prettier Formatter",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: true,
		description: "Auto-indents JS, TS, CSS, Kotlin, Java, C/C++, and Go code in the active tab.",
		run: async () => {
			const raw = getActiveText();
			if (!raw.trim()) return alert("Axiom Prettier", "Open a source file first.");
			setActiveText(basicBraceFormat(raw, 2));
			toast("Formatted with Axiom Prettier");
		},
	},
	{
		id: "axiom.linter.core",
		name: "Axiom JS & JSON Linter",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: true,
		description: "Checks active JS/JSON file for syntax errors, unbalanced brackets, and common issues.",
		run: async () => {
			const code = getActiveText();
			const fileName = editorManager?.activeFile?.filename || "";
			if (!code.trim()) return alert("Axiom Linter", "Active file is empty.");
			const issues = [];
			if (/\.json$/i.test(fileName)) {
				try {
					JSON.parse(code);
				} catch (e) {
					issues.push("JSON Error: " + e.message);
				}
			} else {
				try {
					new Function(code);
				} catch (e) {
					issues.push("JS Syntax: " + e.message);
				}
			}
			const opens = (code.match(/\{/g) || []).length;
			const closes = (code.match(/\}/g) || []).length;
			if (opens !== closes) issues.push(`Unbalanced braces: { = ${opens}, } = ${closes}`);
			const pOpens = (code.match(/\(/g) || []).length;
			const pCloses = (code.match(/\)/g) || []).length;
			if (pOpens !== pCloses) issues.push(`Unbalanced parentheses: ( = ${pOpens}, ) = ${pCloses}`);
			alert("Axiom Linter", issues.length ? issues.join("\n") : "0 issues found. Syntax looks clean!");
		},
	},
	{
		id: "axiom.python.fmt",
		name: "Axiom Python Formatter",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: false,
		description: "Normalizes tabs to 4 spaces, strips trailing whitespace, and cleans extra blank lines in Python.",
		run: async () => {
			const raw = getActiveText();
			if (!raw.trim()) return alert("Axiom Python Formatter", "Open a .py file first.");
			const cleaned = raw
				.replace(/\t/g, "    ")
				.split("\n")
				.map((l) => l.replace(/[ \t]+$/, ""))
				.join("\n")
				.replace(/\n{3,}/g, "\n\n");
			setActiveText(cleaned.trimEnd() + "\n");
			toast("Python formatted (PEP 8 spacing)");
		},
	},
	{
		id: "axiom.json.formatter",
		name: "Axiom JSON Pro",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: true,
		description: "Validates and pretty-prints JSON with 2-space indentation in the active tab.",
		run: async () => {
			const raw = getActiveText().trim();
			if (!raw) return alert("Axiom JSON", "Open a JSON file first.");
			try {
				setActiveText(JSON.stringify(JSON.parse(raw), null, 2));
				toast("Valid JSON formatted");
			} catch (e) {
				alert("JSON Syntax Error", e.message);
			}
		},
	},
	{
		id: "axiom.sql.formatter",
		name: "Axiom SQL Formatter",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: false,
		description: "Formats SQL SELECT, FROM, JOIN, WHERE, GROUP BY, and ORDER BY clauses.",
		run: async () => {
			const raw = getActiveText().trim();
			if (!raw) return alert("Axiom SQL", "Open a SQL file first.");
			const kws = ["SELECT", "FROM", "WHERE", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "JOIN", "GROUP BY", "ORDER BY", "HAVING", "LIMIT", "VALUES", "SET"];
			let out = raw.replace(/\s+/g, " ");
			for (const kw of kws) out = out.replace(new RegExp(`\\b${kw}\\b`, "gi"), `\n${kw}`);
			setActiveText(out.trim());
			toast("SQL formatted");
		},
	},
	{
		id: "axiom.xml.formatter",
		name: "Axiom XML & SVG Beautifier",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: false,
		description: "Cleanly indents XML, HTML, and SVG tag trees in the active editor.",
		run: async () => {
			const raw = getActiveText().trim();
			if (!raw) return alert("Axiom XML", "Open an XML or SVG file first.");
			setActiveText(formatXml(raw));
			toast("XML / SVG formatted");
		},
	},
	{
		id: "axiom.minifier.cssjs",
		name: "Axiom CSS / JS / JSON Minifier",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Formatter",
		defaultInstalled: false,
		description: "Strips comments and collapses whitespace to minify CSS, JS, or JSON in 1 tap.",
		run: async () => {
			const raw = getActiveText().trim();
			if (!raw) return alert("Axiom Minifier", "Active file is empty.");
			const minified = raw
				.replace(/\/\*[\s\S]*?\*\//g, "")
				.replace(/\s+/g, " ")
				.replace(/\s*([{};:,])\s*/g, "$1")
				.trim();
			setActiveText(minified);
			toast("Code minified");
		},
	},

	// === SNIPPETS & WEB KITS ===
	{
		id: "axiom.snippets.tailwind",
		name: "Axiom Tailwind CSS Kit",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Snippets",
		defaultInstalled: true,
		description: "Inserts a responsive Tailwind CSS CDN page scaffold with dark UI cards and flexbox grid.",
		run: async () => {
			insertAtCursor(`<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>Axiom Tailwind App</title>\n  <script src="https://cdn.tailwindcss.com"></script>\n</head>\n<body class="bg-slate-950 text-slate-100 min-h-screen p-6">\n  <main class="max-w-2xl mx-auto space-y-4">\n    <div class="p-6 rounded-xl bg-slate-900 border border-slate-800">\n      <h1 class="text-2xl font-bold text-sky-400">Axiom Tailwind Starter</h1>\n      <p class="text-slate-400 mt-2">Ready for live preview.</p>\n    </div>\n  </main>\n</body>\n</html>\n`);
			toast("Tailwind starter inserted");
		},
	},
	{
		id: "axiom.snippets.html5",
		name: "Axiom HTML5 Boilerplate",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Snippets",
		defaultInstalled: true,
		description: "Inserts a responsive HTML5 + viewport + CSS/JS starter scaffold.",
		run: async () => {
			insertAtCursor(`<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>Axiom App</title>\n  <link rel="stylesheet" href="style.css" />\n</head>\n<body>\n  <main id="app">\n    <h1>Axiom Code</h1>\n  </main>\n  <script src="app.js"></script>\n</body>\n</html>\n`);
			toast("HTML5 boilerplate inserted");
		},
	},
	{
		id: "axiom.snippets.lorem",
		name: "Axiom Lorem Ipsum Generator",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Snippets",
		defaultInstalled: false,
		description: "Generates clean placeholder paragraphs (1 to 5) directly at your editor cursor.",
		run: async () => {
			const n = Math.min(5, Math.max(1, Number(await prompt("How many paragraphs? (1-5)", "2", "number")) || 1));
			const para = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";
			insertAtCursor(Array.from({ length: n }, () => para).join("\n\n") + "\n");
			toast(`Inserted ${n} paragraph(s)`);
		},
	},
	{
		id: "axiom.snippets.react",
		name: "Axiom React / JSX Pack",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Snippets",
		defaultInstalled: false,
		description: "Inserts a modern React functional component with useState hook.",
		run: async () => {
			const name = (await prompt("Component Name", "App", "text")) || "App";
			insertAtCursor(`import React, { useState } from "react";\n\nexport default function ${name}() {\n  const [count, setCount] = useState(0);\n  return (\n    <section>\n      <h1>${name}</h1>\n      <button onClick={() => setCount((c) => c + 1)}>Count: {count}</button>\n    </section>\n  );\n}\n`);
			toast(`Inserted ${name} component`);
		},
	},
	{
		id: "axiom.snippets.python",
		name: "Axiom Python Starter Pack",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Snippets",
		defaultInstalled: false,
		description: "Inserts a clean Python 3 typed main entry point.",
		run: async () => {
			insertAtCursor(`def main() -> None:\n    print("Axiom Code Python Ready")\n\nif __name__ == "__main__":\n    main()\n`);
			toast("Python starter inserted");
		},
	},
	{
		id: "axiom.snippets.kotlin",
		name: "Axiom Kotlin & Java Pack",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Snippets",
		defaultInstalled: false,
		description: "Inserts a Kotlin data class + main() starter.",
		run: async () => {
			insertAtCursor(`data class Item(val id: Int, val name: String)\n\nfun main() {\n    val item = Item(1, "Axiom Code")\n    println(item)\n}\n`);
			toast("Kotlin starter inserted");
		},
	},

	// === DEV TOOLS ===
	{
		id: "axiom.tools.rest",
		name: "Axiom REST API Client",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Dev Tools",
		defaultInstalled: true,
		description: "Sends real HTTPS GET requests and displays status and JSON response.",
		run: async () => {
			const url = await prompt("HTTPS GET URL", "https://api.github.com", "url");
			if (!url) return;
			if (!url.startsWith("https://")) return alert("HTTPS Required", "Enter a valid https:// URL.");
			try {
				const resp = await fetch(url);
				const text = (await resp.text()).slice(0, 3000);
				alert(`HTTP ${resp.status} ${resp.statusText}`, text);
			} catch (e) {
				alert("Request Failed", e.message);
			}
		},
	},
	{
		id: "axiom.tools.regex",
		name: "Axiom Regex Tester",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Dev Tools",
		defaultInstalled: false,
		description: "Tests a regular expression against the active editor file and reports all matches.",
		run: async () => {
			const pattern = await prompt("Regex Pattern", "", "text");
			if (!pattern) return;
			try {
				const re = new RegExp(pattern, "gm");
				const matches = [...getActiveText().matchAll(re)];
				if (!matches.length) return alert("Regex Result", "No matches in active file.");
				const preview = matches.slice(0, 20).map((m, i) => `#${i + 1} @${m.index}: ${m[0]}`).join("\n");
				alert(`${matches.length} Match(es)`, preview);
			} catch (e) {
				alert("Invalid Regex", e.message);
			}
		},
	},
	{
		id: "axiom.tools.jwt",
		name: "Axiom JWT Decoder",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Dev Tools",
		defaultInstalled: false,
		description: "Decodes JWT header and payload JSON locally with zero external requests.",
		run: async () => {
			const token = await prompt("Paste JWT Token", "", "text");
			if (!token) return;
			try {
				const parts = token.trim().split(".");
				if (parts.length < 2) throw new Error("Invalid JWT structure");
				const dec = (s) => JSON.stringify(JSON.parse(atob(s.replace(/-/g, "+").replace(/_/g, "/"))), null, 2);
				alert("Decoded JWT", `HEADER:\n${dec(parts[0])}\n\nPAYLOAD:\n${dec(parts[1])}`);
			} catch (e) {
				alert("JWT Error", e.message);
			}
		},
	},
	{
		id: "axiom.tools.base64",
		name: "Axiom Base64 & URL Codec",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Dev Tools",
		defaultInstalled: false,
		description: "Encodes and decodes Base64 and URL strings locally.",
		run: async () => {
			const input = await prompt("Input Text", "", "text");
			if (!input) return;
			let b64Dec = "(not Base64)";
			try {
				b64Dec = atob(input.trim());
			} catch {}
			alert("Codec Output", `Base64 Enc:\n${btoa(unescape(encodeURIComponent(input)))}\n\nBase64 Dec:\n${b64Dec}\n\nURL Enc:\n${encodeURIComponent(input)}`);
		},
	},
	{
		id: "axiom.tools.hashuuid",
		name: "Axiom Hash & UUID",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Dev Tools",
		defaultInstalled: false,
		description: "Generates a cryptographic UUID v4 (inserts at cursor) and SHA-256 hash of active file.",
		run: async () => {
			const uuid =
				typeof crypto?.randomUUID === "function"
					? crypto.randomUUID()
					: "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
							const r = (Math.random() * 16) | 0;
							return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
						});
			let sha = "Unavailable";
			try {
				const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(getActiveText()));
				sha = [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
			} catch {}
			insertAtCursor(uuid);
			alert("UUID Inserted & File SHA-256", `UUID v4:\n${uuid}\n\nActive File SHA-256:\n${sha}`);
		},
	},
	{
		id: "axiom.tools.color",
		name: "Axiom Color Converter",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Dev Tools",
		defaultInstalled: false,
		description: "Converts HEX color to RGB and inserts it directly into your CSS/code.",
		run: async () => {
			const hex = (await prompt("Enter HEX Color", "#38BDF8", "text"))?.trim();
			if (!hex) return;
			const clean = hex.replace("#", "");
			if (!/^[0-9a-fA-F]{6}$/.test(clean)) return alert("Invalid HEX", "Use 6-digit HEX like #38BDF8");
			const rgb = `rgb(${parseInt(clean.slice(0, 2), 16)}, ${parseInt(clean.slice(2, 4), 16)}, ${parseInt(clean.slice(4, 6), 16)})`;
			insertAtCursor(rgb);
			alert("Color Converted & Inserted", `HEX: #${clean.toUpperCase()}\nRGB: ${rgb}`);
		},
	},

	// === PRODUCTIVITY ===
	{
		id: "axiom.prod.comments",
		name: "Axiom Better Comments Scanner",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Productivity",
		defaultInstalled: true,
		description: "Scans active file for TODO, FIXME, BUG, NOTE, and !/? comment tags with exact line numbers.",
		run: async () => {
			const lines = getActiveText().split("\n");
			const hits = [];
			lines.forEach((l, idx) => {
				if (/\b(TODO|FIXME|BUG|HACK|NOTE)\b/i.test(l) || /\/\/\s*[!?*]/.test(l)) {
					hits.push(`L${idx + 1}: ${l.trim()}`);
				}
			});
			alert(
				`Found ${hits.length} Highlighted Comment(s)`,
				hits.length ? hits.slice(0, 30).join("\n") : "No TODO / FIXME / NOTE comments in this file.",
			);
		},
	},
	{
		id: "axiom.prod.case",
		name: "Axiom Case Converter",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Productivity",
		defaultInstalled: false,
		description: "Converts any identifier between camelCase, snake_case, kebab-case, and PascalCase.",
		run: async () => {
			const raw = await prompt("Enter text or identifier", "", "text");
			if (!raw) return;
			const words = raw.trim().replace(/([a-z])([A-Z])/g, "$1 $2").split(/[\s_-]+/).filter(Boolean).map((w) => w.toLowerCase());
			const camel = words.map((w, i) => (i === 0 ? w : w[0].toUpperCase() + w.slice(1))).join("");
			const pascal = words.map((w) => w[0].toUpperCase() + w.slice(1)).join("");
			const snake = words.join("_");
			const kebab = words.join("-");
			alert("Case Conversions", `camelCase:  ${camel}\nPascalCase: ${pascal}\nsnake_case: ${snake}\nkebab-case: ${kebab}`);
		},
	},
	{
		id: "axiom.prod.stats",
		name: "Axiom Code Stats",
		author: "Axiom Core",
		version: "1.5.0",
		category: "Productivity",
		defaultInstalled: false,
		description: "Analyzes lines, words, characters, and byte size of the active file.",
		run: async () => {
			const text = getActiveText();
			const lines = text ? text.split("\n").length : 0;
			const words = text.trim() ? text.trim().split(/\s+/).length : 0;
			const bytes = new Blob([text]).size;
			alert("Axiom Code Stats", `Lines: ${lines}\nWords: ${words}\nCharacters: ${text.length}\nSize: ${bytes} bytes`);
		},
	},
];

const CATEGORIES = ["All", "Installed", "Runner", "AI & Git", "Formatter", "Snippets", "Dev Tools", "Productivity"];

export default function PluginsInclude() {
	const $page = Page("Axiom Plugins");
	const state = loadState();
	let activeCategory = "All";
	let searchQuery = "";

	function isInstalled(ext) {
		return state[ext.id]?.installed ?? ext.defaultInstalled;
	}

	function isEnabled(ext) {
		return state[ext.id]?.enabled ?? true;
	}

	function setPluginState(ext, installed, enabled) {
		state[ext.id] = { installed, enabled };
		saveState(state);
		render();
	}

	function render() {
		const filtered = AXIOM_PLUGINS.filter((ext) => {
			const catMatch =
				activeCategory === "All" ||
				(activeCategory === "Installed" && isInstalled(ext)) ||
				ext.category === activeCategory;
			const q = searchQuery.trim().toLowerCase();
			const textMatch =
				!q ||
				ext.name.toLowerCase().includes(q) ||
				ext.description.toLowerCase().includes(q) ||
				ext.category.toLowerCase().includes(q);
			return catMatch && textMatch;
		});

		$page.body = (
			<main className="main scroll" style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "12px" }}>
				<input
					type="search"
					value={searchQuery}
					placeholder="Search 24 Axiom plugins..."
					style={{
						width: "100%",
						boxSizing: "border-box",
						padding: "10px 12px",
						borderRadius: "10px",
						border: "1px solid var(--border-color)",
						backgroundColor: "var(--secondary-color)",
						color: "var(--primary-text-color)",
						fontSize: "13.5px",
					}}
					oninput={(e) => {
						searchQuery = e.target.value;
						render();
					}}
				/>

				<div style={{ display: "flex", gap: "6px", overflowX: "auto", paddingBottom: "2px" }}>
					{CATEGORIES.map((cat) => {
						const active = cat === activeCategory;
						return (
							<button
								style={{
									padding: "6px 12px",
									borderRadius: "20px",
									border: "1px solid var(--border-color)",
									backgroundColor: active ? "var(--active-color)" : "var(--secondary-color)",
									color: active ? "#04131e" : "var(--primary-text-color)",
									fontSize: "12px",
									fontWeight: "600",
									whiteSpace: "nowrap",
								}}
								onclick={() => {
									activeCategory = cat;
									render();
								}}
							>
								{cat}
							</button>
						);
					})}
				</div>

				{filtered.map((ext) => {
					const installed = isInstalled(ext);
					const enabled = isEnabled(ext);
					return (
						<div
							style={{
								padding: "14px",
								borderRadius: "12px",
								backgroundColor: "var(--secondary-color)",
								border: "1px solid var(--border-color)",
								display: "flex",
								flexDirection: "column",
								gap: "8px",
							}}
						>
							<div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "8px" }}>
								<div>
									<div style={{ fontSize: "14.5px", fontWeight: "700", color: "var(--primary-text-color)" }}>
										{ext.name}
									</div>
									<div style={{ fontSize: "11.5px", color: "var(--active-color)", marginTop: "2px" }}>
										{ext.category} • v{ext.version} • {ext.author} • Free
									</div>
								</div>
								<button
									style={{
										padding: "6px 12px",
										borderRadius: "8px",
										border: "1px solid var(--border-color)",
										backgroundColor: installed ? "transparent" : "var(--active-color)",
										color: installed ? "var(--primary-text-color)" : "#04131e",
										fontSize: "12px",
										fontWeight: "600",
									}}
									onclick={() => setPluginState(ext, !installed, true)}
								>
									{installed ? "Uninstall" : "Install"}
								</button>
							</div>
							<div style={{ fontSize: "13px", color: "var(--secondary-text-color)", lineHeight: "1.45" }}>
								{ext.description}
							</div>
							{installed && (
								<div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
									<button
										style={{
											padding: "7px 14px",
											borderRadius: "8px",
											border: "none",
											backgroundColor: enabled ? "var(--active-color)" : "var(--border-color)",
											color: enabled ? "#04131e" : "var(--secondary-text-color)",
											fontSize: "12px",
											fontWeight: "600",
										}}
										onclick={() => {
											if (!enabled) return;
											$page.hide();
											ext.run();
										}}
									>
										Run
									</button>
									<button
										style={{
											padding: "7px 12px",
											borderRadius: "8px",
											border: "1px solid var(--border-color)",
											backgroundColor: "transparent",
											color: "var(--primary-text-color)",
											fontSize: "12px",
										}}
										onclick={() => setPluginState(ext, true, !enabled)}
									>
										{enabled ? "Disable" : "Enable"}
									</button>
								</div>
							)}
						</div>
					);
				})}
			</main>
		);
	}

	render();

	actionStack.push({
		id: "plugins",
		action: $page.hide,
	});

	$page.onhide = function () {
		actionStack.remove("plugins");
	};

	app.append($page);
}
