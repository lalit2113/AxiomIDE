import { getResolvedKeyBindings } from "cm/commandRegistry";
import logoSrc from "components/logo/logo.png?inline";
import EditorFile from "lib/editorFile";

export default function openWelcomeTab() {
	const existingFile = editorManager.files.find((f) => f.id === "welcome-tab");
	if (existingFile) {
		existingFile.makeActive();
		return;
	}

	const welcomeContent = createWelcomeContent();

	const welcomeFile = new EditorFile("Axiom Home", {
		id: "welcome-tab",
		render: true,
		type: "page",
		content: welcomeContent,
		tabIcon: "icon code",
		hideQuickTools: true,
	});

	welcomeFile.setCustomTitle(() => "Workspace");
}

function createWelcomeContent() {
	const bindings = getResolvedKeyBindings();
	const kb = (name) => {
		const binding = bindings[name];
		return binding?.key ? binding.key.split("|")[0].replace(/-/g, "+") : "";
	};

	return (
		<div id="welcome-tab" className="axiom-home scroll">
			<header className="axiom-hero axiom-anim-1">
				<div className="axiom-hero-top">
					<img className="axiom-logo" src={logoSrc} width="46" height="46" alt="Axiom Code" />
					<div className="axiom-hero-meta">
						<div className="axiom-status-pill">
							<span className="axiom-pulse-dot"></span>
							<span>Open-Source Mobile IDE</span>
						</div>
						<h1>Axiom Code</h1>
						<p className="axiom-tagline">Fast, ad-free coding workspace for Android</p>
					</div>
				</div>
			</header>

			<section className="axiom-section axiom-anim-2">
				<h2 className="axiom-section-title">WORKSPACE</h2>
				<div className="axiom-grid">
					<QuickCard
						icon="add"
						title={strings["new file"] || "New File"}
						subtitle={kb("newFile") || "Create blank file"}
						accent={true}
						onClick={() => acode.exec("new-file")}
					/>
					<QuickCard
						icon="folder_open"
						title={strings["open folder"] || "Open Folder"}
						subtitle={kb("openFolder") || "Browse project"}
						onClick={() => acode.exec("open-folder")}
					/>
					<QuickCard
						icon="document-text-outline"
						title={strings["open file"] || "Open File"}
						subtitle={kb("openFile") || "Pick local file"}
						onClick={() => acode.exec("open-file")}
					/>
					<QuickCard
						icon="terminal"
						title={strings.terminal || "Terminal"}
						subtitle={kb("openTerminal") || "Launch shell"}
						onClick={() => acode.exec("new-terminal")}
					/>
					<QuickCard
						icon="tune"
						title={strings["command palette"] || "Commands"}
						subtitle={kb("openCommandPalette") || "Quick actions"}
						onClick={() => acode.exec("command-palette")}
					/>
					<QuickCard
						icon="historyrestore"
						title={strings.recent || "Recent"}
						subtitle="Jump back in"
						onClick={() => acode.exec("recent")}
					/>
				</div>
			</section>

			<section className="axiom-section axiom-anim-3">
				<h2 className="axiom-section-title">CUSTOMIZE</h2>
				<div className="axiom-list">
					<CompactRow
						icon="extension"
						label="Axiom Extensions"
						onClick={() => acode.exec("open", "plugins")}
					/>
					<CompactRow
						icon="color_lenspalette"
						label={strings["change theme"] || "Themes & Appearance"}
						onClick={() => acode.exec("change-app-theme")}
					/>
					<CompactRow
						icon="settings"
						label={strings.settings || "IDE Settings"}
						onClick={() => acode.exec("open", "settings")}
					/>
					<CompactRow
						icon="info_outline"
						label={strings.about || "About Axiom Code"}
						onClick={() => acode.exec("open", "about")}
					/>
				</div>
			</section>
		</div>
	);
}

function QuickCard({ icon, title, subtitle, accent = false, onClick }) {
	return (
		<div className={`axiom-card ${accent ? "axiom-card-accent" : ""}`} onclick={onClick}>
			<span className={`icon ${icon} axiom-card-icon`}></span>
			<div className="axiom-card-title">{title}</div>
			<div className="axiom-card-sub">{subtitle}</div>
		</div>
	);
}

function CompactRow({ icon, label, onClick }) {
	return (
		<div className="axiom-row" onclick={onClick}>
			<span className={`icon ${icon}`}></span>
			<span className="axiom-row-label">{label}</span>
			<span className="icon keyboard_arrow_right axiom-row-chevron"></span>
		</div>
	);
}
