import Sidebar from "components/sidebar";
import alert from "dialogs/alert";
import prompt from "dialogs/prompt";
import EditorFile from "lib/editorFile";

const GH_TOKEN_KEY = "axiom_github_pat";
const GH_USER_KEY = "axiom_github_user";

let container = null;
let repos = [];
let selectedRepo = null;
let currentPath = "";
let repoItems = [];
let activeTab = "files"; // files | commits | issues | pulls | branches
let tabItems = [];
let searchQuery = "";
let statusMsg = "";
let isLoading = false;

export default [
	"github",
	"github",
	"GitHub",
	initApp,
	false,
	onSelected,
];

function getToken() {
	return localStorage.getItem(GH_TOKEN_KEY) || "";
}

function getUser() {
	return localStorage.getItem(GH_USER_KEY) || "";
}

async function ghFetch(endpoint, options = {}) {
	const token = getToken();
	const headers = {
		Accept: "application/vnd.github+json",
		...(options.headers || {}),
	};
	if (token) headers.Authorization = `Bearer ${token}`;
	const resp = await fetch(`https://api.github.com${endpoint}`, { ...options, headers });
	const text = await resp.text();
	let data = null;
	try {
		data = text ? JSON.parse(text) : null;
	} catch {
		data = text;
	}
	if (!resp.ok) {
		throw new Error(data?.message || `GitHub HTTP ${resp.status}`);
	}
	return data;
}

function onSelected() {
	if (!repos.length && getToken()) {
		syncAccountAndRepos();
	} else {
		render();
	}
}

function initApp($el) {
	container = $el;
	container.classList.add("axiom-github-sidebar");
	render();
}

async function connectToken() {
	const tok = await prompt("GitHub Personal Access Token (repo, read:user)", getToken(), "password");
	if (!tok || !tok.trim()) return;
	localStorage.setItem(GH_TOKEN_KEY, tok.trim());
	await syncAccountAndRepos();
}

function disconnect() {
	localStorage.removeItem(GH_TOKEN_KEY);
	localStorage.removeItem(GH_USER_KEY);
	repos = [];
	selectedRepo = null;
	repoItems = [];
	tabItems = [];
	statusMsg = "Disconnected from GitHub.";
	render();
}

async function syncAccountAndRepos() {
	isLoading = true;
	statusMsg = "Syncing with GitHub...";
	render();
	try {
		const me = await ghFetch("/user");
		localStorage.setItem(GH_USER_KEY, me.login || "");
		repos = await ghFetch("/user/repos?sort=updated&per_page=40");
		statusMsg = `Connected as @${me.login} (${repos.length} repos)`;
	} catch (e) {
		statusMsg = `Error: ${e.message}`;
	} finally {
		isLoading = false;
		render();
	}
}

async function createRepo() {
	if (!getToken()) return alert("Connect GitHub", "Connect your GitHub token first.");
	const name = await prompt("New Repository Name", "", "text");
	if (!name || !name.trim()) return;
	const desc = (await prompt("Description (optional)", "", "text")) || "";
	isLoading = true;
	render();
	try {
		const created = await ghFetch("/user/repos", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ name: name.trim(), description: desc.trim(), auto_init: true }),
		});
		toast(`Created ${created.full_name}`);
		await syncAccountAndRepos();
	} catch (e) {
		alert("Create Repo Failed", e.message);
		isLoading = false;
		render();
	}
}

async function openRepo(repo) {
	selectedRepo = repo;
	currentPath = "";
	activeTab = "files";
	await loadRepoContents("");
}

async function loadRepoContents(path) {
	if (!selectedRepo) return;
	isLoading = true;
	currentPath = path;
	render();
	try {
		const encoded = path ? `/${path.split("/").map(encodeURIComponent).join("/")}` : "";
		const data = await ghFetch(`/repos/${selectedRepo.full_name}/contents${encoded}`);
		repoItems = Array.isArray(data)
			? data.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === "dir" ? -1 : 1))
			: [];
	} catch (e) {
		statusMsg = `Error: ${e.message}`;
		repoItems = [];
	} finally {
		isLoading = false;
		render();
	}
}

async function openGitHubFile(item) {
	isLoading = true;
	render();
	try {
		const data = await ghFetch(`/repos/${selectedRepo.full_name}/contents/${item.path.split("/").map(encodeURIComponent).join("/")}`);
		const decoded = decodeURIComponent(escape(atob((data.content || "").replace(/\n/g, ""))));
		const file = new EditorFile(item.name, { text: decoded, render: true });
		file.__axiomGhMeta = { fullName: selectedRepo.full_name, path: item.path, sha: data.sha };
		Sidebar.hide();
		toast(`Opened ${item.name} from GitHub`);
	} catch (e) {
		alert("Open File Failed", e.message);
	} finally {
		isLoading = false;
		render();
	}
}

async function commitActiveFileToGitHub() {
	if (!getToken()) return alert("Connect GitHub", "Connect your GitHub token first.");
	const active = editorManager?.activeFile;
	const meta = active?.__axiomGhMeta;
	if (!meta) {
		return alert("Commit to GitHub", "Open a file from your GitHub repo in the sidebar first, edit it, then tap Commit Active File.");
	}
	const message = await prompt("Commit Message", `Update ${active.filename}`, "text");
	if (!message || !message.trim()) return;
	const contentText = editorManager?.editor?.getValue?.() || "";
	const b64 = btoa(unescape(encodeURIComponent(contentText)));
	try {
		const res = await ghFetch(`/repos/${meta.fullName}/contents/${meta.path.split("/").map(encodeURIComponent).join("/")}`, {
			method: "PUT",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ message: message.trim(), content: b64, sha: meta.sha }),
		});
		active.__axiomGhMeta.sha = res?.content?.sha || meta.sha;
		toast(`Committed & pushed ${active.filename}`);
	} catch (e) {
		alert("Commit Failed", e.message);
	}
}

async function switchRepoTab(tab) {
	if (!selectedRepo) return;
	activeTab = tab;
	if (tab === "files") return loadRepoContents(currentPath);
	isLoading = true;
	tabItems = [];
	render();
	try {
		if (tab === "commits") tabItems = await ghFetch(`/repos/${selectedRepo.full_name}/commits?per_page=20`);
		if (tab === "issues") tabItems = await ghFetch(`/repos/${selectedRepo.full_name}/issues?state=open&per_page=20`);
		if (tab === "pulls") tabItems = await ghFetch(`/repos/${selectedRepo.full_name}/pulls?state=open&per_page=20`);
		if (tab === "branches") tabItems = await ghFetch(`/repos/${selectedRepo.full_name}/branches?per_page=20`);
	} catch (e) {
		statusMsg = `Error: ${e.message}`;
	} finally {
		isLoading = false;
		render();
	}
}

async function createIssue() {
	if (!selectedRepo || !getToken()) return;
	const title = await prompt("Issue Title", "", "text");
	if (!title || !title.trim()) return;
	const body = (await prompt("Issue Description", "", "text")) || "";
	try {
		await ghFetch(`/repos/${selectedRepo.full_name}/issues`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ title: title.trim(), body: body.trim() }),
		});
		toast("Issue created");
		await switchRepoTab("issues");
	} catch (e) {
		alert("Create Issue Failed", e.message);
	}
}

function render() {
	if (!container) return;
	const token = getToken();
	const user = getUser();
	container.innerHTML = "";

	const btnStyle = (primary = false) => ({
		padding: "6px 10px",
		borderRadius: "7px",
		border: primary ? "none" : "1px solid var(--border-color)",
		backgroundColor: primary ? "var(--active-color)" : "var(--secondary-color)",
		color: primary ? "#04131e" : "var(--primary-text-color)",
		fontSize: "11.5px",
		fontWeight: "600",
	});

	container.append(
		<div style={{ padding: "10px", display: "flex", flexDirection: "column", gap: "8px", borderBottom: "1px solid var(--border-color)" }}>
			<div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
				<span style={{ fontWeight: "700", fontSize: "14px", color: "var(--primary-text-color)" }}>
					{selectedRepo ? selectedRepo.name : "GitHub"}
				</span>
				<div style={{ display: "flex", gap: "6px" }}>
					{selectedRepo ? (
						<button type="button" style={btnStyle(false)} onclick={() => { selectedRepo = null; render(); }}>
							Repos
						</button>
					) : (
						<button type="button" style={btnStyle(true)} onclick={connectToken}>
							{token ? "Token" : "Connect"}
						</button>
					)}
				</div>
			</div>

			{token && !selectedRepo && (
				<div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
					<button type="button" style={btnStyle(false)} onclick={syncAccountAndRepos}>Sync</button>
					<button type="button" style={btnStyle(false)} onclick={createRepo}>+ Repo</button>
					<button type="button" style={btnStyle(false)} onclick={commitActiveFileToGitHub}>Push File</button>
					<button type="button" style={btnStyle(false)} onclick={disconnect}>Logout</button>
				</div>
			)}

			{selectedRepo && (
				<div style={{ display: "flex", gap: "5px", flexWrap: "wrap" }}>
					{["files", "commits", "issues", "pulls", "branches"].map((t) => (
						<button type="button" style={btnStyle(activeTab === t)} onclick={() => switchRepoTab(t)}>
							{t[0].toUpperCase() + t.slice(1)}
						</button>
					))}
					<button type="button" style={btnStyle(true)} onclick={commitActiveFileToGitHub}>Push</button>
				</div>
			)}

			{!selectedRepo && token && (
				<input
					type="search"
					value={searchQuery}
					placeholder="Search repositories..."
					style={{
						width: "100%",
						boxSizing: "border-box",
						padding: "7px 10px",
						borderRadius: "8px",
						border: "1px solid var(--border-color)",
						backgroundColor: "var(--secondary-color)",
						color: "var(--primary-text-color)",
						fontSize: "12px",
					}}
					oninput={(e) => {
						searchQuery = e.target.value;
						render();
					}}
				/>
			)}

			{statusMsg && (
				<div style={{ fontSize: "11px", color: "var(--active-color)" }}>
					{isLoading ? "Loading..." : statusMsg}
				</div>
			)}
		</div>,
	);

	const body = (
		<div className="scroll" style={{ flex: "1", overflowY: "auto", padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
			{!token ? (
				<div style={{ padding: "12px", borderRadius: "10px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)", fontSize: "12.5px", color: "var(--secondary-text-color)", lineHeight: "1.5" }}>
					Connect a GitHub Personal Access Token (<code>repo</code>, <code>read:user</code>) to browse repositories, open files into the editor, commit & push changes, manage issues, and inspect commits, branches, and PRs.
				</div>
			) : !selectedRepo ? (
				repos
					.filter((r) => !searchQuery.trim() || r.full_name.toLowerCase().includes(searchQuery.trim().toLowerCase()))
					.map((repo) => (
						<div
							style={{ padding: "10px", borderRadius: "10px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)", cursor: "pointer" }}
							onclick={() => openRepo(repo)}
						>
							<div style={{ fontSize: "13px", fontWeight: "600", color: "var(--primary-text-color)" }}>{repo.name}</div>
							<div style={{ fontSize: "11px", color: "var(--active-color)", marginTop: "2px" }}>
								{repo.language || "Repo"} • ★ {repo.stargazers_count} • {repo.private ? "Private" : "Public"}
							</div>
						</div>
					))
			) : activeTab === "files" ? (
				<div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
					{currentPath && (
						<button
							type="button"
							style={btnStyle(false)}
							onclick={() => loadRepoContents(currentPath.split("/").slice(0, -1).join("/"))}
						>
							← Up Folder
						</button>
					)}
					{repoItems.map((item) => (
						<div
							style={{ padding: "9px 10px", borderRadius: "8px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)", cursor: "pointer", fontSize: "12.5px", color: "var(--primary-text-color)" }}
							onclick={() => (item.type === "dir" ? loadRepoContents(item.path) : openGitHubFile(item))}
						>
							{item.type === "dir" ? "📁 " : "📄 "}
							{item.name}
						</div>
					))}
				</div>
			) : activeTab === "commits" ? (
				tabItems.map((c) => (
					<div style={{ padding: "9px", borderRadius: "8px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)" }}>
						<div style={{ fontSize: "12.5px", fontWeight: "600", color: "var(--primary-text-color)" }}>
							{(c.commit?.message || "").split("\n")[0]}
						</div>
						<div style={{ fontSize: "11px", color: "var(--secondary-text-color)", marginTop: "2px" }}>
							{(c.sha || "").slice(0, 7)} • {c.commit?.author?.name || ""}
						</div>
					</div>
				))
			) : activeTab === "issues" ? (
				<div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
					<button type="button" style={btnStyle(true)} onclick={createIssue}>+ New Issue</button>
					{tabItems.map((iss) => (
						<div style={{ padding: "9px", borderRadius: "8px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)" }}>
							<div style={{ fontSize: "12.5px", fontWeight: "600", color: "var(--primary-text-color)" }}>
								#{iss.number} {iss.title}
							</div>
							<div style={{ fontSize: "11px", color: "var(--active-color)" }}>@{iss.user?.login}</div>
						</div>
					))}
				</div>
			) : activeTab === "pulls" ? (
				tabItems.map((pr) => (
					<div style={{ padding: "9px", borderRadius: "8px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)" }}>
						<div style={{ fontSize: "12.5px", fontWeight: "600", color: "var(--primary-text-color)" }}>
							#{pr.number} {pr.title}
						</div>
						<div style={{ fontSize: "11px", color: "var(--active-color)" }}>@{pr.user?.login} • {pr.state}</div>
					</div>
				))
			) : (
				tabItems.map((br) => (
					<div style={{ padding: "9px", borderRadius: "8px", backgroundColor: "var(--secondary-color)", border: "1px solid var(--border-color)", fontSize: "12.5px", color: "var(--primary-text-color)" }}>
						🌿 {br.name}
					</div>
				))
			)}
		</div>
	);
	container.append(body);
}
