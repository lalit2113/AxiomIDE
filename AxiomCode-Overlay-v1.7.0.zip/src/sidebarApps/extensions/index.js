import "./style.scss";
import Sidebar from "components/sidebar";
import openPluginsPage, { AXIOM_PLUGINS, loadState, saveState } from "pages/plugins/plugins";

let container = null;
let searchQuery = "";

export default [
	"extension",
	"extensions",
	"Axiom Plugins",
	initApp,
	false,
	onSelected,
];

function onSelected() {
	renderSidebarPlugins();
}

function initApp($el) {
	container = $el;
	container.classList.add("extensions");
	renderSidebarPlugins();
}

export async function openWithSearch(query = "") {
	searchQuery = query;
	Sidebar.show("extensions");
	renderSidebarPlugins();
}

function renderSidebarPlugins() {
	if (!container) return;
	const state = loadState();
	const isInstalled = (ext) => state[ext.id]?.installed ?? ext.defaultInstalled;
	const isEnabled = (ext) => state[ext.id]?.enabled ?? true;

	const q = searchQuery.trim().toLowerCase();
	const filtered = AXIOM_PLUGINS.filter(
		(ext) =>
			!q ||
			ext.name.toLowerCase().includes(q) ||
			ext.category.toLowerCase().includes(q) ||
			ext.description.toLowerCase().includes(q),
	);

	container.innerHTML = "";
	container.append(
		<div className="header" style={{ padding: "10px", display: "flex", flexDirection: "column", gap: "8px" }}>
			<div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
				<span style={{ fontWeight: "700", fontSize: "14px", color: "var(--primary-text-color)" }}>
					Axiom Plugins
				</span>
				<button
					type="button"
					style={{
						padding: "4px 10px",
						borderRadius: "6px",
						border: "1px solid var(--border-color)",
						backgroundColor: "var(--secondary-color)",
						color: "var(--active-color)",
						fontSize: "11.5px",
						fontWeight: "600",
					}}
					onclick={() => {
						Sidebar.hide();
						openPluginsPage();
					}}
				>
					Open All
				</button>
			</div>
			<input
				type="search"
				value={searchQuery}
				placeholder="Search Axiom plugins..."
				style={{
					width: "100%",
					boxSizing: "border-box",
					padding: "8px 10px",
					borderRadius: "8px",
					border: "1px solid var(--border-color)",
					backgroundColor: "var(--secondary-color)",
					color: "var(--primary-text-color)",
					fontSize: "12.5px",
				}}
				oninput={(e) => {
					searchQuery = e.target.value;
					renderSidebarPlugins();
				}}
			/>
		</div>,
		<div
			className="scroll"
			style={{
				flex: "1",
				overflowY: "auto",
				padding: "0 10px 16px",
				display: "flex",
				flexDirection: "column",
				gap: "8px",
			}}
		>
			{filtered.map((ext) => {
				const installed = isInstalled(ext);
				const enabled = isEnabled(ext);
				return (
					<div
						style={{
							padding: "10px",
							borderRadius: "10px",
							backgroundColor: "var(--secondary-color)",
							border: "1px solid var(--border-color)",
							display: "flex",
							flexDirection: "column",
							gap: "6px",
						}}
					>
						<div style={{ fontSize: "13px", fontWeight: "600", color: "var(--primary-text-color)" }}>
							{ext.name}
						</div>
						<div style={{ fontSize: "11px", color: "var(--active-color)" }}>
							{ext.category} • Free
						</div>
						<div style={{ display: "flex", gap: "6px" }}>
							{installed ? (
								<button
									type="button"
									style={{
										padding: "5px 10px",
										borderRadius: "6px",
										border: "none",
										backgroundColor: enabled ? "var(--active-color)" : "var(--border-color)",
										color: enabled ? "#04131e" : "var(--secondary-text-color)",
										fontSize: "11.5px",
										fontWeight: "600",
									}}
									onclick={() => {
										if (!enabled) return;
										Sidebar.hide();
										ext.run();
									}}
								>
									Run
								</button>
							) : (
								<button
									type="button"
									style={{
										padding: "5px 10px",
										borderRadius: "6px",
										border: "none",
										backgroundColor: "var(--active-color)",
										color: "#04131e",
										fontSize: "11.5px",
										fontWeight: "600",
									}}
									onclick={() => {
										state[ext.id] = { installed: true, enabled: true };
										saveState(state);
										renderSidebarPlugins();
									}}
								>
									Install
								</button>
							)}
						</div>
					</div>
				);
			})}
		</div>,
	);
}
