import Page from "components/page";
import actionStack from "lib/actionStack";

const RELEASES = [
	{
		version: "v1.4.0",
		title: "Full Axiom Plugins Marketplace (16 Built-In Plugins)",
		items: [
			"Added searchable, categorized Axiom Plugins marketplace (Formatters, Snippets, Dev Tools, Productivity) with Install/Uninstall & Enable/Disable.",
			"Added 16 real offline-first plugins: Axiom Prettier, JSON Pro, SQL Formatter, XML/SVG Beautifier, HTML5/React/Python/Kotlin Snippets, REST API Client, Regex Tester, JWT Decoder, Base64/URL Codec, Hash/UUID, Color Converter, TODO/FIXME Scanner, and Code Stats.",
		],
	},
	{
		version: "v1.3.0",
		title: "Custom Axiom Icons & Whitelabel Suite",
		items: [
			"Added 8 custom Axiom Code launcher icons (Sky, OLED, Emerald, Ember, Blueprint, Indigo, Midnight, Rose).",
			"Added offline Axiom Code Changelog.",
		],
	},
	{
		version: "v1.2.0",
		title: "Total Whitelabel & Update Cleanup",
		items: [
			"Disabled upstream update popups and external redirects.",
			"Removed all paywalls, ads, sponsors, and paid plugins.",
			"Whitelabeled all 32 language packs and About/Settings screens.",
		],
	},
];

export default function Changelog() {
	const $page = Page("Changelog");

	$page.body = (
		<main className="main scroll" style={{ padding: "16px", display: "flex", flexDirection: "column", gap: "12px" }}>
			{RELEASES.map((rel) => (
				<div
					style={{
						padding: "16px",
						borderRadius: "12px",
						backgroundColor: "var(--secondary-color)",
						border: "1px solid var(--border-color)",
					}}
				>
					<div style={{ fontSize: "12px", fontWeight: "700", color: "var(--active-color)" }}>
						{rel.version}
					</div>
					<div style={{ fontSize: "15px", fontWeight: "700", color: "var(--primary-text-color)", margin: "4px 0 8px 0" }}>
						{rel.title}
					</div>
					<ul style={{ margin: 0, paddingLeft: "18px", color: "var(--secondary-text-color)", fontSize: "13px", lineHeight: "1.6" }}>
						{rel.items.map((item) => (
							<li>{item}</li>
						))}
					</ul>
				</div>
			))}
		</main>
	);

	actionStack.push({
		id: "changelog",
		action: $page.hide,
	});

	$page.onhide = function () {
		actionStack.remove("changelog");
	};

	app.append($page);
}
