import logoSrc from "components/logo/logo.png?inline";
import EditorFile from "lib/editorFile";

export default function openWelcomeTab() {
	const existingFile = editorManager.files.find((f) => f.id === "welcome-tab");
	if (existingFile) {
		existingFile.makeActive();
		return;
	}

	const welcomeContent = createWelcomeContent();

	const welcomeFile = new EditorFile("Home", {
		id: "welcome-tab",
		render: true,
		type: "page",
		content: welcomeContent,
		tabIcon: "icon code",
		hideQuickTools: true,
	});

	welcomeFile.setCustomTitle(() => "Axiom Code");
}

function createWelcomeContent() {
	return (
		<div id="welcome-tab" className="axiom-home scroll">
			<div className="axiom-container">
				<header className="axiom-hero axiom-anim-1">
					<img className="axiom-logo" src={logoSrc} width="44" height="44" alt="Axiom Code" />
					<div className="axiom-hero-meta">
						<div className="axiom-status-pill">
							<span className="axiom-pulse-dot"></span>
							<span>Open-Source Mobile IDE</span>
						</div>
						<h1>Axiom Code</h1>
						<p className="axiom-tagline">Fast, ad-free coding workspace for Android</p>
					</div>
				</header>

				<section className="axiom-section axiom-anim-2">
					<h2 className="axiom-section-title">WORKSPACE</h2>
					<div className="axiom-grid">
						<QuickCard
							icon="add"
							title="New File"
							subtitle="Blank file"
							accent={true}
							onClick={() => acode.exec("new-file")}
						/>
						<QuickCard
							icon="folder_open"
							title="Open Folder"
							subtitle="Project folder"
							onClick={() => acode.exec("open-folder")}
						/>
						<QuickCard
							icon="document-text-outline"
							title="Open File"
							subtitle="Pick local file"
							onClick={() => acode.exec("open-file")}
						/>
						<QuickCard
							icon="terminal"
							title="Terminal"
							subtitle="Built-in shell"
							onClick={() => acode.exec("new-terminal")}
						/>
						<QuickCard
							icon="tune"
							title="Commands"
							subtitle="Quick palette"
							onClick={() => acode.exec("command-palette")}
						/>
						<QuickCard
							icon="historyrestore"
							title="Recent"
							subtitle="Jump back in"
							onClick={() => acode.exec("recent")}
						/>
					</div>
				</section>

				<section className="axiom-section axiom-anim-3">
					<h2 className="axiom-section-title">CUSTOMIZE</h2>
					<div className="axiom-list">
						<CompactRow
							icon="extension"
							label="Axiom Plugins"
							onClick={() => acode.exec("open", "plugins")}
						/>
						<CompactRow
							icon="color_lenspalette"
							label="Themes & Appearance"
							onClick={() => acode.exec("change-app-theme")}
						/>
						<CompactRow
							icon="settings"
							label="Settings"
							onClick={() => acode.exec("open", "settings")}
						/>
						<CompactRow
							icon="info_outline"
							label="About Axiom Code"
							onClick={() => acode.exec("open", "about")}
						/>
					</div>
				</section>
			</div>
		</div>
	);
}

function QuickCard({ icon, title, subtitle, accent = false, onClick }) {
	return (
		<div className={`axiom-card ${accent ? "axiom-card-accent" : ""}`} onclick={onClick}>
			<div className="axiom-card-icon-wrap">
				<span className={`icon ${icon} axiom-card-icon`}></span>
			</div>
			<div className="axiom-card-title">{title}</div>
			<div className="axiom-card-sub">{subtitle}</div>
		</div>
	);
}

function CompactRow({ icon, label, onClick }) {
	return (
		<div className="axiom-row" onclick={onClick}>
			<span className={`icon ${icon} axiom-row-icon`}></span>
			<span className="axiom-row-label">{label}</span>
			<span className="icon keyboard_arrow_right axiom-row-chevron"></span>
		</div>
	);
}
