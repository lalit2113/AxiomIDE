# Axiom Code (Open-Source Fork of Acode)

**Axiom Code** (`com.axiom.code`) is a 100% free, ad-free, open-source Android code editor forked from [Acode](https://github.com/Acode-Foundation/Acode) under the MIT License.

## What's Customized in This Fork
- Rebranded identity (`Axiom Code`, package `com.axiom.code`, custom Axiom geometric vector launcher icon and `#0B0F17` dark splash background).
- Configured to build the **100% free, ad-free, IAP-free (`fdroid`) flavor** automatically via `.github/workflows/build-axiom-code.yml`.
- Auto-populates the `codemirror-lsp-client` submodule during GitHub Actions builds.

## Attribution & License
Original Acode codebase copyright Foxdebug (Ajit Kumar) & Acode contributors, licensed under the [MIT License](license.txt).
