package com.axiom.ide.feature.auth

import android.net.Uri
import android.util.Base64
import com.axiom.ide.core.data.SecureStorage
import com.axiom.ide.core.data.db.AxiomDatabase
import com.axiom.ide.core.data.db.LocalUserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class AuthenticatedUser(
    val email: String,
    val displayName: String,
    val provider: String
)

sealed class AuthResult {
    data class Success(val user: AuthenticatedUser) : AuthResult()
    data class VerificationRequired(
        val email: String,
        val offlinePreviewCode: String? = null
    ) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthManager(
    private val db: AxiomDatabase,
    private val secureStorage: SecureStorage
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    // Pending offline 6-digit code map (only used when no remote backend URL is configured)
    private val localPendingCodes = mutableMapOf<String, String>()
    private val localPendingUsers = mutableMapOf<String, LocalUserEntity>()

    fun getCurrentSession(): AuthenticatedUser? {
        val email = secureStorage.getSecret(SecureStorage.KEY_ACTIVE_USER_EMAIL) ?: return null
        val name = secureStorage.getSecret(SecureStorage.KEY_AUTH_DISPLAY_NAME) ?: email.substringBefore("@")
        val provider = secureStorage.getSecret(SecureStorage.KEY_AUTH_PROVIDER) ?: "email"
        return AuthenticatedUser(email = email, displayName = name, provider = provider)
    }

    fun buildOAuthStartUrl(backendBaseUrl: String, provider: String): String? {
        val clean = backendBaseUrl.trim().trimEnd('/')
        if (!clean.startsWith("https://")) return null
        return "$clean/auth/oauth/$provider/start"
    }

    fun handleOAuthDeepLink(uri: Uri): AuthenticatedUser? {
        if (uri.scheme != "axiomide" || uri.host != "auth") return null
        val token = uri.getQueryParameter("token") ?: return null
        val email = uri.getQueryParameter("email") ?: return null
        val name = uri.getQueryParameter("name") ?: email.substringBefore("@")
        val provider = uri.getQueryParameter("provider") ?: "oauth"
        saveSession(email, name, provider, token)
        return AuthenticatedUser(email, name, provider)
    }

    suspend fun register(
        displayName: String,
        email: String,
        password: String,
        backendBaseUrl: String
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (displayName.isBlank()) return@withContext AuthResult.Error("Display name is required.")
        if (!cleanEmail.contains("@") || !cleanEmail.contains(".")) return@withContext AuthResult.Error("Enter a valid email address.")
        if (password.length < 8) return@withContext AuthResult.Error("Password must be at least 8 characters.")

        val cleanBackend = backendBaseUrl.trim().trimEnd('/')
        if (cleanBackend.startsWith("https://")) {
            return@withContext runCatching {
                val payload = JSONObject().apply {
                    put("display_name", displayName.trim())
                    put("email", cleanEmail)
                    put("password", password)
                }
                val req = Request.Builder()
                    .url("$cleanBackend/auth/register")
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val detail = runCatching { JSONObject(body).optString("detail") }.getOrDefault(body)
                        AuthResult.Error(detail.ifBlank { "Registration failed (HTTP ${resp.code})" })
                    } else {
                        AuthResult.VerificationRequired(email = cleanEmail, offlinePreviewCode = null)
                    }
                }
            }.getOrElse { AuthResult.Error("Backend unreachable: ${it.message}") }
        }

        // Offline local registration with local 6-digit verification challenge
        if (db.localUserDao().findByEmail(cleanEmail) != null) {
            return@withContext AuthResult.Error("An account with this email already exists on this device.")
        }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val user = LocalUserEntity(
            email = cleanEmail,
            displayName = displayName.trim(),
            passwordHash = hashPassword(password, salt),
            passwordSalt = Base64.encodeToString(salt, Base64.NO_WRAP)
        )
        val code = (100000 + SecureRandom().nextInt(900000)).toString()
        localPendingUsers[cleanEmail] = user
        localPendingCodes[cleanEmail] = code
        AuthResult.VerificationRequired(email = cleanEmail, offlinePreviewCode = code)
    }

    suspend fun verifyEmailCode(
        email: String,
        code: String,
        backendBaseUrl: String
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanCode = code.trim()
        if (cleanCode.length != 6 || !cleanCode.all { it.isDigit() }) {
            return@withContext AuthResult.Error("Enter the 6-digit verification code.")
        }

        val cleanBackend = backendBaseUrl.trim().trimEnd('/')
        if (cleanBackend.startsWith("https://")) {
            return@withContext runCatching {
                val payload = JSONObject().apply {
                    put("email", cleanEmail)
                    put("code", cleanCode)
                }
                val req = Request.Builder()
                    .url("$cleanBackend/auth/verify-email")
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val detail = runCatching { JSONObject(body).optString("detail") }.getOrDefault("Invalid code")
                        AuthResult.Error(detail)
                    } else {
                        val json = JSONObject(body)
                        val token = json.getString("token")
                        val name = json.optString("display_name", cleanEmail.substringBefore("@"))
                        val provider = json.optString("provider", "email")
                        saveSession(cleanEmail, name, provider, token)
                        AuthResult.Success(AuthenticatedUser(cleanEmail, name, provider))
                    }
                }
            }.getOrElse { AuthResult.Error("Verification request failed: ${it.message}") }
        }

        val expected = localPendingCodes[cleanEmail]
        val pendingUser = localPendingUsers[cleanEmail]
        if (expected == null || pendingUser == null || expected != cleanCode) {
            return@withContext AuthResult.Error("Invalid 6-digit code.")
        }
        db.localUserDao().insert(pendingUser)
        localPendingCodes.remove(cleanEmail)
        localPendingUsers.remove(cleanEmail)
        saveSession(pendingUser.email, pendingUser.displayName, "local-email", "local")
        AuthResult.Success(AuthenticatedUser(pendingUser.email, pendingUser.displayName, "local-email"))
    }

    suspend fun resendCode(email: String, backendBaseUrl: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanBackend = backendBaseUrl.trim().trimEnd('/')
        if (cleanBackend.startsWith("https://")) {
            return@withContext runCatching {
                val payload = JSONObject().apply { put("email", cleanEmail) }
                val req = Request.Builder()
                    .url("$cleanBackend/auth/resend-code")
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) AuthResult.Error("Could not resend code (HTTP ${resp.code})")
                    else AuthResult.VerificationRequired(cleanEmail, null)
                }
            }.getOrElse { AuthResult.Error("Resend failed: ${it.message}") }
        }
        val code = (100000 + SecureRandom().nextInt(900000)).toString()
        localPendingCodes[cleanEmail] = code
        AuthResult.VerificationRequired(cleanEmail, code)
    }

    suspend fun login(email: String, password: String, backendBaseUrl: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanBackend = backendBaseUrl.trim().trimEnd('/')
        if (cleanBackend.startsWith("https://")) {
            return@withContext runCatching {
                val payload = JSONObject().apply {
                    put("email", cleanEmail)
                    put("password", password)
                }
                val req = Request.Builder()
                    .url("$cleanBackend/auth/login")
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (resp.code == 403 && body.contains("EMAIL_NOT_VERIFIED")) {
                        AuthResult.VerificationRequired(cleanEmail, null)
                    } else if (!resp.isSuccessful) {
                        val detail = runCatching { JSONObject(body).optString("detail") }.getOrDefault("Sign in failed")
                        AuthResult.Error(detail)
                    } else {
                        val json = JSONObject(body)
                        val token = json.getString("token")
                        val name = json.optString("display_name", cleanEmail.substringBefore("@"))
                        val provider = json.optString("provider", "email")
                        saveSession(cleanEmail, name, provider, token)
                        AuthResult.Success(AuthenticatedUser(cleanEmail, name, provider))
                    }
                }
            }.getOrElse { AuthResult.Error("Backend unreachable: ${it.message}") }
        }

        val user = db.localUserDao().findByEmail(cleanEmail)
            ?: return@withContext AuthResult.Error("No local account found for $cleanEmail.")
        val salt = Base64.decode(user.passwordSalt, Base64.NO_WRAP)
        if (hashPassword(password, salt) != user.passwordHash) {
            return@withContext AuthResult.Error("Incorrect password.")
        }
        saveSession(user.email, user.displayName, "local-email", "local")
        AuthResult.Success(AuthenticatedUser(user.email, user.displayName, "local-email"))
    }

    suspend fun resetLocalPassword(email: String, newPassword: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (newPassword.length < 8) return@withContext AuthResult.Error("New password must be at least 8 characters.")
        val user = db.localUserDao().findByEmail(cleanEmail)
            ?: return@withContext AuthResult.Error("No local account found for $cleanEmail.")
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        db.localUserDao().update(
            user.copy(
                passwordHash = hashPassword(newPassword, salt),
                passwordSalt = Base64.encodeToString(salt, Base64.NO_WRAP)
            )
        )
        AuthResult.Success(AuthenticatedUser(user.email, user.displayName, "local-email"))
    }

    fun logout() {
        secureStorage.removeSecret(SecureStorage.KEY_ACTIVE_USER_EMAIL)
        secureStorage.removeSecret(SecureStorage.KEY_AUTH_DISPLAY_NAME)
        secureStorage.removeSecret(SecureStorage.KEY_AUTH_PROVIDER)
        secureStorage.removeSecret(SecureStorage.KEY_AUTH_TOKEN)
    }

    suspend fun deleteLocalAccount(email: String) = withContext(Dispatchers.IO) {
        db.localUserDao().deleteByEmail(email)
        logout()
    }

    private fun saveSession(email: String, displayName: String, provider: String, token: String) {
        secureStorage.putSecret(SecureStorage.KEY_ACTIVE_USER_EMAIL, email)
        secureStorage.putSecret(SecureStorage.KEY_AUTH_DISPLAY_NAME, displayName)
        secureStorage.putSecret(SecureStorage.KEY_AUTH_PROVIDER, provider)
        secureStorage.putSecret(SecureStorage.KEY_AUTH_TOKEN, token)
    }

    private fun hashPassword(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 65536, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return Base64.encodeToString(factory.generateSecret(spec).encoded, Base64.NO_WRAP)
    }
}
