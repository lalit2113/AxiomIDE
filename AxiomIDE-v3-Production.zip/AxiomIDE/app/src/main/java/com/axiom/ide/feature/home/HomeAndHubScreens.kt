package com.axiom.ide.feature.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.axiom.ide.core.data.db.ProjectEntity
import com.axiom.ide.core.data.db.RecentFileEntity
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    userName: String?,
    githubUsername: String?,
    projects: List<ProjectEntity>,
    recentFiles: List<RecentFileEntity>,
    installedExtensionsCount: Int,
    storageBytes: Long,
    onCreateProject: () -> Unit,
    onOpenProjects: () -> Unit,
    onOpenProject: (ProjectEntity) -> Unit,
    onOpenRecentFile: (RecentFileEntity) -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenTools: () -> Unit
) {
    val storageKb = storageBytes / 1024.0
    val storageLabel = if (storageKb >= 1024) "%.2f MB".format(storageKb / 1024.0) else "%.1f KB".format(storageKb)

    // Smooth staggered entrance animations
    var showHero by remember { mutableStateOf(false) }
    var showActions by remember { mutableStateOf(false) }
    var showRecent by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        showHero = true
        delay(90)
        showActions = true
        delay(90)
        showRecent = true
    }

    val pulseTransition = rememberInfiniteTransition(label = "status_pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .animateContentSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Animated Hero Banner
        AnimatedVisibility(
            visible = showHero,
            enter = fadeIn(tween(320)) + slideInVertically(tween(320)) { -it / 4 }
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .alpha(pulseAlpha)
                                .background(Color(0xFF22C55E), CircleShape)
                        )
                        Text(
                            text = if (githubUsername != null) "Online • GitHub @$githubUsername" else "Offline-Ready Engine Active",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = if (userName != null) "Welcome back, $userName" else "Axiom IDE",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        StatBadge("Projects", projects.size.toString())
                        StatBadge("Storage", storageLabel)
                        StatBadge("Extensions", installedExtensionsCount.toString())
                    }
                }
            }
        }

        // Animated Quick Action Grid
        AnimatedVisibility(
            visible = showActions,
            enter = fadeIn(tween(340)) + slideInVertically(tween(340)) { it / 4 }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onCreateProject, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text(" New Project")
                    }
                    OutlinedButton(onClick = onOpenProjects, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Text(" Projects")
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onOpenTerminal, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Terminal, contentDescription = null)
                        Text(" Shell")
                    }
                    OutlinedButton(onClick = onOpenTools, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Build, contentDescription = null)
                        Text(" 19 Tools")
                    }
                }
            }
        }

        // Animated Recent Projects & Recent Files
        AnimatedVisibility(
            visible = showRecent,
            enter = fadeIn(tween(360)) + slideInVertically(tween(360)) { it / 5 }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Recent Projects", style = MaterialTheme.typography.titleMedium)
                if (projects.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "No projects yet. Create one from templates or import a ZIP / folder.",
                            modifier = Modifier.padding(14.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    projects.take(4).forEach { project ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth().clickable { onOpenProject(project) }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Column {
                                    Text(project.name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${project.primaryLanguage} • ${project.template}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                Text("Recent Files", style = MaterialTheme.typography.titleMedium)
                if (recentFiles.isEmpty()) {
                    Text("Files you open in the editor appear here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    recentFiles.take(5).forEach { file ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth().clickable { onOpenRecentFile(file) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(file.fileName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${file.projectName} • ${file.language}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun StatBadge(label: String, value: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private data class HubItem(val title: String, val subtitle: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
fun HubScreen(
    githubUsername: String?,
    onOpenGitHub: () -> Unit,
    onOpenTools: () -> Unit,
    onOpenRunner: () -> Unit,
    onOpenPreview: () -> Unit,
    onOpenAi: () -> Unit,
    onOpenExtensions: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val items = listOf(
        HubItem("GitHub", githubUsername?.let { "Connected as @$it" } ?: "Sync live repositories", Icons.Default.Cloud, onOpenGitHub),
        HubItem("Developer Toolbox", "19 local utilities (JSON, JWT, Regex, API...)", Icons.Default.Build, onOpenTools),
        HubItem("Run & Output Console", "Shell, Termux & HTTPS Piston runner", Icons.Default.PlayArrow, onOpenRunner),
        HubItem("Live Web Preview", "HTML/CSS/JS preview + JS console", Icons.Default.Public, onOpenPreview),
        HubItem("AI Assistant", "Optional BYOK HTTPS AI provider", Icons.Default.AutoAwesome, onOpenAi),
        HubItem("Extensions", "Import & manage local JSON manifests", Icons.Default.Extension, onOpenExtensions),
        HubItem("Settings", "Themes, accents, backend URL & editor", Icons.Default.Settings, onOpenSettings),
        HubItem("Account & Profile", "Google, GitHub, Discord, Email or Guest", Icons.Default.Person, onOpenProfile),
        HubItem("About & Privacy", "Security architecture & version info", Icons.Default.Info, onOpenAbout)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Workspace Hub", style = MaterialTheme.typography.titleLarge)
        items.forEach { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth().clickable { item.onClick() }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Text(item.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
