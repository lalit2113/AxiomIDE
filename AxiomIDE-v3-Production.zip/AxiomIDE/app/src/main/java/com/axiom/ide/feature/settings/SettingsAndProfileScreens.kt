package com.axiom.ide.feature.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.data.SettingsRepository
import com.axiom.ide.core.designsystem.AccentPreset
import com.axiom.ide.core.designsystem.AppThemeMode
import com.axiom.ide.feature.auth.AuthManager
import com.axiom.ide.feature.auth.AuthenticatedUser
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: IdeSettings,
    settingsRepo: SettingsRepository,
    onOpenAbout: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var backendUrl by remember(settings.backendBaseUrl) { mutableStateOf(settings.backendBaseUrl) }
    var savedMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)

        Text("Theme", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = settings.themeMode == mode,
                    onClick = { scope.launch { settingsRepo.setThemeMode(mode) } },
                    label = { Text(mode.label) }
                )
            }
        }

        Text("Accent Color", style = MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AccentPreset.entries.forEach { preset ->
                FilterChip(
                    selected = settings.accentPreset == preset,
                    onClick = { scope.launch { settingsRepo.setAccentPreset(preset) } },
                    label = { Text(preset.label) }
                )
            }
        }

        Text("Editor Font Size: ${settings.editorFontSizeSp} sp", style = MaterialTheme.typography.titleMedium)
        Slider(
            value = settings.editorFontSizeSp.toFloat(),
            onValueChange = { scope.launch { settingsRepo.setEditorFontSize(it.toInt()) } },
            valueRange = 10f..24f
        )

        Text("Terminal Font Size: ${settings.terminalFontSizeSp} sp", style = MaterialTheme.typography.titleMedium)
        Slider(
            value = settings.terminalFontSizeSp.toFloat(),
            onValueChange = { scope.launch { settingsRepo.setTerminalFontSize(it.toInt()) } },
            valueRange = 10f..22f
        )

        SettingToggleRow("Show Line Numbers", settings.showLineNumbers) { scope.launch { settingsRepo.setShowLineNumbers(it) } }
        SettingToggleRow("Word Wrap", settings.wordWrap) { scope.launch { settingsRepo.setWordWrap(it) } }
        SettingToggleRow("Auto-Save Open Files", settings.autoSaveEnabled) { scope.launch { settingsRepo.setAutoSave(it) } }
        SettingToggleRow("Auto-Close Brackets", settings.autoCloseBrackets) { scope.launch { settingsRepo.setAutoCloseBrackets(it) } }

        Text("Auth & Sync Backend URL (Optional)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = backendUrl,
            onValueChange = { backendUrl = it },
            label = { Text("Deployed HTTPS Axiom Backend URL") },
            placeholder = { Text("https://your-axiom-backend.onrender.com") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                scope.launch {
                    settingsRepo.setBackendBaseUrl(backendUrl)
                    savedMsg = if (backendUrl.isBlank()) "Cleared (Offline auth mode active)" else "Backend URL saved"
                }
            }) { Text("Save Backend URL") }
            savedMsg?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onOpenProfile, modifier = Modifier.weight(1f)) { Text("Account") }
            OutlinedButton(onClick = onOpenAbout, modifier = Modifier.weight(1f)) { Text("About & Privacy") }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun SettingToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
fun UserProfileScreen(
    currentUser: AuthenticatedUser?,
    authManager: AuthManager,
    onSignedOut: () -> Unit,
    onGoToLogin: () -> Unit
) {
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Account", style = MaterialTheme.typography.titleLarge)

        if (currentUser == null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Offline Guest Mode", style = MaterialTheme.typography.titleMedium)
                    Text("All built-in features are unlocked locally with no account required.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onGoToLogin) { Text("Sign In / Create Account") }
                }
            }
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(currentUser.displayName, style = MaterialTheme.typography.titleMedium)
                    Text(currentUser.email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Provider: ${currentUser.provider.uppercase()} • 100% Free Tier",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { authManager.logout(); onSignedOut() }, modifier = Modifier.weight(1f)) { Text("Sign Out") }
                Button(onClick = { scope.launch { authManager.deleteLocalAccount(currentUser.email); onSignedOut() } }, modifier = Modifier.weight(1f)) {
                    Text("Delete Local Data")
                }
            }
        }
    }
}

@Composable
fun AboutPrivacyScreen() {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("About Axiom IDE", style = MaterialTheme.typography.titleLarge)
        Text("Version 3.0.0 Production • 100% Free, Zero Ads, Zero Subscriptions.", style = MaterialTheme.typography.bodyMedium)

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Security & Privacy", style = MaterialTheme.typography.titleMedium)
                Text("• Offline-first architecture with zero analytics, ad SDKs, or trackers.")
                Text("• OAuth tokens, AI keys, and sessions are encrypted with Android Keystore AES-256-GCM.")
                Text("• Network calls enforce HTTPS-only transport (usesCleartextTraffic=false).")
                Text("• ZIP imports validate canonical paths against Zip Slip traversal.")
                Text("• Supports Google, GitHub, Discord OAuth, and 6-digit SMTP email verification via your self-hosted Axiom FastAPI backend.")
            }
        }
    }
}
