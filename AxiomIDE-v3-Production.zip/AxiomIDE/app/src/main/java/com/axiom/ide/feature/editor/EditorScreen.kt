package com.axiom.ide.feature.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.data.SettingsRepository
import com.axiom.ide.core.data.db.AxiomDatabase
import com.axiom.ide.core.data.db.ProjectEntity
import com.axiom.ide.core.data.db.SnippetEntity
import com.axiom.ide.core.designsystem.AppThemeMode
import com.axiom.ide.feature.tools.DevToolsEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val acodeExtraKeys = listOf(
    "TAB" to "  ", "{" to "{", "}" to "}", "(" to "(", ")" to ")",
    "[" to "[", "]" to "]", "<" to "<", ">" to ">", ";" to ";",
    ":" to ":", "\"" to "\"", "'" to "'", "=" to "=", "/" to "/",
    "\\" to "\\", "|" to "|", "&" to "&", "!" to "!", "$" to "$"
)

private val encodings = listOf("UTF-8", "UTF-16", "ISO-8859-1", "US-ASCII")

@Composable
fun EditorScreen(
    controller: EditorWorkspaceController,
    activeProject: ProjectEntity?,
    db: AxiomDatabase,
    settings: IdeSettings,
    settingsRepo: SettingsRepository,
    editorRevision: Int,
    onMutated: () -> Unit,
    onOpenFileFromSidebar: (File, String) -> Unit,
    onRunFile: (File) -> Unit,
    onPreviewHtml: (File) -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenProjects: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    var localRev by remember { mutableIntStateOf(0) }
    val tabs = remember(editorRevision, localRev) { controller.tabs }
    val activeTab = remember(editorRevision, localRev) { controller.activeTab }
    val snippets by db.snippetDao().observeAll().collectAsState(initial = emptyList())

    var showFindReplace by remember { mutableStateOf(false) }
    var showCommandPalette by remember { mutableStateOf(false) }
    var showGoToLine by remember { mutableStateOf(false) }
    var showEncodingDialog by remember { mutableStateOf(false) }
    var showSnippetsDialog by remember { mutableStateOf(false) }
    var showDiffDialog by remember { mutableStateOf(false) }
    var pendingCloseTabIdx by remember { mutableStateOf<Int?>(null) }

    var findQuery by remember { mutableStateOf("") }
    var replaceQuery by remember { mutableStateOf("") }
    var ignoreCase by remember { mutableStateOf(true) }
    var statusText by remember { mutableStateOf<String?>(null) }
    val verticalScroll = rememberScrollState()

    // Background IO auto-save
    LaunchedEffect(activeTab?.filePath, activeTab?.content, settings.autoSaveEnabled) {
        if (settings.autoSaveEnabled && activeTab != null && activeTab.isDirty) {
            delay(settings.autoSaveIntervalSec * 1000L)
            val saved = withContext(Dispatchers.IO) { controller.saveActiveTab() }
            if (saved) {
                localRev++
                onMutated()
                statusText = "Auto-saved"
            }
        }
    }

    // Acode-style Slide-Out File Tree Drawer
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(280.dp)) {
                EditorFileTreeSidebar(
                    project = activeProject,
                    onSelectFile = { file ->
                        onOpenFileFromSidebar(file, activeProject?.name ?: "Project")
                        scope.launch { drawerState.close() }
                    },
                    onBrowseProjects = {
                        scope.launch { drawerState.close() }
                        onOpenProjects()
                    }
                )
            }
        }
    ) {
        if (activeTab == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No Open Files", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Swipe right for the File Tree or open a project.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onOpenProjects) { Text("Projects") }
                    if (activeProject != null) {
                        OutlinedButton(onClick = { scope.launch { drawerState.open() } }) { Text("File Tree") }
                    }
                }
            }
            return@ModalNavigationDrawer
        }

        val isDark = settings.themeMode != AppThemeMode.LIGHT
        val highlightedCache = remember(activeTab.content, isDark) {
            SyntaxHighlighter.highlight(activeTab.content, isDark)
        }
        val syntaxTransform = remember(highlightedCache) {
            VisualTransformation { text ->
                val annotated = if (text.text == highlightedCache.text) highlightedCache
                else SyntaxHighlighter.highlight(text.text, isDark)
                TransformedText(annotated, OffsetMapping.Identity)
            }
        }

        val lineCount = remember(activeTab.content) { activeTab.content.count { it == '\n' } + 1 }
        val gutterText = remember(lineCount) { (1..lineCount).joinToString("\n") }

        Column(modifier = Modifier.fillMaxSize().imePadding()) {
            // Acode-style Slim Tab Bar + File Tree Toggle + Command Palette
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(Icons.Default.Menu, contentDescription = "File Tree Sidebar")
                }

                Row(
                    modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tabs.forEachIndexed { index, tab ->
                        val selected = index == controller.activeIndex
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.clickable {
                                controller.selectTab(index)
                                localRev++
                                onMutated()
                            }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(start = 10.dp, end = 2.dp, top = 4.dp, bottom = 4.dp)
                            ) {
                                Text(
                                    text = if (tab.isDirty) "• ${tab.fileName}" else tab.fileName,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                IconButton(onClick = {
                                    if (tab.isDirty) {
                                        pendingCloseTabIdx = index
                                    } else {
                                        controller.closeTab(index)
                                        localRev++
                                        onMutated()
                                    }
                                }) { Icon(Icons.Default.Close, contentDescription = "Close tab") }
                            }
                        }
                    }
                }

                IconButton(onClick = { showCommandPalette = true }) {
                    Icon(Icons.Default.Search, contentDescription = "Command Palette")
                }

                IconButton(onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { controller.saveActiveTab() }
                        val file = File(activeTab.filePath)
                        if (activeTab.language.id == "html") onPreviewHtml(file) else onRunFile(file)
                    }
                }) { Icon(Icons.Default.PlayArrow, contentDescription = "Run or Preview") }
            }

            // Compact Action Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    scope.launch {
                        if (withContext(Dispatchers.IO) { controller.saveActiveTab() }) {
                            statusText = "Saved"
                            localRev++; onMutated()
                        }
                    }
                }) { Icon(Icons.Default.Save, contentDescription = "Save") }
                IconButton(onClick = { controller.undo(); localRev++; onMutated() }) { Icon(Icons.Default.Undo, contentDescription = "Undo") }
                IconButton(onClick = { controller.redo(); localRev++; onMutated() }) { Icon(Icons.Default.Redo, contentDescription = "Redo") }
                IconButton(onClick = { showFindReplace = !showFindReplace }) { Icon(Icons.Default.FindReplace, contentDescription = "Find") }
                IconButton(onClick = { controller.formatActiveCode(settings.tabSize); localRev++; onMutated() }) {
                    Icon(Icons.Default.FormatAlignLeft, contentDescription = "Format")
                }
                IconButton(onClick = { showSnippetsDialog = true }) { Icon(Icons.Default.DataObject, contentDescription = "Snippets") }
                if (tabs.size >= 2) {
                    IconButton(onClick = { showDiffDialog = true }) { Icon(Icons.Default.CompareArrows, contentDescription = "Diff") }
                }
                IconButton(onClick = { controller.toggleReadOnly(); localRev++; onMutated() }) {
                    Icon(if (activeTab.isReadOnly) Icons.Default.Lock else Icons.Default.LockOpen, contentDescription = "Read-Only")
                }
                OutlinedButton(onClick = { controller.toggleCommentAllOrFirstLine(); localRev++; onMutated() }) { Text("//") }
            }

            // Enhanced Find & Replace Bar with Match Count & Case Toggle
            if (showFindReplace) {
                val matchCount = remember(findQuery, activeTab.content, ignoreCase) {
                    controller.countMatches(findQuery, ignoreCase)
                }
                Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = findQuery,
                            onValueChange = { findQuery = it },
                            placeholder = { Text("Find ($matchCount matches)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        FilterChip(selected = !ignoreCase, onClick = { ignoreCase = !ignoreCase }, label = { Text("Aa") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = replaceQuery,
                            onValueChange = { replaceQuery = it },
                            placeholder = { Text("Replace with...") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(onClick = {
                            val replaced = controller.findAndReplace(findQuery, replaceQuery, ignoreCase)
                            statusText = "Replaced $replaced"
                            localRev++; onMutated()
                        }) { Text("Replace All") }
                    }
                }
            }

            HorizontalDivider()

            // High-Performance Code Canvas
            val horizontalScroll = rememberScrollState()
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(verticalScroll)
            ) {
                if (settings.showLineNumbers) {
                    Text(
                        text = gutterText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = settings.editorFontSizeSp.sp,
                        lineHeight = (settings.editorFontSizeSp + 6).sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 10.dp, vertical = 10.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .then(if (settings.wordWrap) Modifier else Modifier.horizontalScroll(horizontalScroll))
                        .padding(10.dp)
                ) {
                    BasicTextField(
                        value = activeTab.content,
                        onValueChange = { updated ->
                            controller.updateActiveContent(updated, settings.autoCloseBrackets, settings.tabSize)
                            localRev++; onMutated()
                        },
                        readOnly = activeTab.isReadOnly,
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = settings.editorFontSizeSp.sp,
                            lineHeight = (settings.editorFontSizeSp + 6).sp,
                            color = MaterialTheme.colorScheme.onBackground
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        visualTransformation = syntaxTransform,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Acode-Style Extra Keys Bar pinned right above keyboard
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 6.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    acodeExtraKeys.forEach { (label, insertion) ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = MaterialTheme.shapes.extraSmall,
                            modifier = Modifier.clickable {
                                controller.appendText(insertion)
                                localRev++; onMutated()
                            }
                        ) {
                            Text(
                                text = label,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Status Bar (Tap Encoding or Line count for quick dialogs)
            Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${activeTab.language.displayName} • ${activeTab.encodingName} • $lineCount L",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable { showGoToLine = true }
                    )
                    Text(
                        text = statusText ?: if (activeTab.isReadOnly) "READ-ONLY" else "READY",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }

    // Command Palette Dialog (Acode / VS Code style)
    if (showCommandPalette) {
        var cmdQuery by remember { mutableStateOf("") }
        val commands = listOf(
            "Save Active File" to {
                scope.launch {
                    withContext(Dispatchers.IO) { controller.saveActiveTab() }
                    statusText = "Saved"; localRev++; onMutated()
                }
            },
            "Save All Open Files" to {
                scope.launch {
                    val n = withContext(Dispatchers.IO) { controller.saveAllTabs() }
                    statusText = "Saved $n file(s)"; localRev++; onMutated()
                }
            },
            "Go to Line..." to { showGoToLine = true },
            "Find & Replace" to { showFindReplace = true },
            "Format Document" to { controller.formatActiveCode(settings.tabSize); localRev++; onMutated() },
            "Toggle Comment" to { controller.toggleCommentAllOrFirstLine(); localRev++; onMutated() },
            "Toggle Word Wrap" to { scope.launch { settingsRepo.setWordWrap(!settings.wordWrap) } },
            "Toggle Read-Only Mode" to { controller.toggleReadOnly(); localRev++; onMutated() },
            "Change File Encoding" to { showEncodingDialog = true },
            "Insert / Manage Snippets" to { showSnippetsDialog = true },
            "Compare Open Tabs (Diff)" to { if (tabs.size >= 2) showDiffDialog = true },
            "Open File Tree Sidebar" to { scope.launch { drawerState.open() } },
            "Open Integrated Shell" to { onOpenTerminal() }
        ).filter { cmdQuery.isBlank() || it.first.contains(cmdQuery, ignoreCase = true) }

        AlertDialog(
            onDismissRequest = { showCommandPalette = false },
            title = { Text("Command Palette") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cmdQuery, onValueChange = { cmdQuery = it }, placeholder = { Text("Type a command...") }, singleLine = true)
                    LazyColumn(modifier = Modifier.height(240.dp)) {
                        items(commands) { (label, action) ->
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showCommandPalette = false
                                        action()
                                    }
                                    .padding(vertical = 10.dp)
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCommandPalette = false }) { Text("Close") } }
        )
    }

    // Go to Line Dialog
    if (showGoToLine && activeTab != null) {
        var lineInput by remember { mutableStateOf("") }
        val totalLines = activeTab.content.count { it == '\n' } + 1
        AlertDialog(
            onDismissRequest = { showGoToLine = false },
            title = { Text("Go to Line (1 - $totalLines)") },
            text = {
                OutlinedTextField(
                    value = lineInput,
                    onValueChange = { lineInput = it.filter { c -> c.isDigit() } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    label = { Text("Line number") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val target = (lineInput.toIntOrNull() ?: 1).coerceIn(1, totalLines)
                    val ratio = (target - 1).toFloat() / totalLines.coerceAtLeast(1)
                    scope.launch { verticalScroll.animateScrollTo((verticalScroll.maxValue * ratio).toInt()) }
                    statusText = "Line $target"
                    showGoToLine = false
                }) { Text("Jump") }
            },
            dismissButton = { TextButton(onClick = { showGoToLine = false }) { Text("Cancel") } }
        )
    }

    // Encoding Picker Dialog
    if (showEncodingDialog) {
        AlertDialog(
            onDismissRequest = { showEncodingDialog = false },
            title = { Text("File Encoding") },
            text = {
                Column {
                    encodings.forEach { enc ->
                        Text(
                            text = enc,
                            modifier = Modifier.fillMaxWidth().clickable {
                                controller.setEncoding(enc)
                                localRev++; onMutated()
                                statusText = "Encoding: $enc"
                                showEncodingDialog = false
                            }.padding(vertical = 10.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showEncodingDialog = false }) { Text("Cancel") } }
        )
    }

    // Unsaved Changes Guard before closing a dirty tab
    pendingCloseTabIdx?.let { idx ->
        val closingTab = tabs.getOrNull(idx)
        if (closingTab != null) {
            AlertDialog(
                onDismissRequest = { pendingCloseTabIdx = null },
                title = { Text("Unsaved Changes") },
                text = { Text("${closingTab.fileName} has unsaved edits. Save before closing?") },
                confirmButton = {
                    Button(onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { controller.saveTabAt(idx) }
                            controller.closeTab(idx)
                            pendingCloseTabIdx = null
                            localRev++; onMutated()
                        }
                    }) { Text("Save & Close") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        controller.closeTab(idx)
                        pendingCloseTabIdx = null
                        localRev++; onMutated()
                    }) { Text("Discard") }
                }
            )
        }
    }

    if (showSnippetsDialog && activeTab != null) {
        SnippetsDialog(
            snippets = snippets,
            defaultLanguage = activeTab.language.displayName,
            onDismiss = { showSnippetsDialog = false },
            onInsert = { body ->
                controller.appendText("\n$body")
                localRev++; onMutated()
                showSnippetsDialog = false
            },
            onCreate = { title, prefix, lang, body ->
                scope.launch { db.snippetDao().insert(SnippetEntity(title = title, prefix = prefix, language = lang, body = body)) }
            },
            onDelete = { snippet -> scope.launch { db.snippetDao().delete(snippet) } }
        )
    }

    if (showDiffDialog && activeTab != null && tabs.size >= 2) {
        val otherTab = tabs.first { it.filePath != activeTab.filePath }
        val diffText = remember(activeTab.content, otherTab.content) {
            DevToolsEngine.diffLines(otherTab.content, activeTab.content)
        }
        AlertDialog(
            onDismissRequest = { showDiffDialog = false },
            title = { Text("Diff: ${otherTab.fileName} → ${activeTab.fileName}") },
            text = {
                Box(modifier = Modifier.height(300.dp).verticalScroll(rememberScrollState())) {
                    Text(diffText, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = { TextButton(onClick = { showDiffDialog = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun EditorFileTreeSidebar(
    project: ProjectEntity?,
    onSelectFile: (File) -> Unit,
    onBrowseProjects: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(project?.name ?: "No Active Project", style = MaterialTheme.typography.titleMedium)
        HorizontalDivider()
        if (project == null) {
            Text("Select a project first to browse its files here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onBrowseProjects) { Text("Open Projects") }
            return
        }

        var currentDir by remember(project.path) { mutableStateOf(File(project.path)) }
        val entries = remember(currentDir.absolutePath) {
            currentDir.listFiles()?.sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }) ?: emptyList()
        }

        if (currentDir.absolutePath != project.path) {
            TextButton(onClick = { currentDir.parentFile?.let { currentDir = it } }) { Text("← Up Folder") }
        }

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(entries, key = { it.absolutePath }) { file ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (file.isDirectory) currentDir = file else onSelectFile(file) }
                        .padding(vertical = 8.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (file.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                        contentDescription = null,
                        tint = if (file.isDirectory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(file.name, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun SnippetsDialog(
    snippets: List<SnippetEntity>,
    defaultLanguage: String,
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit,
    onCreate: (String, String, String, String) -> Unit,
    onDelete: (SnippetEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var prefix by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Code Snippets") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(value = prefix, onValueChange = { prefix = it }, label = { Text("Prefix") }, singleLine = true)
                OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Snippet Body") }, minLines = 2)
                Button(
                    enabled = title.isNotBlank() && body.isNotBlank(),
                    onClick = {
                        onCreate(title.trim(), prefix.trim(), defaultLanguage, body)
                        title = ""; prefix = ""; body = ""
                    }
                ) { Text("Save Snippet") }
                HorizontalDivider()
                if (snippets.isEmpty()) {
                    Text("No saved snippets yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(modifier = Modifier.height(160.dp)) {
                        items(snippets, key = { it.id }) { s ->
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable { onInsert(s.body) }.padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(s.title, style = MaterialTheme.typography.titleMedium)
                                    Text("${s.language} • ${s.prefix}", style = MaterialTheme.typography.labelMedium)
                                }
                                TextButton(onClick = { onDelete(s) }) { Text("Delete") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}
