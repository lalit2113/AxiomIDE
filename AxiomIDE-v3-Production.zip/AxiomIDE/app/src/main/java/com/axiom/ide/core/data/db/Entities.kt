package com.axiom.ide.core.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val path: String,
    val template: String,
    val primaryLanguage: String,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastOpenedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_files")
data class RecentFileEntity(
    @PrimaryKey val filePath: String,
    val fileName: String,
    val projectName: String,
    val language: String,
    val lastOpenedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "snippets")
data class SnippetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val prefix: String,
    val language: String,
    val body: String
)

@Entity(tableName = "extensions")
data class ExtensionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val author: String,
    val version: String,
    val category: String,
    val description: String,
    val permissions: String,
    val manifestJson: String = "",
    val isInstalled: Boolean = true,
    val isEnabled: Boolean = true
)

@Entity(tableName = "local_users")
data class LocalUserEntity(
    @PrimaryKey val email: String,
    val displayName: String,
    val passwordHash: String,
    val passwordSalt: String,
    val createdAt: Long = System.currentTimeMillis()
)
