package com.axiom.ide

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.designsystem.AxiomTheme
import com.axiom.ide.navigation.AxiomRoot

class MainActivity : ComponentActivity() {

    private val incomingOAuthUri = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        incomingOAuthUri.value = intent?.data

        val app = application as AxiomApp
        setContent {
            val settings by app.settingsRepository.settingsFlow.collectAsState(initial = IdeSettings())
            AxiomTheme(
                themeMode = settings.themeMode,
                accentPreset = settings.accentPreset
            ) {
                AxiomRoot(
                    app = app,
                    settings = settings,
                    pendingOAuthUri = incomingOAuthUri.value,
                    onOAuthHandled = { incomingOAuthUri.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.data?.let { incomingOAuthUri.value = it }
    }
}
