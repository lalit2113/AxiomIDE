package com.axiom.ide.core.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProjectEntity::class,
        RecentFileEntity::class,
        SnippetEntity::class,
        ExtensionEntity::class,
        LocalUserEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AxiomDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun recentFileDao(): RecentFileDao
    abstract fun snippetDao(): SnippetDao
    abstract fun extensionDao(): ExtensionDao
    abstract fun localUserDao(): LocalUserDao

    companion object {
        @Volatile
        private var INSTANCE: AxiomDatabase? = null

        fun getInstance(context: Context): AxiomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AxiomDatabase::class.java,
                    "axiom_ide.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
