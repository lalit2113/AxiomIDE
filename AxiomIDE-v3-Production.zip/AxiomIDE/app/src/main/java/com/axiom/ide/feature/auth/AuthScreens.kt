package com.axiom.ide.feature.auth

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    authManager: AuthManager,
    backendBaseUrl: String,
    onAuthSuccess: () -> Unit,
    onNeedVerification: (email: String, offlineCode: String?) -> Unit,
    onContinueOffline: () -> Unit,
    onNavigateRegister: () -> Unit,
    onNavigateForgot: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    fun launchOAuth(provider: String) {
        val url = authManager.buildOAuthStartUrl(backendBaseUrl, provider)
        if (url == null) {
            message = "Set your deployed HTTPS Backend URL in Settings to enable ${provider.replaceFirstChar { it.uppercase() }} OAuth."
            return
        }
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }.onFailure { message = "Unable to open browser: ${it.message}" }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("Sign In to Axiom IDE", style = MaterialTheme.typography.headlineMedium)
        Text(
            if (backendBaseUrl.startsWith("https://")) "Connected to cloud auth backend."
            else "Offline local auth active. Configure a backend URL in Settings for Google, GitHub, Discord & SMTP email verification.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // OAuth Providers: Google, GitHub, Discord
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { launchOAuth("google") }, modifier = Modifier.weight(1f)) { Text("Google") }
            OutlinedButton(onClick = { launchOAuth("github") }, modifier = Modifier.weight(1f)) { Text("GitHub") }
            OutlinedButton(onClick = { launchOAuth("discord") }, modifier = Modifier.weight(1f)) { Text("Discord") }
        }

        HorizontalDivider()

        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }

        Button(
            enabled = !isLoading,
            onClick = {
                isLoading = true
                scope.launch {
                    when (val res = authManager.login(email, password, backendBaseUrl)) {
                        is AuthResult.Success -> onAuthSuccess()
                        is AuthResult.VerificationRequired -> onNeedVerification(res.email, res.offlinePreviewCode)
                        is AuthResult.Error -> message = res.message
                    }
                    isLoading = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (isLoading) "Signing in..." else "Sign In with Email") }

        OutlinedButton(onClick = onContinueOffline, modifier = Modifier.fillMaxWidth()) {
            Text("Continue Offline (Guest Mode)")
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onNavigateRegister) { Text("Create Account") }
            TextButton(onClick = onNavigateForgot) { Text("Reset Password") }
        }
    }
}

@Composable
fun RegisterScreen(
    authManager: AuthManager,
    backendBaseUrl: String,
    onNeedVerification: (email: String, offlineCode: String?) -> Unit,
    onBackToLogin: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var displayName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    fun launchOAuth(provider: String) {
        val url = authManager.buildOAuthStartUrl(backendBaseUrl, provider)
        if (url == null) {
            message = "Configure your HTTPS Backend URL in Settings to sign up with ${provider.replaceFirstChar { it.uppercase() }}."
            return
        }
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("Create Axiom Account", style = MaterialTheme.typography.headlineMedium)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { launchOAuth("google") }, modifier = Modifier.weight(1f)) { Text("Google") }
            OutlinedButton(onClick = { launchOAuth("github") }, modifier = Modifier.weight(1f)) { Text("GitHub") }
            OutlinedButton(onClick = { launchOAuth("discord") }, modifier = Modifier.weight(1f)) { Text("Discord") }
        }

        HorizontalDivider()

        OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text("Display Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (min 8 chars)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }

        Button(
            enabled = !isLoading,
            onClick = {
                isLoading = true
                scope.launch {
                    when (val res = authManager.register(displayName, email, password, backendBaseUrl)) {
                        is AuthResult.VerificationRequired -> onNeedVerification(res.email, res.offlinePreviewCode)
                        is AuthResult.Error -> message = res.message
                        is AuthResult.Success -> Unit
                    }
                    isLoading = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (isLoading) "Sending 6-Digit Code..." else "Continue & Verify Email") }

        TextButton(onClick = onBackToLogin) { Text("Back to Sign In") }
    }
}

@Composable
fun EmailVerificationScreen(
    email: String,
    initialOfflineCode: String?,
    authManager: AuthManager,
    backendBaseUrl: String,
    onVerified: () -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var offlineCode by remember { mutableStateOf(initialOfflineCode) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var resendSeconds by remember { mutableIntStateOf(60) }
    var isVerifying by remember { mutableStateOf(false) }

    LaunchedEffect(resendSeconds) {
        if (resendSeconds > 0) {
            delay(1000L)
            resendSeconds--
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Verify Your Email", style = MaterialTheme.typography.headlineMedium)
        Text(
            text = if (offlineCode == null) "Enter the 6-digit verification code sent to $email."
            else "Offline local mode (no SMTP backend configured). Enter this local 6-digit verification code for $email:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        offlineCode?.let { localCode ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = localCode.chunked(3).joinToString(" "),
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(14.dp)
                )
            }
        }

        // Visual 6-digit slot display
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0 until 6) {
                val ch = code.getOrNull(i)?.toString() ?: ""
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = if (i == code.length) 2.dp else 1.dp,
                        color = if (i == code.length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(ch, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
        }

        OutlinedTextField(
            value = code,
            onValueChange = { updated ->
                val digits = updated.filter { it.isDigit() }.take(6)
                code = digits
            },
            label = { Text("6-Digit Verification Code") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }

        Button(
            enabled = code.length == 6 && !isVerifying,
            onClick = {
                isVerifying = true
                scope.launch {
                    when (val res = authManager.verifyEmailCode(email, code, backendBaseUrl)) {
                        is AuthResult.Success -> onVerified()
                        is AuthResult.Error -> errorMsg = res.message
                        is AuthResult.VerificationRequired -> Unit
                    }
                    isVerifying = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (isVerifying) "Verifying..." else "Verify Code") }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(
                enabled = resendSeconds == 0,
                onClick = {
                    scope.launch {
                        when (val res = authManager.resendCode(email, backendBaseUrl)) {
                            is AuthResult.VerificationRequired -> {
                                offlineCode = res.offlinePreviewCode
                                resendSeconds = 60
                                errorMsg = null
                            }
                            is AuthResult.Error -> errorMsg = res.message
                            else -> Unit
                        }
                    }
                }
            ) {
                Text(if (resendSeconds > 0) "Resend in ${resendSeconds}s" else "Resend 6-Digit Code")
            }
            TextButton(onClick = onBack) { Text("Back") }
        }
    }
}

@Composable
fun ForgotPasswordScreen(
    authManager: AuthManager,
    onBackToLogin: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Reset Local Password", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Account Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            value = newPassword,
            onValueChange = { newPassword = it },
            label = { Text("New Password (min 8 chars)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        status?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
        Button(
            onClick = {
                scope.launch {
                    status = when (val res = authManager.resetLocalPassword(email, newPassword)) {
                        is AuthResult.Success -> "Local password updated."
                        is AuthResult.Error -> res.message
                        else -> null
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Update Password") }
        TextButton(onClick = onBackToLogin) { Text("Back to Sign In") }
    }
}
