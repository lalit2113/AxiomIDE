# Axiom IDE (Android) — Phase 2

Axiom IDE is a 100% free, offline-first Android coding platform built with Kotlin, Jetpack Compose, Material 3, Room, DataStore, Android Keystore, and Storage Access Framework.

## What's New in Phase 2
- **Rebranded to Axiom IDE** (`com.axiom.ide`) with a new geometric vector icon & splash screen.
- **Keyboard / IME Fix**: Bottom `NavigationBar` hides automatically when the soft keyboard opens, and all input screens apply `imePadding()` so typing fields stay visible above the keyboard.
- **Redesigned Navigation**: Clean 5-tab bottom bar (**Home**, **Projects**, **Editor**, **Shell**, **Hub**) with contextual top-bar titles and Back buttons on secondary screens.
- **Performance Upgrades**: Cached `AnnotatedString` syntax highlighting, single-node line-number gutter, background IO auto-save, and auto-scrolling terminal output.
- **Zero Placeholder Data**: Removed hardcoded dummy extension catalog items and prefilled dummy inputs; Extensions now imports real local `.json` manifests with permission checks.
- **Phase 2 Features**: Editor quick coding symbol bar, Room-backed custom snippets, open-tab Diff viewer, and optional HTTPS Piston-compatible remote code runner (with stdin & untrusted-code confirmation).
