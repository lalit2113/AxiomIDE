"""
Axiom IDE Production Backend (FastAPI + SQLite)
Provides:
- Email + Password registration with 6-digit OTP email verification (10-min TTL)
- Login & JWT Bearer session tokens (HMAC-SHA256)
- Google, GitHub, and Discord OAuth 2.0 login flows redirecting to axiomide://auth/callback
- Optional encrypted project backup endpoint

Configure secrets via environment variables (see .env.example). Never hardcode secrets.
"""
import hashlib
import hmac
import os
import secrets
import smtplib
import sqlite3
import time
from email.message import EmailMessage
from typing import Optional
from urllib.parse import urlencode

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, EmailStr

DB_PATH = os.getenv("AXIOM_DB_PATH", "axiom_backend.db")
JWT_SECRET = os.getenv("AXIOM_JWT_SECRET", secrets.token_hex(32))
PUBLIC_BASE_URL = os.getenv("AXIOM_PUBLIC_BASE_URL", "https://your-backend.example.com").rstrip("/")

SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
SMTP_FROM = os.getenv("SMTP_FROM", SMTP_USER or "noreply@axiomide.app")

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
GITHUB_CLIENT_ID = os.getenv("GITHUB_CLIENT_ID", "")
GITHUB_CLIENT_SECRET = os.getenv("GITHUB_CLIENT_SECRET", "")
DISCORD_CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "")
DISCORD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "")

app = FastAPI(title="Axiom IDE Backend", version="3.0.0")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                display_name TEXT NOT NULL,
                provider TEXT NOT NULL DEFAULT 'email',
                password_hash TEXT,
                password_salt TEXT,
                email_verified INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS otp_codes (
                email TEXT PRIMARY KEY,
                code TEXT NOT NULL,
                expires_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_email TEXT NOT NULL,
                project_name TEXT NOT NULL,
                payload TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            );
            """
        )


init_db()


def hash_password(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100_000).hex()


def create_token(email: str, display_name: str, provider: str) -> str:
    exp = int(time.time()) + 60 * 60 * 24 * 30
    payload = f"{email}|{display_name}|{provider}|{exp}"
    sig = hmac.new(JWT_SECRET.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload}|{sig}"


def verify_token(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token")
    token = authorization.removeprefix("Bearer ").strip()
    parts = token.split("|")
    if len(parts) != 5:
        raise HTTPException(status_code=401, detail="Malformed token")
    email, display_name, provider, exp_s, sig = parts
    expected = hmac.new(
        JWT_SECRET.encode("utf-8"),
        f"{email}|{display_name}|{provider}|{exp_s}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(sig, expected) or int(exp_s) < int(time.time()):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return {"email": email, "display_name": display_name, "provider": provider}


def send_otp_email(to_email: str, code: str) -> bool:
    if not SMTP_HOST or not SMTP_USER or not SMTP_PASS:
        return False
    msg = EmailMessage()
    msg["Subject"] = f"Axiom IDE Verification Code: {code}"
    msg["From"] = SMTP_FROM
    msg["To"] = to_email
    msg.set_content(f"Your Axiom IDE 6-digit verification code is: {code}\n\nThis code expires in 10 minutes.")
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASS)
        server.send_message(msg)
    return True


class RegisterReq(BaseModel):
    display_name: str
    email: EmailStr
    password: str


class VerifyReq(BaseModel):
    email: EmailStr
    code: str


class LoginReq(BaseModel):
    email: EmailStr
    password: str


class ResendReq(BaseModel):
    email: EmailStr


class BackupReq(BaseModel):
    project_name: str
    payload: str


@app.get("/health")
def health():
    return {"status": "ok", "service": "axiom-ide-backend", "version": "3.0.0"}


@app.post("/auth/register")
def register(req: RegisterReq):
    if len(req.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    email = req.email.lower().strip()
    salt = secrets.token_bytes(16)
    pw_hash = hash_password(req.password, salt)
    code = f"{secrets.randbelow(900000) + 100000}"
    expires = int(time.time()) + 600

    with get_db() as conn:
        existing = conn.execute("SELECT email FROM users WHERE email = ?", (email,)).fetchone()
        if existing:
            raise HTTPException(status_code=409, detail="Email already registered")
        conn.execute(
            "INSERT INTO users (email, display_name, provider, password_hash, password_salt, email_verified, created_at) VALUES (?, ?, 'email', ?, ?, 0, ?)",
            (email, req.display_name.strip(), pw_hash, salt.hex(), int(time.time())),
        )
        conn.execute(
            "INSERT OR REPLACE INTO otp_codes (email, code, expires_at) VALUES (?, ?, ?)",
            (email, code, expires),
        )

    sent = send_otp_email(email, code)
    if not sent:
        raise HTTPException(status_code=503, detail="SMTP not configured on server; set SMTP_HOST/SMTP_USER/SMTP_PASS.")
    return {"status": "verification_required", "email": email, "message": "6-digit verification code sent."}


@app.post("/auth/resend-code")
def resend_code(req: ResendReq):
    email = req.email.lower().strip()
    code = f"{secrets.randbelow(900000) + 100000}"
    expires = int(time.time()) + 600
    with get_db() as conn:
        user = conn.execute("SELECT email FROM users WHERE email = ?", (email,)).fetchone()
        if not user:
            raise HTTPException(status_code=404, detail="Account not found")
        conn.execute("INSERT OR REPLACE INTO otp_codes (email, code, expires_at) VALUES (?, ?, ?)", (email, code, expires))
    if not send_otp_email(email, code):
        raise HTTPException(status_code=503, detail="SMTP not configured on server.")
    return {"status": "sent", "email": email}


@app.post("/auth/verify-email")
def verify_email(req: VerifyReq):
    email = req.email.lower().strip()
    with get_db() as conn:
        row = conn.execute("SELECT code, expires_at FROM otp_codes WHERE email = ?", (email,)).fetchone()
        if not row or row["code"] != req.code.strip():
            raise HTTPException(status_code=400, detail="Invalid 6-digit verification code")
        if row["expires_at"] < int(time.time()):
            raise HTTPException(status_code=400, detail="Verification code expired")
        conn.execute("UPDATE users SET email_verified = 1 WHERE email = ?", (email,))
        conn.execute("DELETE FROM otp_codes WHERE email = ?", (email,))
        user = conn.execute("SELECT email, display_name, provider FROM users WHERE email = ?", (email,)).fetchone()
    token = create_token(user["email"], user["display_name"], user["provider"])
    return {"token": token, "email": user["email"], "display_name": user["display_name"], "provider": user["provider"]}


@app.post("/auth/login")
def login(req: LoginReq):
    email = req.email.lower().strip()
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if not user or not user["password_hash"] or not user["password_salt"]:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    computed = hash_password(req.password, bytes.fromhex(user["password_salt"]))
    if not hmac.compare_digest(computed, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user["email_verified"]:
        raise HTTPException(status_code=403, detail="EMAIL_NOT_VERIFIED")
    token = create_token(user["email"], user["display_name"], user["provider"])
    return {"token": token, "email": user["email"], "display_name": user["display_name"], "provider": user["provider"]}


@app.get("/auth/oauth/{provider}/start")
def oauth_start(provider: str):
    redirect_uri = f"{PUBLIC_BASE_URL}/auth/oauth/{provider}/callback"
    state = secrets.token_urlsafe(16)
    if provider == "google" and GOOGLE_CLIENT_ID:
        params = urlencode({
            "client_id": GOOGLE_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "openid email profile",
            "state": state,
        })
        return RedirectResponse(f"https://accounts.google.com/o/oauth2/v2/auth?{params}")
    if provider == "github" and GITHUB_CLIENT_ID:
        params = urlencode({
            "client_id": GITHUB_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "scope": "read:user user:email",
            "state": state,
        })
        return RedirectResponse(f"https://github.com/login/oauth/authorize?{params}")
    if provider == "discord" and DISCORD_CLIENT_ID:
        params = urlencode({
            "client_id": DISCORD_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "identify email",
            "state": state,
        })
        return RedirectResponse(f"https://discord.com/api/oauth2/authorize?{params}")
    raise HTTPException(status_code=503, detail=f"{provider} OAuth client credentials not configured on backend.")


@app.get("/auth/oauth/{provider}/callback")
async def oauth_callback(provider: str, code: str = Query(...)):
    redirect_uri = f"{PUBLIC_BASE_URL}/auth/oauth/{provider}/callback"
    async with httpx.AsyncClient(timeout=15) as client:
        if provider == "google":
            tok = (await client.post("https://oauth2.googleapis.com/token", data={
                "code": code, "client_id": GOOGLE_CLIENT_ID, "client_secret": GOOGLE_CLIENT_SECRET,
                "redirect_uri": redirect_uri, "grant_type": "authorization_code"
            })).json()
            profile = (await client.get(
                "https://www.googleapis.com/oauth2/v2/userinfo",
                headers={"Authorization": f"Bearer {tok['access_token']}"}
            )).json()
            email, name = profile["email"].lower(), profile.get("name", profile["email"])
        elif provider == "github":
            tok = (await client.post(
                "https://github.com/login/oauth/access_token",
                headers={"Accept": "application/json"},
                data={"code": code, "client_id": GITHUB_CLIENT_ID, "client_secret": GITHUB_CLIENT_SECRET, "redirect_uri": redirect_uri}
            )).json()
            headers = {"Authorization": f"Bearer {tok['access_token']}", "Accept": "application/vnd.github+json"}
            profile = (await client.get("https://api.github.com/user", headers=headers)).json()
            email = (profile.get("email") or f"{profile['login']}@users.noreply.github.com").lower()
            name = profile.get("name") or profile["login"]
        elif provider == "discord":
            tok = (await client.post("https://discord.com/api/oauth2/token", data={
                "client_id": DISCORD_CLIENT_ID, "client_secret": DISCORD_CLIENT_SECRET,
                "grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri
            })).json()
            profile = (await client.get(
                "https://discord.com/api/users/@me",
                headers={"Authorization": f"Bearer {tok['access_token']}"}
            )).json()
            email = (profile.get("email") or f"{profile['id']}@discord.local").lower()
            name = profile.get("global_name") or profile["username"]
        else:
            raise HTTPException(status_code=400, detail="Unsupported provider")

    with get_db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO users (email, display_name, provider, email_verified, created_at) VALUES (?, ?, ?, 1, ?)",
            (email, name, provider, int(time.time())),
        )
    jwt_token = create_token(email, name, provider)
    deep_link = "axiomide://auth/callback?" + urlencode({
        "token": jwt_token, "email": email, "name": name, "provider": provider
    })
    return RedirectResponse(deep_link)


@app.get("/auth/me")
def me(user=Depends(verify_token)):
    return user


@app.post("/sync/backup")
def save_backup(req: BackupReq, user=Depends(verify_token)):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO backups (user_email, project_name, payload, updated_at) VALUES (?, ?, ?, ?)",
            (user["email"], req.project_name, req.payload, int(time.time())),
        )
    return {"status": "backed_up", "project_name": req.project_name}
