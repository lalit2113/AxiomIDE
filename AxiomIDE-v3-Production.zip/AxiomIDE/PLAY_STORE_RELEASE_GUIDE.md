# Axiom IDE — Play Store & Production Publishing Guide

## 1. Deploy the Backend (Optional — Needed Only for Cloud Auth / 6-Digit Email OTP / OAuth)
1. Push the `backend/` folder to Render, Railway, or Fly.io using the included `Dockerfile`.
2. Set the environment variables listed in `backend/.env.example` (SMTP for 6-digit email verification + Google, GitHub, and Discord OAuth client IDs & secrets).
3. Register these OAuth callback URLs in each developer console:
   - Google Cloud Console: `https://<your-backend>/auth/oauth/google/callback`
   - GitHub OAuth App: `https://<your-backend>/auth/oauth/github/callback`
   - Discord Developer Portal: `https://<your-backend>/auth/oauth/discord/callback`
4. Enter your deployed HTTPS backend URL in **Axiom IDE → Settings → Auth & Sync Backend URL**.

## 2. Generate a Release Signing Keystore
```bash
keytool -genkey -v -keystore axiom-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias axiom
```
Never commit `axiom-release.jks` or `keystore.properties` to Git. In GitHub Actions, set repository secrets `AXIOM_KEYSTORE_PATH`, `AXIOM_KEYSTORE_PASSWORD`, `AXIOM_KEY_ALIAS`, and `AXIOM_KEY_PASSWORD`.

## 3. Build Release App Bundle (`.aab`)
Run the GitHub Actions workflow **Build Axiom IDE (Debug APK + Release AAB)** and download `AxiomIDE-v3-release-aab` for Google Play Console upload.

## 4. Play Store Store Listing Checklist
- Privacy Policy URL (matching the in-app **About & Privacy** disclosures: zero ads, zero trackers, optional account).
- Data Safety declaration: Email/display name collected only if user opts into backend account; secrets encrypted in Android Keystore.
- Target API Level: `targetSdk = 35` (Android 15), `minSdk = 26` (Android 8.0).
