import "./about.scss";
import Logo from "components/logo";
import Page from "components/page";
import Reactive from "html-tag-js/reactive";
import actionStack from "lib/actionStack";

export default function AboutInclude() {
	const $page = Page(strings.about.capitalize());
	const webviewVersionName = Reactive("N/A");
	const webviewPackageName = Reactive("N/A");

	$page.classList.add("about-us");
	$page.body = (
		<main id="about-page" className="main scroll">
			<Logo />

			<div className="version-info">
				<h1 className="version-title">Axiom Code</h1>
				<div className="version-number">
					Version {BuildInfo.version} ({BuildInfo.versionCode})
				</div>
			</div>

			<div className="info-section">
				<div className="info-item">
					<div className="info-item-icon">
						<span className="icon googlechrome"></span>
					</div>
					<div className="info-item-text">
						WebView {webviewVersionName}
						<div className="info-item-subtext">{webviewPackageName}</div>
					</div>
				</div>
				<div className="info-item">
					<div className="info-item-icon">
						<span className="icon code"></span>
					</div>
					<div className="info-item-text">
						100% Free & Open Source
						<div className="info-item-subtext">
							Zero ads, zero paywalls, zero locked features.
						</div>
					</div>
				</div>
				<div className="info-item">
					<div className="info-item-icon">
						<span className="icon info"></span>
					</div>
					<div className="info-item-text">
						MIT License Attribution
						<div className="info-item-subtext">
							Built on the open-source Acode engine under the MIT License.
						</div>
					</div>
				</div>
			</div>
		</main>
	);

	if (typeof system?.getWebviewInfo === "function") {
		system.getWebviewInfo(
			(res) => {
				webviewVersionName.value = res.versionName || "N/A";
				webviewPackageName.value = res.packageName || "N/A";
			},
			() => {},
		);
	}

	actionStack.push({
		id: "about",
		action: $page.hide,
	});

	$page.onhide = function () {
		actionStack.remove("about");
	};

	app.append($page);
}
