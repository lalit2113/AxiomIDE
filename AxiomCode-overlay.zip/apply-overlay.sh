#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-Acode-main}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -d "$TARGET" ]; then
  echo "Error: Target directory '$TARGET' not found." >&2
  exit 1
fi

rm -f "$TARGET/src/lib/acode.js"

find "$TARGET/res" "$TARGET/www" -type f -name '*ic_acode_*' 2>/dev/null | while IFS= read -r f; do
  dir="$(dirname "$f")"
  base="$(basename "$f")"
  mv -f "$f" "$dir/${base//ic_acode_/ic_axiom_}"
done

cp -rf "$SCRIPT_DIR/overlay/." "$TARGET/"
echo "Axiom Code overlay applied cleanly to $TARGET"
