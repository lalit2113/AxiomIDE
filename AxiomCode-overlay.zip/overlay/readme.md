# Axiom Code - Code Editor for Android

<p align="center">
  <img src='res/logo_1.png' width='250'>
</p>

[![](https://img.shields.io/endpoint?logo=telegram&label=Axiom%20Code&style=flat&url=https%3A%2F%2Faxiomcode.app%2Fapi%2Ftelegram-members-count)](https://t.me/axiomcode_app) [![](https://dcbadge.limes.pink/api/server/https://discord.gg/vVxVWYUAWD?style=flat)](https://discord.gg/vVxVWYUAWD)

## • Overview

Welcome to Axiom Code - a powerful and versatile code editing tool designed specifically for Android devices. Whether you're working on HTML, CSS, JavaScript, or other programming languages, Axiom Code empowers you to code on-the-go with confidence.

## • Features

- Edit and create websites, and instantly preview them in a browser.
- Seamlessly modify source files for various languages like Python, Java, JavaScript, and more.
- Built-in javascript console
- S/FTP and SSH terminal integration
- Built-in terminal(Alpine)
- Enjoy multi-language editing support with easy management tools.
- Enjoy a large collections of community plugins to enhance your coding experience.

## • Installation

You can get Axiom Code from popular platforms:

[<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" alt="Get it on Google Play" height="60">](https://play.google.com/store/apps/details?id=com.axiomcode.app.free) [<img src="https://fdroid.gitlab.io/artwork/badge/get-it-on.png" alt="Get it on F-Droid" height="60"/>](https://www.f-droid.org/packages/com.axiomcode.app/)

## • Project Structure

<pre>
Axiom Code/
|
|- src/   - Core code and language files
|
|- www/   - Public documents, compiled files, and HTML templates
|
|- utils/ - CLI tools for building, string manipulation, and more
|
|- codemirror-lsp-client/ - Git submodule providing @codemirror/lsp-client (clone with --recurse-submodules)
</pre>

## • Multi-language Support

Enhance Axiom Code's capabilities by adding new languages easily. Just create a file with the language code (e.g., en-us for English) in [`src/lang/`](https://github.com/Axiom-Code/AxiomCode/tree/main/src/lang) and include it in [`src/lib/lang.js`](https://github.com/Axiom-Code/AxiomCode/blob/main/src/lib/lang.js). Manage strings across languages effortlessly using utility commands:

```shell
pnpm run lang add
pnpm run lang remove
pnpm run lang search
pnpm run lang update
```

## • Contributing & Building the Application

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed instructions.

## • Contributors

<a href="https://github.com/Axiom-Code/AxiomCode/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=Axiom-Code/AxiomCode" />
</a>

## • Developing a Plugin for Axiom Code

For comprehensive documentation on creating plugins for Axiom Code, visit the [repository](https://github.com/Axiom-Code/axiomcode-plugin).

For plugin development information, refer to: [Axiom Code Plugin Documentation](https://docs.axiomcode.app/)

## Star History

<a href="https://star-history.com/#Axiom-Code/AxiomCode&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=Axiom-Code/AxiomCode&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=Axiom-Code/AxiomCode&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=Axiom-Code/AxiomCode&type=Date" />
 </picture>
</a>
