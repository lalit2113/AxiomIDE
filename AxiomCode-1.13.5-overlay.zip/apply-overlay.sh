#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-Acode-1.13.5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
rm -f "$TARGET/src/lib/acode.js"
find "$TARGET" -type f -name '*ic_acode_*' -print0 | while IFS= read -r -d '' f; do
  dir="$(dirname "$f")"
  base="$(basename "$f")"
  mv -f "$f" "$dir/${base//ic_acode_/ic_axiom_}"
done || true
cp -rf "$SCRIPT_DIR/overlay/." "$TARGET/"
echo "Axiom Code 1.13.5 overlay applied cleanly to $TARGET"
