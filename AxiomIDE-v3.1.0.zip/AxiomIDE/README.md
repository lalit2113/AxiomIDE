# Axiom IDE (Android) — v3.1.0 Open Source

Axiom IDE is a 100% free, open-source, offline-first Android coding IDE with zero accounts, zero paywalls, and zero ads.

## Highlights
- **Acode-Style Editor**: Slide-out Project File Tree drawer, Command Palette, Go to Line, Auto-Indent & Auto-Close Brackets, Encoding Picker, Save All, Unsaved Changes guard, Find & Replace with match counter & case sensitivity, 20-key Extra Keys bar pinned above the keyboard, custom snippets, and open-tab diff.
- **Projects & Files**: 10 starter templates, full local CRUD, Zip Slip–safe ZIP import/export, and Android Storage Access Framework folder import.
- **Real Shell & Execution**: Multi-session `/system/bin/sh` terminal, Termux launcher, live WebView HTML/CSS/JS preview with JS console logs, and optional HTTPS Piston remote runner.
- **19 Built-In Local Dev Tools**: JSON/XML/SQL formatters, Base64, URL, Hashes, UUID, Regex, JWT, Markdown, Color Picker, Timestamp, Cron, HTTPS API & Headers tester, Diff, Text Compare, and Image-to-Base64.
- **Optional Integrations**: Live GitHub repo sync via Keystore-encrypted PAT, local JSON extension manifests, and optional BYOK HTTPS AI assistant.

## Build APK via GitHub Actions
Upload `AxiomIDE-v3.1.0.zip` to your GitHub repo and run **Build & Release Axiom IDE APK** from the **Actions** tab.
