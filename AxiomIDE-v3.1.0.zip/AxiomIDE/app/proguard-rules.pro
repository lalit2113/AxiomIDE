# Axiom IDE ProGuard rules
-keep class com.axiom.ide.core.data.db.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
