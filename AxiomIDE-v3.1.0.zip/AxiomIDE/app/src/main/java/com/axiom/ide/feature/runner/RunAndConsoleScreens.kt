package com.axiom.ide.feature.runner

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.data.SettingsRepository
import com.axiom.ide.core.util.LanguageRegistry
import com.axiom.ide.feature.terminal.TerminalEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

@Composable
fun RunAndConsoleScreen(
    targetFile: File?,
    settings: IdeSettings,
    settingsRepo: SettingsRepository,
    onOpenWebPreview: (File) -> Unit
) {
    val scope = rememberCoroutineScope()
    val httpClient = remember {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    var runnerUrl by remember(settings.remoteRunnerUrl) { mutableStateOf(settings.remoteRunnerUrl) }
    var stdinInput by remember { mutableStateOf("") }
    var outputLog by remember { mutableStateOf("Ready. Open a file in the Editor and tap Run.") }
    var isRunning by remember { mutableStateOf(false) }
    var showTrustConfirm by remember { mutableStateOf(false) }

    val lang = targetFile?.let { LanguageRegistry.detectForFileName(it.name) }

    fun executeTargetFile() {
        val file = targetFile ?: return
        when (lang?.id) {
            "html" -> onOpenWebPreview(file)
            "bash" -> {
                isRunning = true
                outputLog = "Executing ${file.name} via /system/bin/sh (20s timeout)..."
                scope.launch {
                    val res = TerminalEngine.executeCommand("sh \"${file.absolutePath}\"", file.parent ?: "/")
                    outputLog = buildString {
                        appendLine(res.output.ifBlank { "(no output)" })
                        appendLine("\nExit code: ${res.exitCode}")
                    }
                    isRunning = false
                }
            }
            else -> {
                val pistonLang = lang?.pistonLanguage
                val cleanUrl = runnerUrl.trim().trimEnd('/')
                if (pistonLang == null) {
                    outputLog = "${lang?.displayName ?: "This file"} does not have a direct execution target."
                    return
                }
                if (!cleanUrl.startsWith("https://")) {
                    outputLog = buildString {
                        appendLine("No HTTPS Remote Execution Backend configured for ${lang.displayName}.")
                        appendLine("Options:")
                        appendLine("1. Run locally inside Termux (python, node, clang, kotlinc, rustc, go).")
                        appendLine("2. Enter a self-hosted HTTPS Piston-compatible /api/v2/execute endpoint above and save.")
                    }
                    return
                }
                isRunning = true
                outputLog = "Sending ${file.name} ($pistonLang) to $cleanUrl..."
                scope.launch {
                    outputLog = withContext(Dispatchers.IO) {
                        runCatching {
                            val sourceCode = file.readText()
                            val payload = JSONObject().apply {
                                put("language", pistonLang)
                                put("version", "*")
                                put("stdin", stdinInput)
                                put("files", JSONArray().put(JSONObject().apply {
                                    put("name", file.name)
                                    put("content", sourceCode)
                                }))
                            }
                            val req = Request.Builder()
                                .url(cleanUrl)
                                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                                .build()
                            httpClient.newCall(req).execute().use { resp ->
                                val raw = resp.body?.string().orEmpty()
                                if (!resp.isSuccessful) "HTTP ${resp.code}: $raw"
                                else {
                                    val json = JSONObject(raw)
                                    val run = json.optJSONObject("run")
                                    val compile = json.optJSONObject("compile")
                                    buildString {
                                        if (compile != null && compile.optString("output").isNotBlank()) {
                                            appendLine("=== COMPILE ===")
                                            appendLine(compile.optString("output"))
                                        }
                                        if (run != null) {
                                            appendLine("=== OUTPUT ===")
                                            appendLine(run.optString("output").ifBlank { "(empty)" })
                                            appendLine("Exit code: ${run.optInt("code", 0)}")
                                        } else {
                                            append(raw)
                                        }
                                    }
                                }
                            }
                        }.getOrElse { "Remote runner error: ${it.message}" }
                    }
                    isRunning = false
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Run & Output Console", style = MaterialTheme.typography.titleLarge)

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Target: ${targetFile?.name ?: "None"}", style = MaterialTheme.typography.titleMedium)
                Text("Language: ${lang?.displayName ?: "-"}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    lang?.localExecutionNote ?: "Open a file from Projects or Editor first.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        OutlinedTextField(
            value = runnerUrl,
            onValueChange = { runnerUrl = it },
            label = { Text("Optional HTTPS Remote Runner URL (Piston API)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = stdinInput,
            onValueChange = { stdinInput = it },
            label = { Text("Standard Input (stdin)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = targetFile != null && !isRunning,
                onClick = { showTrustConfirm = true }
            ) { Text(if (isRunning) "Running..." else "Run File") }

            OutlinedButton(onClick = {
                scope.launch { settingsRepo.setRemoteRunnerUrl(runnerUrl) }
                outputLog = "Saved remote runner URL."
            }) { Text("Save URL") }

            OutlinedButton(onClick = { outputLog = "" }) { Text("Clear") }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
                .padding(12.dp)
        ) {
            Text(outputLog, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
        }
    }

    if (showTrustConfirm) {
        AlertDialog(
            onDismissRequest = { showTrustConfirm = false },
            title = { Text("Run ${targetFile?.name}?") },
            text = { Text("Confirm you trust this code before executing it. Axiom never exposes your saved API keys or tokens to executed programs.") },
            confirmButton = {
                Button(onClick = {
                    showTrustConfirm = false
                    executeTargetFile()
                }) { Text("Run") }
            },
            dismissButton = { TextButton(onClick = { showTrustConfirm = false }) { Text("Cancel") } }
        )
    }
}
