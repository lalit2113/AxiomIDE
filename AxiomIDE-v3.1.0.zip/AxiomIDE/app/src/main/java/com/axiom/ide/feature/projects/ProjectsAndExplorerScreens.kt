package com.axiom.ide.feature.projects

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.axiom.ide.core.data.db.ProjectEntity
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ProjectsScreen(
    projects: List<ProjectEntity>,
    repository: ProjectRepository,
    onOpenExplorer: (ProjectEntity) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var searchQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val zipImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val created = repository.importZipProject(uri, "ImportedZip")
                    statusMessage = "Imported ${created.name}"
                }.onFailure { statusMessage = "ZIP import failed: ${it.message}" }
            }
        }
    }

    val safFolderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val created = repository.importSafFolder(uri)
                    statusMessage = "Imported folder ${created.name}"
                }.onFailure { statusMessage = "Folder import failed: ${it.message}" }
            }
        }
    }

    val filtered by remember(projects, searchQuery) {
        derivedStateOf {
            if (searchQuery.isBlank()) projects
            else projects.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                    it.primaryLanguage.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { showCreateDialog = true }, modifier = Modifier.weight(1f)) { Text("New") }
            OutlinedButton(onClick = { zipImportLauncher.launch(arrayOf("application/zip", "*/*")) }, modifier = Modifier.weight(1f)) { Text("ZIP") }
            OutlinedButton(onClick = { safFolderLauncher.launch(null) }, modifier = Modifier.weight(1f)) { Text("Folder") }
        }

        statusMessage?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }

        if (filtered.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "No projects found. Create a new project or import an existing ZIP archive or folder.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(filtered, key = { it.id }) { project ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth().clickable { onOpenExplorer(project) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${project.primaryLanguage} • ${project.template}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row {
                                IconButton(onClick = { scope.launch { repository.toggleFavorite(project) } }) {
                                    Icon(
                                        imageVector = if (project.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                                        contentDescription = "Favorite"
                                    )
                                }
                                IconButton(onClick = {
                                    scope.launch {
                                        repository.duplicateProject(project)
                                        statusMessage = "Duplicated ${project.name}"
                                    }
                                }) { Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate") }
                                IconButton(onClick = {
                                    scope.launch {
                                        runCatching {
                                            val zipFile = repository.exportProjectToZip(project)
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", zipFile)
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/zip"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Export ${project.name}.zip"))
                                        }.onFailure { statusMessage = "Export error: ${it.message}" }
                                    }
                                }) { Icon(Icons.Default.Share, contentDescription = "Export ZIP") }
                                IconButton(onClick = {
                                    scope.launch {
                                        repository.deleteProject(project)
                                        statusMessage = "Deleted ${project.name}"
                                    }
                                }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateProjectDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, template ->
                showCreateDialog = false
                scope.launch {
                    val created = repository.createProject(name, template)
                    onOpenExplorer(created)
                }
            }
        )
    }
}

@Composable
private fun CreateProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (String, ProjectTemplate) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedTemplate by remember { mutableStateOf(ProjectTemplates.all.first()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Name") },
                    singleLine = true
                )
                Text("Template", style = MaterialTheme.typography.titleMedium)
                LazyColumn(modifier = Modifier.height(220.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(ProjectTemplates.all, key = { it.id }) { tpl ->
                        val isSelected = tpl.id == selectedTemplate.id
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth().clickable { selectedTemplate = tpl }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(tpl.name, style = MaterialTheme.typography.titleMedium)
                                Text(tpl.description, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = name.isNotBlank(), onClick = { onCreate(name, selectedTemplate) }) { Text("Create") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun FileExplorerScreen(
    project: ProjectEntity?,
    onOpenFile: (File, String) -> Unit,
    onOpenWebPreview: (File) -> Unit,
    onOpenTerminalAt: (String) -> Unit
) {
    if (project == null) {
        Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
            Text("No project selected. Open a project from the Projects tab.", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }

    var currentDir by remember(project.path) { mutableStateOf(File(project.path)) }
    var refreshTrigger by remember { mutableIntStateOf(0) }
    var showNewEntryDialog by remember { mutableStateOf(false) }
    var newEntryName by remember { mutableStateOf("") }
    var createAsFolder by remember { mutableStateOf(false) }

    val entries = remember(currentDir.absolutePath, refreshTrigger) {
        currentDir.listFiles()?.sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }) ?: emptyList()
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(project.name, style = MaterialTheme.typography.titleLarge)
        Text(currentDir.absolutePath, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (currentDir.absolutePath != project.path) {
                OutlinedButton(onClick = { currentDir.parentFile?.let { currentDir = it } }) { Text("Up") }
            }
            Button(onClick = { createAsFolder = false; showNewEntryDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text(" File")
            }
            OutlinedButton(onClick = { createAsFolder = true; showNewEntryDialog = true }) { Text("+ Folder") }
            OutlinedButton(onClick = { onOpenTerminalAt(currentDir.absolutePath) }) { Text("Shell") }
        }

        val indexHtml = File(currentDir, "index.html")
        if (indexHtml.exists()) {
            OutlinedButton(onClick = { onOpenWebPreview(indexHtml) }, modifier = Modifier.fillMaxWidth()) {
                Text("Live Web Preview (index.html)")
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
            items(entries, key = { it.absolutePath }) { file ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth().clickable {
                        if (file.isDirectory) currentDir = file else onOpenFile(file, project.name)
                    }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(
                                imageVector = if (file.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                                contentDescription = null,
                                tint = if (file.isDirectory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Column {
                                Text(file.name, style = MaterialTheme.typography.titleMedium)
                                if (file.isFile) {
                                    Text("${file.length()} bytes", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        IconButton(onClick = {
                            file.deleteRecursively()
                            refreshTrigger++
                        }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }

    if (showNewEntryDialog) {
        AlertDialog(
            onDismissRequest = { showNewEntryDialog = false },
            title = { Text(if (createAsFolder) "New Folder" else "New File") },
            text = {
                OutlinedTextField(
                    value = newEntryName,
                    onValueChange = { newEntryName = it },
                    label = { Text(if (createAsFolder) "Folder name" else "File name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(enabled = newEntryName.isNotBlank(), onClick = {
                    val clean = newEntryName.trim()
                    val target = File(currentDir, clean)
                    if (createAsFolder) target.mkdirs() else {
                        target.parentFile?.mkdirs()
                        target.createNewFile()
                    }
                    refreshTrigger++
                    newEntryName = ""
                    showNewEntryDialog = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewEntryDialog = false }) { Text("Cancel") } }
        )
    }
}
