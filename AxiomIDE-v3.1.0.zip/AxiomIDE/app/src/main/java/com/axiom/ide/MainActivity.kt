package com.axiom.ide

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.designsystem.AxiomTheme
import com.axiom.ide.navigation.AxiomRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as AxiomApp
        setContent {
            val settings by app.settingsRepository.settingsFlow.collectAsState(initial = IdeSettings())
            AxiomTheme(
                themeMode = settings.themeMode,
                accentPreset = settings.accentPreset
            ) {
                AxiomRoot(app = app, settings = settings)
            }
        }
    }
}
