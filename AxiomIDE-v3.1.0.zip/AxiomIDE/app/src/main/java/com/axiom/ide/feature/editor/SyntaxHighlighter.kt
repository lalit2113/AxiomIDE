package com.axiom.ide.feature.editor

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import com.axiom.ide.core.designsystem.SyntaxColors

object SyntaxHighlighter {

    private val commonKeywords = setOf(
        "fun", "val", "var", "class", "object", "interface", "return", "if", "else", "when", "for", "while",
        "do", "try", "catch", "finally", "import", "package", "private", "public", "protected", "internal",
        "override", "suspend", "data", "sealed", "enum", "true", "false", "null", "this", "super", "new",
        "function", "const", "let", "async", "await", "export", "default", "from", "switch", "case", "break",
        "continue", "def", "lambda", "with", "as", "pass", "yield", "elif", "None", "True", "False", "and",
        "or", "not", "in", "is", "static", "void", "int", "long", "double", "float", "boolean", "char",
        "string", "struct", "impl", "fn", "pub", "mod", "use", "match", "mut", "SELECT", "FROM", "WHERE",
        "INSERT", "UPDATE", "DELETE", "CREATE", "TABLE", "JOIN", "GROUP", "ORDER", "BY", "LIMIT",
        "echo", "fi", "then", "esac", "done", "include", "namespace", "using", "template", "typename"
    )

    private val tokenRegex = Regex(
        """(//[^\n]*|#[^\n]*|/\*[\s\S]*?\*/|<!--[\s\S]*?-->)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(@[A-Za-z_][A-Za-z0-9_]*)|\b(\d+(?:\.\d+)?)\b|\b([A-Za-z_][A-Za-z0-9_]*)\b"""
    )

    fun highlight(code: String, isDark: Boolean): AnnotatedString {
        if (code.length > 50_000) return AnnotatedString(code)

        val keywordColor = if (isDark) SyntaxColors.keywordDark else SyntaxColors.keywordLight
        val stringColor = if (isDark) SyntaxColors.stringDark else SyntaxColors.stringLight
        val commentColor = if (isDark) SyntaxColors.commentDark else SyntaxColors.commentLight
        val numberColor = if (isDark) SyntaxColors.numberDark else SyntaxColors.numberLight
        val typeColor = if (isDark) SyntaxColors.typeDark else SyntaxColors.typeLight
        val annotationColor = if (isDark) SyntaxColors.annotationDark else SyntaxColors.annotationLight

        return buildAnnotatedString {
            append(code)
            for (match in tokenRegex.findAll(code)) {
                val range = match.range
                when {
                    match.groups[1] != null -> addStyle(SpanStyle(color = commentColor), range.first, range.last + 1)
                    match.groups[2] != null -> addStyle(SpanStyle(color = stringColor), range.first, range.last + 1)
                    match.groups[3] != null -> addStyle(SpanStyle(color = annotationColor), range.first, range.last + 1)
                    match.groups[4] != null -> addStyle(SpanStyle(color = numberColor), range.first, range.last + 1)
                    match.groups[5] != null -> {
                        val word = match.groups[5]!!.value
                        if (word in commonKeywords || word.uppercase() in commonKeywords) {
                            addStyle(SpanStyle(color = keywordColor, fontWeight = FontWeight.Medium), range.first, range.last + 1)
                        } else if (word.first().isUpperCase() && word.any { it.isLowerCase() }) {
                            addStyle(SpanStyle(color = typeColor), range.first, range.last + 1)
                        }
                    }
                }
            }
        }
    }
}
