package com.axiom.ide.feature.extensions

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.axiom.ide.core.data.db.AxiomDatabase
import com.axiom.ide.core.data.db.ExtensionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun ExtensionsScreen(db: AxiomDatabase) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val extensions by db.extensionDao().observeAll().collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }

    val manifestPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) {
                    runCatching {
                        val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: throw IllegalStateException("Cannot read manifest file")
                        val json = JSONObject(raw)
                        val id = json.getString("id").trim()
                        val name = json.getString("name").trim()
                        val version = json.optString("version", "1.0.0")
                        val author = json.optString("author", "Local Package")
                        val category = json.optString("category", "Utilities")
                        val description = json.optString("description", "")
                        val permissions = json.optString("permissions", "editor:readonly")
                        if (permissions.contains("exec", ignoreCase = true) || permissions.contains("shell", ignoreCase = true)) {
                            throw SecurityException("Blocked untrusted extension requesting shell/exec permission.")
                        }
                        val entity = ExtensionEntity(
                            id = id,
                            name = name,
                            author = author,
                            version = version,
                            category = category,
                            description = description,
                            permissions = permissions,
                            manifestJson = raw,
                            isInstalled = true,
                            isEnabled = true
                        )
                        db.extensionDao().upsert(entity)
                        "Installed extension: $name v$version"
                    }
                }
                status = res.getOrElse { "Import rejected: ${it.message}" }
            }
        }
    }

    val filtered = extensions.filter {
        query.isBlank() ||
            it.name.contains(query, ignoreCase = true) ||
            it.category.contains(query, ignoreCase = true)
    }

    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Local Extensions", style = MaterialTheme.typography.titleLarge)
        Text(
            "Import verified JSON extension manifests (fields: id, name, version, author, category, description, permissions). Arbitrary shell execution permissions are blocked.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { manifestPicker.launch(arrayOf("application/json", "*/*")) }) {
                Text("Import Manifest (.json)")
            }
        }

        status?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }

        if (extensions.isNotEmpty()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Filter") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        if (filtered.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "No extensions installed yet. Tap Import Manifest (.json) to load a local extension package.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(filtered, key = { it.id }) { ext ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ext.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${ext.category} • v${ext.version} • ${ext.author}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = ext.isEnabled,
                                    onCheckedChange = { enabled ->
                                        scope.launch { db.extensionDao().update(ext.copy(isEnabled = enabled)) }
                                    }
                                )
                            }
                            if (ext.description.isNotBlank()) Text(ext.description, style = MaterialTheme.typography.bodyMedium)
                            Text("Permissions: ${ext.permissions}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            OutlinedButton(onClick = { scope.launch { db.extensionDao().delete(ext) } }) { Text("Uninstall") }
                        }
                    }
                }
            }
        }
    }
}
