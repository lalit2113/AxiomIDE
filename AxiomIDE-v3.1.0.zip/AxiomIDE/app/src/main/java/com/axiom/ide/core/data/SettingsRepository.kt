package com.axiom.ide.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.axiom.ide.core.designsystem.AccentPreset
import com.axiom.ide.core.designsystem.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "axiom_ide_settings")

data class IdeSettings(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val accentPreset: AccentPreset = AccentPreset.SKY,
    val editorFontSizeSp: Int = 14,
    val terminalFontSizeSp: Int = 13,
    val tabSize: Int = 4,
    val showLineNumbers: Boolean = true,
    val wordWrap: Boolean = false,
    val autoSaveEnabled: Boolean = true,
    val autoSaveIntervalSec: Int = 10,
    val autoCloseBrackets: Boolean = true,
    val defaultShell: String = "/system/bin/sh",
    val onboardingCompleted: Boolean = false,
    val remoteRunnerUrl: String = "",
    val aiBaseUrl: String = "",
    val aiModelName: String = ""
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_PRESET = stringPreferencesKey("accent_preset")
        val EDITOR_FONT_SIZE = intPreferencesKey("editor_font_size")
        val TERMINAL_FONT_SIZE = intPreferencesKey("terminal_font_size")
        val TAB_SIZE = intPreferencesKey("tab_size")
        val SHOW_LINE_NUMBERS = booleanPreferencesKey("show_line_numbers")
        val WORD_WRAP = booleanPreferencesKey("word_wrap")
        val AUTO_SAVE = booleanPreferencesKey("auto_save")
        val AUTO_SAVE_INTERVAL = intPreferencesKey("auto_save_interval")
        val AUTO_CLOSE_BRACKETS = booleanPreferencesKey("auto_close_brackets")
        val DEFAULT_SHELL = stringPreferencesKey("default_shell")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val REMOTE_RUNNER_URL = stringPreferencesKey("remote_runner_url")
        val AI_BASE_URL = stringPreferencesKey("ai_base_url")
        val AI_MODEL_NAME = stringPreferencesKey("ai_model_name")
    }

    val settingsFlow: Flow<IdeSettings> = context.dataStore.data.map { prefs ->
        IdeSettings(
            themeMode = AppThemeMode.fromName(prefs[Keys.THEME_MODE] ?: AppThemeMode.DARK.name),
            accentPreset = AccentPreset.fromName(prefs[Keys.ACCENT_PRESET] ?: AccentPreset.SKY.name),
            editorFontSizeSp = prefs[Keys.EDITOR_FONT_SIZE] ?: 14,
            terminalFontSizeSp = prefs[Keys.TERMINAL_FONT_SIZE] ?: 13,
            tabSize = prefs[Keys.TAB_SIZE] ?: 4,
            showLineNumbers = prefs[Keys.SHOW_LINE_NUMBERS] ?: true,
            wordWrap = prefs[Keys.WORD_WRAP] ?: false,
            autoSaveEnabled = prefs[Keys.AUTO_SAVE] ?: true,
            autoSaveIntervalSec = prefs[Keys.AUTO_SAVE_INTERVAL] ?: 10,
            autoCloseBrackets = prefs[Keys.AUTO_CLOSE_BRACKETS] ?: true,
            defaultShell = prefs[Keys.DEFAULT_SHELL] ?: "/system/bin/sh",
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            remoteRunnerUrl = prefs[Keys.REMOTE_RUNNER_URL] ?: "",
            aiBaseUrl = prefs[Keys.AI_BASE_URL] ?: "",
            aiModelName = prefs[Keys.AI_MODEL_NAME] ?: ""
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) { context.dataStore.edit { it[Keys.THEME_MODE] = mode.name } }
    suspend fun setAccentPreset(preset: AccentPreset) { context.dataStore.edit { it[Keys.ACCENT_PRESET] = preset.name } }
    suspend fun setEditorFontSize(sizeSp: Int) { context.dataStore.edit { it[Keys.EDITOR_FONT_SIZE] = sizeSp.coerceIn(10, 26) } }
    suspend fun setTerminalFontSize(sizeSp: Int) { context.dataStore.edit { it[Keys.TERMINAL_FONT_SIZE] = sizeSp.coerceIn(10, 24) } }
    suspend fun setShowLineNumbers(enabled: Boolean) { context.dataStore.edit { it[Keys.SHOW_LINE_NUMBERS] = enabled } }
    suspend fun setWordWrap(enabled: Boolean) { context.dataStore.edit { it[Keys.WORD_WRAP] = enabled } }
    suspend fun setAutoSave(enabled: Boolean) { context.dataStore.edit { it[Keys.AUTO_SAVE] = enabled } }
    suspend fun setAutoCloseBrackets(enabled: Boolean) { context.dataStore.edit { it[Keys.AUTO_CLOSE_BRACKETS] = enabled } }
    suspend fun setOnboardingCompleted(completed: Boolean) { context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed } }
    suspend fun setRemoteRunnerUrl(url: String) { context.dataStore.edit { it[Keys.REMOTE_RUNNER_URL] = url.trim() } }
    suspend fun setAiConfig(baseUrl: String, model: String) {
        context.dataStore.edit {
            it[Keys.AI_BASE_URL] = baseUrl.trim()
            it[Keys.AI_MODEL_NAME] = model.trim()
        }
    }
}
