package com.axiom.ide.feature.tools

import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

enum class DevToolType(val title: String) {
    JSON_FORMAT("JSON Format"),
    JSON_VALIDATE("JSON Validate"),
    XML_FORMAT("XML Format"),
    BASE64("Base64"),
    URL_CODEC("URL Codec"),
    HASH("Hash"),
    UUID("UUID"),
    REGEX("Regex"),
    JWT("JWT Decode"),
    MARKDOWN("Markdown"),
    COLOR("Color Picker"),
    TIMESTAMP("Timestamp"),
    CRON("Cron Helper"),
    API_TESTER("API Tester"),
    HTTP_HEADERS("HTTP Headers"),
    DIFF("Diff Checker"),
    SQL_FORMAT("SQL Format"),
    TEXT_COMPARE("Text Compare"),
    IMAGE_BASE64("Image→Base64")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DevToolsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTool by remember { mutableStateOf(DevToolType.JSON_FORMAT) }
    var inputA by remember { mutableStateOf("") }
    var inputB by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var red by remember { mutableFloatStateOf(56f) }
    var green by remember { mutableFloatStateOf(189f) }
    var blue by remember { mutableFloatStateOf(248f) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                output = "data:image/*;base64,${Base64.encodeToString(bytes, Base64.NO_WRAP)}"
            }.onFailure { output = "Failed to read image: ${it.message}" }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Developer Toolbox", style = MaterialTheme.typography.titleLarge)

        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DevToolType.entries.forEach { tool ->
                FilterChip(
                    selected = selectedTool == tool,
                    onClick = { selectedTool = tool; output = "" },
                    label = { Text(tool.title) }
                )
            }
        }

        when (selectedTool) {
            DevToolType.COLOR -> {
                val color = Color(red.toInt(), green.toInt(), blue.toInt())
                val hex = "#%02X%02X%02X".format(red.toInt(), green.toInt(), blue.toInt())
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Box(modifier = Modifier.size(64.dp).background(color, MaterialTheme.shapes.medium))
                    Column {
                        Text("HEX: $hex", fontFamily = FontFamily.Monospace)
                        Text("RGB: rgb(${red.toInt()}, ${green.toInt()}, ${blue.toInt()})", fontFamily = FontFamily.Monospace)
                    }
                }
                Text("Red: ${red.toInt()}")
                Slider(value = red, onValueChange = { red = it }, valueRange = 0f..255f)
                Text("Green: ${green.toInt()}")
                Slider(value = green, onValueChange = { green = it }, valueRange = 0f..255f)
                Text("Blue: ${blue.toInt()}")
                Slider(value = blue, onValueChange = { blue = it }, valueRange = 0f..255f)
            }
            DevToolType.IMAGE_BASE64 -> {
                Button(onClick = { imagePicker.launch("image/*") }) { Text("Pick Image to Encode") }
            }
            else -> {
                OutlinedTextField(
                    value = inputA,
                    onValueChange = { inputA = it },
                    label = {
                        Text(
                            when (selectedTool) {
                                DevToolType.REGEX -> "Regex Pattern"
                                DevToolType.API_TESTER, DevToolType.HTTP_HEADERS -> "HTTPS URL"
                                DevToolType.CRON -> "Cron Expression (5 fields)"
                                DevToolType.DIFF, DevToolType.TEXT_COMPARE -> "Left Text"
                                else -> "Input"
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                if (selectedTool in setOf(DevToolType.REGEX, DevToolType.DIFF, DevToolType.TEXT_COMPARE, DevToolType.API_TESTER)) {
                    OutlinedTextField(
                        value = inputB,
                        onValueChange = { inputB = it },
                        label = {
                            Text(
                                when (selectedTool) {
                                    DevToolType.REGEX -> "Test String"
                                    DevToolType.API_TESTER -> "Optional JSON Body (POST)"
                                    else -> "Right Text"
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        when (selectedTool) {
                            DevToolType.JSON_FORMAT -> output = DevToolsEngine.formatJson(inputA).getOrElse { "Error: ${it.message}" }
                            DevToolType.JSON_VALIDATE -> output = DevToolsEngine.validateJson(inputA)
                            DevToolType.XML_FORMAT -> output = DevToolsEngine.formatXml(inputA).getOrElse { "Error: ${it.message}" }
                            DevToolType.BASE64 -> output = DevToolsEngine.encodeBase64(inputA)
                            DevToolType.URL_CODEC -> output = DevToolsEngine.encodeUrl(inputA)
                            DevToolType.HASH -> output = listOf("MD5", "SHA-1", "SHA-256", "SHA-512")
                                .joinToString("\n") { "$it:\n${DevToolsEngine.hashText(inputA, it)}" }
                            DevToolType.UUID -> output = DevToolsEngine.generateUuids(5)
                            DevToolType.REGEX -> output = DevToolsEngine.testRegex(inputA, inputB).getOrElse { "Error: ${it.message}" }
                            DevToolType.JWT -> output = DevToolsEngine.decodeJwt(inputA).getOrElse { "Error: ${it.message}" }
                            DevToolType.MARKDOWN -> output = inputA
                            DevToolType.TIMESTAMP -> output = DevToolsEngine.convertTimestamp(inputA)
                            DevToolType.CRON -> output = DevToolsEngine.explainCron(inputA)
                            DevToolType.SQL_FORMAT -> output = DevToolsEngine.formatSql(inputA)
                            DevToolType.DIFF -> output = DevToolsEngine.diffLines(inputA, inputB)
                            DevToolType.TEXT_COMPARE -> output = DevToolsEngine.compareTextStats(inputA, inputB)
                            DevToolType.API_TESTER -> scope.launch {
                                output = "Sending HTTPS request..."
                                val method = if (inputB.isBlank()) "GET" else "POST"
                                output = DevToolsEngine.executeHttpRequest(method, inputA, inputB).getOrElse { "Error: ${it.message}" }
                            }
                            DevToolType.HTTP_HEADERS -> scope.launch {
                                output = "Fetching headers..."
                                output = DevToolsEngine.executeHttpRequest("HEAD", inputA, headersOnly = true).getOrElse { "Error: ${it.message}" }
                            }
                            else -> Unit
                        }
                    }) {
                        Text(if (selectedTool == DevToolType.BASE64 || selectedTool == DevToolType.URL_CODEC) "Encode" else "Run")
                    }

                    if (selectedTool == DevToolType.BASE64 || selectedTool == DevToolType.URL_CODEC) {
                        OutlinedButton(onClick = {
                            output = if (selectedTool == DevToolType.BASE64) {
                                DevToolsEngine.decodeBase64(inputA).getOrElse { "Decode error: ${it.message}" }
                            } else {
                                DevToolsEngine.decodeUrl(inputA).getOrElse { "Decode error: ${it.message}" }
                            }
                        }) { Text("Decode") }
                    }
                }
            }
        }

        if (output.isNotEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = output,
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
