package com.axiom.ide.feature.projects

data class ProjectTemplate(
    val id: String,
    val name: String,
    val primaryLanguage: String,
    val description: String,
    val files: Map<String, String>
)

object ProjectTemplates {
    val all: List<ProjectTemplate> = listOf(
        ProjectTemplate(
            id = "web_basic",
            name = "HTML / CSS / JS Website",
            primaryLanguage = "HTML",
            description = "Responsive starter ready for live WebView preview.",
            files = mapOf(
                "index.html" to """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Axiom Web Project</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <main class="card">
    <h1>Axiom Web Starter</h1>
    <p id="status">Edit index.html, style.css, or app.js and open Web Preview.</p>
    <button id="countBtn">Clicks: 0</button>
  </main>
  <script src="app.js"></script>
</body>
</html>
""",
                "style.css" to """body {
  font-family: system-ui, -apple-system, sans-serif;
  background: #0b0f17;
  color: #e6edf3;
  margin: 0;
  padding: 24px;
}
.card {
  max-width: 480px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #2b3548;
  border-radius: 12px;
  background: #131926;
}
button {
  background: #38bdf8;
  color: #04131e;
  border: none;
  padding: 10px 16px;
  border-radius: 8px;
  font-weight: 600;
}
""",
                "app.js" to """let count = 0;
const btn = document.getElementById('countBtn');
btn.addEventListener('click', () => {
  count += 1;
  btn.textContent = 'Clicks: ' + count;
  console.log('Button clicked:', count);
});
"""
            )
        ),
        ProjectTemplate(
            id = "react_app",
            name = "React Application",
            primaryLanguage = "JSX / React",
            description = "React component scaffold with package.json.",
            files = mapOf(
                "package.json" to """{
  "name": "axiom-react-app",
  "version": "1.0.0",
  "private": true,
  "scripts": { "dev": "vite", "build": "vite build" },
  "dependencies": { "react": "^18.3.1", "react-dom": "^18.3.1" }
}
""",
                "src/App.jsx" to """import React, { useState } from 'react';

export default function App() {
  const [count, setCount] = useState(0);
  return (
    <main style={{ padding: 24, fontFamily: 'sans-serif' }}>
      <h1>React Starter</h1>
      <button onClick={() => setCount((c) => c + 1)}>Count: {count}</button>
    </main>
  );
}
"""
            )
        ),
        ProjectTemplate(
            id = "python_project",
            name = "Python Project",
            primaryLanguage = "Python",
            description = "Python 3 entry point and requirements.txt.",
            files = mapOf(
                "main.py" to """def greet(name: str) -> str:
    return f"Hello, {name}!"

if __name__ == "__main__":
    print(greet("Developer"))
""",
                "requirements.txt" to ""
            )
        ),
        ProjectTemplate(
            id = "java_project",
            name = "Java Project",
            primaryLanguage = "Java",
            description = "Standard Java Main class layout.",
            files = mapOf(
                "src/Main.java" to """public class Main {
    public static void main(String[] args) {
        System.out.println("Java project ready");
    }
}
"""
            )
        ),
        ProjectTemplate(
            id = "kotlin_project",
            name = "Kotlin Project",
            primaryLanguage = "Kotlin",
            description = "Kotlin main entry point.",
            files = mapOf(
                "src/Main.kt" to """fun main() {
    println("Kotlin project ready")
}
"""
            )
        ),
        ProjectTemplate(
            id = "cpp_project",
            name = "C / C++ Project",
            primaryLanguage = "C++",
            description = "C++17 starter with Makefile.",
            files = mapOf(
                "src/main.cpp" to """#include <iostream>

int main() {
    std::cout << "C++ project ready" << std::endl;
    return 0;
}
""",
                "Makefile" to "all:\n\tg++ -std=c++17 src/main.cpp -o app\n"
            )
        ),
        ProjectTemplate(
            id = "php_project",
            name = "PHP Project",
            primaryLanguage = "PHP",
            description = "PHP starter script.",
            files = mapOf("index.php" to "<?php\necho \"PHP project ready\\n\";\n?>\n")
        ),
        ProjectTemplate(
            id = "node_project",
            name = "Node.js Project",
            primaryLanguage = "JavaScript",
            description = "Node.js CLI/server scaffold.",
            files = mapOf(
                "package.json" to "{\n  \"name\": \"axiom-node\",\n  \"version\": \"1.0.0\",\n  \"main\": \"index.js\"\n}\n",
                "index.js" to "console.log('Node.js project ready');\n"
            )
        ),
        ProjectTemplate(
            id = "flutter_project",
            name = "Flutter Project",
            primaryLanguage = "Dart / Flutter",
            description = "Flutter lib/main.dart and pubspec.yaml scaffold.",
            files = mapOf(
                "pubspec.yaml" to "name: axiom_flutter_app\nversion: 1.0.0+1\nenvironment:\n  sdk: \">=3.0.0 <4.0.0\"\ndependencies:\n  flutter:\n    sdk: flutter\n",
                "lib/main.dart" to "import 'package:flutter/material.dart';\nvoid main() => runApp(const MaterialApp(home: Scaffold(body: Center(child: Text('Flutter Starter')))));\n"
            )
        ),
        ProjectTemplate(
            id = "empty_project",
            name = "Empty Project",
            primaryLanguage = "Plain Text",
            description = "Blank project directory with a README.md.",
            files = mapOf("README.md" to "# New Project\n")
        )
    )
}
