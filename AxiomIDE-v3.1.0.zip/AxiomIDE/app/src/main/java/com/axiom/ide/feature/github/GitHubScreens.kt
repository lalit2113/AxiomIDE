package com.axiom.ide.feature.github

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.axiom.ide.core.data.SecureStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class GitHubRepoItem(
    val name: String,
    val fullName: String,
    val description: String,
    val language: String,
    val stars: Int,
    val defaultBranch: String
)

@Composable
fun GitHubScreen(secureStorage: SecureStorage) {
    val scope = rememberCoroutineScope()
    val client = remember { OkHttpClient() }

    var tokenInput by remember { mutableStateOf(secureStorage.getSecret(SecureStorage.KEY_GITHUB_TOKEN).orEmpty()) }
    var username by remember { mutableStateOf(secureStorage.getSecret(SecureStorage.KEY_GITHUB_USERNAME)) }
    var repos by remember { mutableStateOf<List<GitHubRepoItem>>(emptyList()) }
    var status by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    suspend fun fetchLiveGitHubData(token: String) = withContext(Dispatchers.IO) {
        val userReq = Request.Builder()
            .url("https://api.github.com/user")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .build()
        val login = client.newCall(userReq).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            JSONObject(resp.body?.string().orEmpty()).optString("login")
        }

        val reposReq = Request.Builder()
            .url("https://api.github.com/user/repos?sort=updated&per_page=30")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .build()
        val list = client.newCall(reposReq).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            val arr = JSONArray(resp.body?.string().orEmpty())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                GitHubRepoItem(
                    name = obj.optString("name"),
                    fullName = obj.optString("full_name"),
                    description = obj.optString("description").ifBlank { "No description" },
                    language = obj.optString("language").ifBlank { "Unknown" },
                    stars = obj.optInt("stargazers_count"),
                    defaultBranch = obj.optString("default_branch", "main")
                )
            }
        }
        login to list
    }

    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("GitHub", style = MaterialTheme.typography.titleLarge)
        Text(
            "Connect with a GitHub Personal Access Token (stored encrypted in Android Keystore) to sync your live repositories.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = tokenInput,
            onValueChange = { tokenInput = it },
            label = { Text("GitHub Personal Access Token") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = !isLoading && tokenInput.isNotBlank(),
                onClick = {
                    isLoading = true
                    status = "Connecting to api.github.com..."
                    scope.launch {
                        runCatching {
                            val (login, fetched) = fetchLiveGitHubData(tokenInput.trim())
                            secureStorage.putSecret(SecureStorage.KEY_GITHUB_TOKEN, tokenInput.trim())
                            secureStorage.putSecret(SecureStorage.KEY_GITHUB_USERNAME, login)
                            username = login
                            repos = fetched
                            status = "Connected as @$login (${fetched.size} repos)"
                        }.onFailure { status = "Connection failed: ${it.message}" }
                        isLoading = false
                    }
                }
            ) { Text(if (isLoading) "Syncing..." else "Connect & Sync") }

            if (username != null) {
                OutlinedButton(onClick = {
                    secureStorage.removeSecret(SecureStorage.KEY_GITHUB_TOKEN)
                    secureStorage.removeSecret(SecureStorage.KEY_GITHUB_USERNAME)
                    username = null; tokenInput = ""; repos = emptyList()
                    status = "Disconnected."
                }) { Text("Disconnect") }
            }
        }

        status?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(repos, key = { it.fullName }) { repo ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(repo.fullName, style = MaterialTheme.typography.titleMedium)
                        Text(repo.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${repo.language} • ★ ${repo.stars} • ${repo.defaultBranch}", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
