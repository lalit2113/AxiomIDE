package com.axiom.ide.feature.projects

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.axiom.ide.core.data.db.AxiomDatabase
import com.axiom.ide.core.data.db.ProjectEntity
import com.axiom.ide.core.data.db.RecentFileEntity
import com.axiom.ide.core.util.LanguageRegistry
import com.axiom.ide.core.util.ZipUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class ProjectRepository(
    private val context: Context,
    private val db: AxiomDatabase
) {
    val projectsRoot: File
        get() = File(context.filesDir, "projects").apply { mkdirs() }

    val exportsDir: File
        get() = File(context.cacheDir, "exports").apply { mkdirs() }

    fun observeProjects(): Flow<List<ProjectEntity>> = db.projectDao().observeAll()

    fun observeRecentFiles(): Flow<List<RecentFileEntity>> = db.recentFileDao().observeRecent()

    suspend fun createProject(name: String, template: ProjectTemplate): ProjectEntity = withContext(Dispatchers.IO) {
        val cleanName = name.trim().replace(Regex("[^a-zA-Z0-9._ -]"), "_").ifBlank { "UntitledProject" }
        var dir = File(projectsRoot, cleanName)
        var suffix = 1
        while (dir.exists()) {
            dir = File(projectsRoot, "${cleanName}_$suffix")
            suffix++
        }
        dir.mkdirs()

        template.files.forEach { (relPath, content) ->
            val target = File(dir, relPath)
            target.parentFile?.mkdirs()
            target.writeText(content)
        }

        val entity = ProjectEntity(
            name = dir.name,
            path = dir.absolutePath,
            template = template.name,
            primaryLanguage = template.primaryLanguage
        )
        val id = db.projectDao().insert(entity)
        entity.copy(id = id)
    }

    suspend fun duplicateProject(project: ProjectEntity): ProjectEntity = withContext(Dispatchers.IO) {
        val src = File(project.path)
        var copyName = "${project.name}_copy"
        var dst = File(projectsRoot, copyName)
        var idx = 2
        while (dst.exists()) {
            copyName = "${project.name}_copy_$idx"
            dst = File(projectsRoot, copyName)
            idx++
        }
        if (src.exists()) src.copyRecursively(dst, overwrite = true) else dst.mkdirs()
        val entity = project.copy(
            id = 0,
            name = copyName,
            path = dst.absolutePath,
            createdAt = System.currentTimeMillis(),
            lastOpenedAt = System.currentTimeMillis()
        )
        val id = db.projectDao().insert(entity)
        entity.copy(id = id)
    }

    suspend fun deleteProject(project: ProjectEntity) = withContext(Dispatchers.IO) {
        File(project.path).deleteRecursively()
        db.projectDao().delete(project)
    }

    suspend fun toggleFavorite(project: ProjectEntity) = withContext(Dispatchers.IO) {
        db.projectDao().update(project.copy(isFavorite = !project.isFavorite))
    }

    suspend fun touchProject(project: ProjectEntity) = withContext(Dispatchers.IO) {
        db.projectDao().update(project.copy(lastOpenedAt = System.currentTimeMillis()))
    }

    suspend fun recordRecentFile(file: File, projectName: String) = withContext(Dispatchers.IO) {
        val lang = LanguageRegistry.detectForFileName(file.name).displayName
        db.recentFileDao().upsert(
            RecentFileEntity(
                filePath = file.absolutePath,
                fileName = file.name,
                projectName = projectName,
                language = lang,
                lastOpenedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun importZipProject(zipUri: Uri, projectName: String): ProjectEntity = withContext(Dispatchers.IO) {
        val clean = projectName.trim().replace(Regex("[^a-zA-Z0-9._ -]"), "_").ifBlank { "ImportedProject" }
        var dir = File(projectsRoot, clean)
        var idx = 1
        while (dir.exists()) {
            dir = File(projectsRoot, "${clean}_$idx")
            idx++
        }
        context.contentResolver.openInputStream(zipUri)?.use { stream ->
            ZipUtils.unzipSafely(stream, dir)
        } ?: throw IllegalStateException("Could not open ZIP file stream")

        val firstFile = dir.walkTopDown().firstOrNull { it.isFile }
        val lang = firstFile?.let { LanguageRegistry.detectForFileName(it.name).displayName } ?: "Plain Text"
        val entity = ProjectEntity(
            name = dir.name,
            path = dir.absolutePath,
            template = "Imported ZIP",
            primaryLanguage = lang
        )
        val id = db.projectDao().insert(entity)
        entity.copy(id = id)
    }

    suspend fun importSafFolder(treeUri: Uri): ProjectEntity = withContext(Dispatchers.IO) {
        val docRoot = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Unable to access selected folder")
        val cleanName = (docRoot.name ?: "ExternalProject").replace(Regex("[^a-zA-Z0-9._ -]"), "_")
        var dir = File(projectsRoot, cleanName)
        var idx = 1
        while (dir.exists()) {
            dir = File(projectsRoot, "${cleanName}_$idx")
            idx++
        }
        dir.mkdirs()

        fun copyDocTree(doc: DocumentFile, targetDir: File) {
            doc.listFiles().forEach { child ->
                val childName = child.name ?: return@forEach
                if (child.isDirectory) {
                    copyDocTree(child, File(targetDir, childName).apply { mkdirs() })
                } else if (child.isFile) {
                    val outFile = File(targetDir, childName)
                    context.contentResolver.openInputStream(child.uri)?.use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }
        copyDocTree(docRoot, dir)

        val firstFile = dir.walkTopDown().firstOrNull { it.isFile }
        val lang = firstFile?.let { LanguageRegistry.detectForFileName(it.name).displayName } ?: "Plain Text"
        val entity = ProjectEntity(
            name = dir.name,
            path = dir.absolutePath,
            template = "SAF Folder",
            primaryLanguage = lang
        )
        val id = db.projectDao().insert(entity)
        entity.copy(id = id)
    }

    suspend fun exportProjectToZip(project: ProjectEntity): File = withContext(Dispatchers.IO) {
        val outZip = File(exportsDir, "${project.name}.zip")
        ZipUtils.zipDirectory(File(project.path), outZip)
        outZip
    }

    suspend fun calculateStorageBytes(): Long = withContext(Dispatchers.IO) {
        projectsRoot.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}
