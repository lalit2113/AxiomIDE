package com.axiom.ide.core.util

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ZipUtils {

    fun zipDirectory(sourceDir: File, outputZip: File) {
        outputZip.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(outputZip))).use { zos ->
            val basePath = sourceDir.canonicalPath
            sourceDir.walkTopDown().forEach { file ->
                if (file == sourceDir) return@forEach
                val relativePath = file.canonicalPath.removePrefix(basePath).trimStart(File.separatorChar)
                if (file.isDirectory) {
                    zos.putNextEntry(ZipEntry("$relativePath/"))
                    zos.closeEntry()
                } else {
                    zos.putNextEntry(ZipEntry(relativePath))
                    FileInputStream(file).use { fis -> fis.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
    }

    fun unzipSafely(inputStream: InputStream, targetDir: File): Int {
        targetDir.mkdirs()
        val canonicalTarget = targetDir.canonicalPath + File.separator
        var extractedCount = 0
        ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (!outFile.canonicalPath.startsWith(canonicalTarget)) {
                    throw SecurityException("Blocked unsafe ZIP entry path: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos -> zis.copyTo(fos) }
                    extractedCount++
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return extractedCount
    }
}
