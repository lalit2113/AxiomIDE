package com.axiom.ide.feature.preview

import android.annotation.SuppressLint
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebPreviewScreen(targetHtmlFile: File?) {
    var desktopMode by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableIntStateOf(0) }
    val consoleLogs = remember { mutableStateListOf<String>() }

    if (targetHtmlFile == null || !targetHtmlFile.exists()) {
        Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
            Text("No HTML File Selected", style = MaterialTheme.typography.titleLarge)
            Text(
                "Open an HTML project and tap Live Web Preview or Run on an .html file.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val baseUrl = "file://${targetHtmlFile.parentFile?.absolutePath}/"
    val htmlContent = remember(targetHtmlFile.absolutePath, reloadKey) {
        runCatching { targetHtmlFile.readText() }.getOrElse { "<h1>Unable to read file</h1>" }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { reloadKey++ }) { Text("Refresh") }
            OutlinedButton(onClick = { desktopMode = !desktopMode; reloadKey++ }) {
                Text(if (desktopMode) "Desktop" else "Mobile")
            }
            OutlinedButton(onClick = { consoleLogs.clear() }) { Text("Clear Log") }
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = true
                    settings.useWideViewPort = desktopMode
                    settings.loadWithOverviewMode = desktopMode
                    webViewClient = WebViewClient()
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(msg: ConsoleMessage): Boolean {
                            consoleLogs.add("[${msg.messageLevel()}] ${msg.message()} (L${msg.lineNumber()})")
                            return true
                        }
                    }
                    loadDataWithBaseURL(baseUrl, htmlContent, "text/html", "UTF-8", null)
                }
            },
            update = { webView ->
                webView.settings.useWideViewPort = desktopMode
                webView.settings.loadWithOverviewMode = desktopMode
                webView.loadDataWithBaseURL(baseUrl, htmlContent, "text/html", "UTF-8", null)
            }
        )

        Text("Console (${consoleLogs.size})", style = MaterialTheme.typography.labelMedium)
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.small)
                .padding(8.dp)
        ) {
            items(consoleLogs) { log ->
                Text(log, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
