package com.axiom.ide.feature.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.data.SecureStorage
import com.axiom.ide.core.data.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiAssistantScreen(
    settings: IdeSettings,
    settingsRepo: SettingsRepository,
    secureStorage: SecureStorage
) {
    val scope = rememberCoroutineScope()
    val client = remember { OkHttpClient() }

    var baseUrl by remember(settings.aiBaseUrl) { mutableStateOf(settings.aiBaseUrl) }
    var model by remember(settings.aiModelName) { mutableStateOf(settings.aiModelName) }
    var apiKey by remember { mutableStateOf(secureStorage.getSecret(SecureStorage.KEY_AI_API_KEY).orEmpty()) }
    var prompt by remember { mutableStateOf("") }
    var responseText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val quickActions = listOf("Explain code:", "Fix error:", "Refactor:", "Write tests:", "Build regex:")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("AI Assistant (Optional BYOK)", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = baseUrl,
            onValueChange = { baseUrl = it },
            label = { Text("HTTPS OpenAI-Compatible Base URL") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = model,
            onValueChange = { model = it },
            label = { Text("Model Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it },
            label = { Text("API Key (Encrypted in Android Keystore)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(onClick = {
            scope.launch {
                settingsRepo.setAiConfig(baseUrl, model)
                if (apiKey.isNotBlank()) secureStorage.putSecret(SecureStorage.KEY_AI_API_KEY, apiKey.trim())
                responseText = "Provider configuration saved securely."
            }
        }) { Text("Save Config") }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            quickActions.forEach { prefix ->
                AssistChip(onClick = { prompt = "$prefix\n" }, label = { Text(prefix.removeSuffix(":")) })
            }
        }

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Prompt") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        Row {
            Button(
                enabled = !isLoading && prompt.isNotBlank(),
                onClick = {
                    val key = apiKey.trim()
                    val cleanBase = baseUrl.trim().trimEnd('/')
                    if (!cleanBase.startsWith("https://")) {
                        responseText = "Enter a valid HTTPS endpoint first."
                        return@Button
                    }
                    if (key.isEmpty() || model.isBlank()) {
                        responseText = "Enter both a model name and your API key first."
                        return@Button
                    }
                    isLoading = true
                    responseText = "Contacting $cleanBase..."
                    scope.launch {
                        responseText = withContext(Dispatchers.IO) {
                            runCatching {
                                val payload = JSONObject().apply {
                                    put("model", model.trim())
                                    put("messages", JSONArray().put(JSONObject().apply {
                                        put("role", "user")
                                        put("content", prompt)
                                    }))
                                }
                                val req = Request.Builder()
                                    .url("$cleanBase/chat/completions")
                                    .header("Authorization", "Bearer $key")
                                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                                    .build()
                                client.newCall(req).execute().use { resp ->
                                    val body = resp.body?.string().orEmpty()
                                    if (!resp.isSuccessful) "HTTP ${resp.code}: $body"
                                    else JSONObject(body)
                                        .getJSONArray("choices")
                                        .getJSONObject(0)
                                        .getJSONObject("message")
                                        .getString("content")
                                }
                            }.getOrElse { "Request failed: ${it.message}" }
                        }
                        isLoading = false
                    }
                }
            ) { Text(if (isLoading) "Sending..." else "Send") }
        }

        if (responseText.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
                    .padding(12.dp)
            ) {
                Text(responseText, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
