package com.axiom.ide.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AxiomTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    accentPreset: AccentPreset = AccentPreset.SKY,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.DARK -> darkColorScheme(
            primary = accentPreset.primary,
            onPrimary = Color(0xFF04131E),
            secondary = accentPreset.secondary,
            onSecondary = Color.White,
            background = DarkBackground,
            onBackground = DarkOnSurface,
            surface = DarkSurface,
            onSurface = DarkOnSurface,
            surfaceVariant = DarkSurfaceVariant,
            onSurfaceVariant = DarkOnSurfaceVariant,
            outline = DarkOutline,
            error = Color(0xFFF85149),
            onError = Color.White
        )
        AppThemeMode.OLED -> darkColorScheme(
            primary = accentPreset.primary,
            onPrimary = Color(0xFF04131E),
            secondary = accentPreset.secondary,
            onSecondary = Color.White,
            background = OledBackground,
            onBackground = DarkOnSurface,
            surface = OledSurface,
            onSurface = DarkOnSurface,
            surfaceVariant = OledSurfaceVariant,
            onSurfaceVariant = DarkOnSurfaceVariant,
            outline = DarkOutline,
            error = Color(0xFFF85149),
            onError = Color.White
        )
        AppThemeMode.LIGHT -> lightColorScheme(
            primary = accentPreset.secondary,
            onPrimary = Color.White,
            secondary = accentPreset.primary,
            onSecondary = Color(0xFF04131E),
            background = LightBackground,
            onBackground = LightOnSurface,
            surface = LightSurface,
            onSurface = LightOnSurface,
            surfaceVariant = LightSurfaceVariant,
            onSurfaceVariant = LightOnSurfaceVariant,
            outline = LightOutline,
            error = Color(0xFFCF222E),
            onError = Color.White
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AxiomTypography,
        shapes = AxiomShapes,
        content = content
    )
}
