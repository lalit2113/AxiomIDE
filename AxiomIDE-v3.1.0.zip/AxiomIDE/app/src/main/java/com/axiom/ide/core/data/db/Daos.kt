package com.axiom.ide.core.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY isFavorite DESC, lastOpenedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: ProjectEntity): Long

    @Update
    suspend fun update(project: ProjectEntity)

    @Delete
    suspend fun delete(project: ProjectEntity)
}

@Dao
interface RecentFileDao {
    @Query("SELECT * FROM recent_files ORDER BY lastOpenedAt DESC LIMIT 20")
    fun observeRecent(): Flow<List<RecentFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: RecentFileEntity)
}

@Dao
interface SnippetDao {
    @Query("SELECT * FROM snippets ORDER BY language ASC, title ASC")
    fun observeAll(): Flow<List<SnippetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(snippet: SnippetEntity): Long

    @Delete
    suspend fun delete(snippet: SnippetEntity)
}

@Dao
interface ExtensionDao {
    @Query("SELECT * FROM extensions ORDER BY isEnabled DESC, name ASC")
    fun observeAll(): Flow<List<ExtensionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ExtensionEntity)

    @Update
    suspend fun update(item: ExtensionEntity)

    @Delete
    suspend fun delete(item: ExtensionEntity)
}
