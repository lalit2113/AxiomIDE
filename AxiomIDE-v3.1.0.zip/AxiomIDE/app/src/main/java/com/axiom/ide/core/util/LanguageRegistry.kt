package com.axiom.ide.core.util

data class LanguageSpec(
    val id: String,
    val displayName: String,
    val extensions: Set<String>,
    val lineComment: String,
    val pistonLanguage: String?,
    val localExecutionNote: String
)

object LanguageRegistry {

    val languages: List<LanguageSpec> = listOf(
        LanguageSpec("html", "HTML", setOf("html", "htm"), "<!--", null, "Live preview in WebView"),
        LanguageSpec("css", "CSS", setOf("css", "scss", "less"), "/*", null, "Live preview in WebView"),
        LanguageSpec("javascript", "JavaScript", setOf("js", "mjs", "cjs"), "//", "javascript", "WebView JS, Termux Node.js, or Remote Runner"),
        LanguageSpec("typescript", "TypeScript", setOf("ts"), "//", "typescript", "Termux ts-node or Remote Runner"),
        LanguageSpec("jsx", "JSX / React", setOf("jsx"), "//", null, "Termux Node.js bundler"),
        LanguageSpec("tsx", "TSX / React", setOf("tsx"), "//", null, "Termux Node.js bundler"),
        LanguageSpec("python", "Python", setOf("py"), "#", "python", "Termux Python or Remote Runner"),
        LanguageSpec("java", "Java", setOf("java"), "//", "java", "Termux OpenJDK or Remote Runner"),
        LanguageSpec("kotlin", "Kotlin", setOf("kt", "kts"), "//", "kotlin", "Termux kotlinc or Remote Runner"),
        LanguageSpec("c", "C", setOf("c", "h"), "//", "c", "Termux clang/gcc or Remote Runner"),
        LanguageSpec("cpp", "C++", setOf("cpp", "cc", "cxx", "hpp"), "//", "c++", "Termux clang++/g++ or Remote Runner"),
        LanguageSpec("csharp", "C#", setOf("cs"), "//", "csharp", "Remote Runner"),
        LanguageSpec("go", "Go", setOf("go"), "//", "go", "Termux golang or Remote Runner"),
        LanguageSpec("rust", "Rust", setOf("rs"), "//", "rust", "Termux rustc or Remote Runner"),
        LanguageSpec("php", "PHP", setOf("php"), "//", "php", "Termux php or Remote Runner"),
        LanguageSpec("ruby", "Ruby", setOf("rb"), "#", "ruby", "Termux ruby or Remote Runner"),
        LanguageSpec("swift", "Swift", setOf("swift"), "//", "swift", "Remote Runner"),
        LanguageSpec("dart", "Dart / Flutter", setOf("dart"), "//", "dart", "External Dart/Flutter SDK or Remote Runner"),
        LanguageSpec("sql", "SQL", setOf("sql"), "--", "sqlite3", "Local formatting or Remote SQLite Runner"),
        LanguageSpec("bash", "Bash / Shell", setOf("sh", "bash", "zsh"), "#", "bash", "Direct execution via Android /system/bin/sh"),
        LanguageSpec("powershell", "PowerShell", setOf("ps1"), "#", null, "Syntax editing locally"),
        LanguageSpec("json", "JSON", setOf("json"), "//", null, "Local validation & formatting in Toolbox"),
        LanguageSpec("xml", "XML", setOf("xml", "svg"), "<!--", null, "Local formatting in Toolbox"),
        LanguageSpec("yaml", "YAML", setOf("yml", "yaml"), "#", null, "Syntax editing locally"),
        LanguageSpec("toml", "TOML", setOf("toml"), "#", null, "Syntax editing locally"),
        LanguageSpec("markdown", "Markdown", setOf("md", "markdown"), "<!--", null, "Live preview in Toolbox"),
        LanguageSpec("lua", "Lua", setOf("lua"), "--", "lua", "Termux lua or Remote Runner"),
        LanguageSpec("r", "R", setOf("r"), "#", "r", "Remote Runner"),
        LanguageSpec("perl", "Perl", setOf("pl", "pm"), "#", "perl", "Termux perl or Remote Runner"),
        LanguageSpec("scala", "Scala", setOf("scala"), "//", "scala", "Remote Runner"),
        LanguageSpec("haskell", "Haskell", setOf("hs"), "--", "haskell", "Remote Runner"),
        LanguageSpec("assembly", "Assembly", setOf("asm", "s"), ";", null, "Syntax editing locally"),
        LanguageSpec("solidity", "Solidity", setOf("sol"), "//", null, "Syntax editing locally"),
        LanguageSpec("graphql", "GraphQL", setOf("graphql", "gql"), "#", null, "Syntax editing locally"),
        LanguageSpec("vue", "Vue", setOf("vue"), "<!--", null, "Syntax editing locally"),
        LanguageSpec("svelte", "Svelte", setOf("svelte"), "<!--", null, "Syntax editing locally"),
        LanguageSpec("dockerfile", "Dockerfile", setOf("dockerfile"), "#", null, "Syntax editing locally"),
        LanguageSpec("makefile", "Makefile", setOf("mk", "makefile"), "#", null, "Syntax editing locally"),
        LanguageSpec("latex", "LaTeX", setOf("tex"), "%", null, "Syntax editing locally"),
        LanguageSpec("plaintext", "Plain Text", setOf("txt", "log", "env", "ini"), "#", null, "Plain text file")
    )

    fun detectForFileName(fileName: String): LanguageSpec {
        val lower = fileName.lowercase()
        if (lower == "dockerfile") return languages.first { it.id == "dockerfile" }
        if (lower == "makefile") return languages.first { it.id == "makefile" }
        val ext = lower.substringAfterLast('.', "")
        return languages.firstOrNull { ext in it.extensions } ?: languages.last()
    }
}
