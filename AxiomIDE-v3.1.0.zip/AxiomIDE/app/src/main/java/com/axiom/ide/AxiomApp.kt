package com.axiom.ide

import android.app.Application
import com.axiom.ide.core.data.SecureStorage
import com.axiom.ide.core.data.SettingsRepository
import com.axiom.ide.core.data.db.AxiomDatabase
import com.axiom.ide.feature.editor.EditorWorkspaceController
import com.axiom.ide.feature.projects.ProjectRepository

class AxiomApp : Application() {
    lateinit var database: AxiomDatabase
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var secureStorage: SecureStorage
        private set
    lateinit var projectRepository: ProjectRepository
        private set
    val editorController: EditorWorkspaceController = EditorWorkspaceController()

    override fun onCreate() {
        super.onCreate()
        database = AxiomDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        secureStorage = SecureStorage(this)
        projectRepository = ProjectRepository(this, database)
    }
}
