package com.axiom.ide.feature.tools

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.StringReader
import java.io.StringWriter
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.stream.StreamResult
import javax.xml.transform.stream.StreamSource

object DevToolsEngine {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    fun formatJson(input: String): Result<String> = runCatching {
        val trimmed = input.trim()
        when {
            trimmed.startsWith("{") -> JSONObject(trimmed).toString(2)
            trimmed.startsWith("[") -> JSONArray(trimmed).toString(2)
            else -> throw IllegalArgumentException("JSON must start with '{' or '['")
        }
    }

    fun validateJson(input: String): String = formatJson(input).fold(
        onSuccess = { "Valid JSON (${it.lines().size} formatted lines)" },
        onFailure = { "Invalid JSON: ${it.message}" }
    )

    fun formatXml(input: String): Result<String> = runCatching {
        val transformer = TransformerFactory.newInstance().newTransformer().apply {
            setOutputProperty(OutputKeys.INDENT, "yes")
            setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2")
        }
        val writer = StringWriter()
        transformer.transform(StreamSource(StringReader(input.trim())), StreamResult(writer))
        writer.toString()
    }

    fun encodeBase64(input: String): String =
        Base64.encodeToString(input.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

    fun decodeBase64(input: String): Result<String> = runCatching {
        String(Base64.decode(input.trim(), Base64.DEFAULT), Charsets.UTF_8)
    }

    fun encodeUrl(input: String): String = URLEncoder.encode(input, "UTF-8")

    fun decodeUrl(input: String): Result<String> = runCatching { URLDecoder.decode(input, "UTF-8") }

    fun hashText(input: String, algorithm: String): String {
        val digest = MessageDigest.getInstance(algorithm).digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun generateUuids(count: Int = 5): String =
        (1..count.coerceIn(1, 20)).joinToString("\n") { UUID.randomUUID().toString() }

    fun testRegex(pattern: String, sample: String): Result<String> = runCatching {
        val matches = Regex(pattern).findAll(sample).toList()
        if (matches.isEmpty()) "No matches found."
        else buildString {
            appendLine("${matches.size} match(es):")
            matches.forEachIndexed { idx, m -> appendLine("#${idx + 1} [${m.range.first}..${m.range.last}]: ${m.value}") }
        }.trimEnd()
    }

    fun decodeJwt(token: String): Result<String> = runCatching {
        val parts = token.trim().split(".")
        if (parts.size < 2) throw IllegalArgumentException("JWT requires header and payload separated by '.'")
        fun decodePart(p: String): String {
            val bytes = Base64.decode(p, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val raw = String(bytes, Charsets.UTF_8)
            return formatJson(raw).getOrDefault(raw)
        }
        buildString {
            appendLine("=== HEADER ===").appendLine(decodePart(parts[0]))
            appendLine("\n=== PAYLOAD ===").appendLine(decodePart(parts[1]))
            if (parts.size >= 3) appendLine("\n=== SIGNATURE ===").append(parts[2])
        }
    }

    fun convertTimestamp(input: String): String {
        val trimmed = input.trim()
        val epoch = trimmed.toLongOrNull()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z").withZone(ZoneId.systemDefault())
        return if (epoch != null) {
            val instant = if (trimmed.length > 11) Instant.ofEpochMilli(epoch) else Instant.ofEpochSecond(epoch)
            "ISO-8601 UTC: $instant\nLocal Time:   ${formatter.format(instant)}"
        } else {
            runCatching {
                val instant = Instant.parse(trimmed)
                "Epoch Seconds: ${instant.epochSecond}\nEpoch Millis:  ${instant.toEpochMilli()}"
            }.getOrElse {
                val now = Instant.now()
                "Now (UTC):     $now\nEpoch Seconds: ${now.epochSecond}\nEpoch Millis:  ${now.toEpochMilli()}"
            }
        }
    }

    fun explainCron(expr: String): String {
        val parts = expr.trim().split(Regex("\\s+"))
        if (parts.size != 5) return "Enter 5 fields: <min> <hour> <day-of-month> <month> <day-of-week>"
        return "Minute: ${parts[0]}\nHour: ${parts[1]}\nDay of Month: ${parts[2]}\nMonth: ${parts[3]}\nDay of Week: ${parts[4]}"
    }

    fun formatSql(sql: String): String {
        val keywords = listOf("SELECT", "FROM", "WHERE", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "JOIN", "GROUP BY", "ORDER BY", "HAVING", "LIMIT", "VALUES", "SET")
        var formatted = sql.trim().replace(Regex("\\s+"), " ")
        keywords.forEach { kw -> formatted = formatted.replace(Regex("(?i)\\b$kw\\b"), "\n$kw") }
        return formatted.trim()
    }

    fun diffLines(left: String, right: String): String {
        val a = left.lines()
        val b = right.lines()
        val max = maxOf(a.size, b.size)
        return buildString {
            var diffs = 0
            for (i in 0 until max) {
                val l = a.getOrNull(i)
                val r = b.getOrNull(i)
                if (l == r) appendLine("  ${i + 1}: ${l.orEmpty()}")
                else {
                    diffs++
                    if (l != null) appendLine("- ${i + 1}: $l")
                    if (r != null) appendLine("+ ${i + 1}: $r")
                }
            }
            append("\n$diffs differing line(s)")
        }
    }

    fun compareTextStats(left: String, right: String): String {
        val lWords = left.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.size
        val rWords = right.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.size
        return buildString {
            appendLine("Identical: ${left == right}")
            appendLine("Left:  ${left.length} chars, $lWords words, ${left.lines().size} lines")
            appendLine("Right: ${right.length} chars, $rWords words, ${right.lines().size} lines")
            appendLine()
            append(diffLines(left, right))
        }
    }

    suspend fun executeHttpRequest(
        method: String,
        url: String,
        bodyText: String = "",
        headersOnly: Boolean = false
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanUrl = url.trim()
            if (!cleanUrl.startsWith("https://")) {
                throw SecurityException("Axiom IDE enforces HTTPS-only API requests.")
            }
            val builder = Request.Builder().url(cleanUrl)
            when (method.uppercase()) {
                "POST", "PUT", "PATCH" -> builder.method(method.uppercase(), bodyText.toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull()))
                "DELETE" -> builder.delete()
                "HEAD" -> builder.head()
                else -> builder.get()
            }
            httpClient.newCall(builder.build()).execute().use { resp ->
                buildString {
                    appendLine("HTTP ${resp.code} ${resp.message}")
                    appendLine("=== HEADERS ===")
                    resp.headers.forEach { (k, v) -> appendLine("$k: $v") }
                    if (!headersOnly) {
                        appendLine("\n=== BODY ===")
                        val raw = resp.body?.string().orEmpty().take(12_000)
                        append(formatJson(raw).getOrDefault(raw))
                    }
                }
            }
        }
    }
}
