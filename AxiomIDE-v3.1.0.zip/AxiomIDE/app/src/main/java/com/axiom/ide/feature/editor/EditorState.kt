package com.axiom.ide.feature.editor

import com.axiom.ide.core.util.LanguageRegistry
import com.axiom.ide.core.util.LanguageSpec
import java.io.File
import java.nio.charset.Charset

data class EditorTab(
    val filePath: String,
    val fileName: String,
    val content: String,
    val savedContent: String,
    val language: LanguageSpec,
    val encodingName: String = "UTF-8",
    val isReadOnly: Boolean = false,
    val undoStack: List<String> = emptyList(),
    val redoStack: List<String> = emptyList()
) {
    val isDirty: Boolean get() = content != savedContent
}

class EditorWorkspaceController {
    private val _tabs = mutableListOf<EditorTab>()
    val tabs: List<EditorTab> get() = _tabs.toList()

    var activeIndex: Int = -1
        private set

    val activeTab: EditorTab? get() = _tabs.getOrNull(activeIndex)

    fun openFile(file: File, encodingName: String = "UTF-8"): EditorTab {
        val existingIdx = _tabs.indexOfFirst { it.filePath == file.absolutePath }
        if (existingIdx >= 0) {
            activeIndex = existingIdx
            return _tabs[existingIdx]
        }
        val charset = runCatching { Charset.forName(encodingName) }.getOrDefault(Charsets.UTF_8)
        val text = if (file.exists() && file.isFile) {
            runCatching { file.readText(charset) }.getOrElse { "// Unable to read file: ${it.message}" }
        } else ""
        val tab = EditorTab(
            filePath = file.absolutePath,
            fileName = file.name,
            content = text,
            savedContent = text,
            language = LanguageRegistry.detectForFileName(file.name),
            encodingName = charset.name()
        )
        _tabs.add(tab)
        activeIndex = _tabs.lastIndex
        return tab
    }

    fun selectTab(index: Int) {
        if (index in _tabs.indices) activeIndex = index
    }

    fun closeTab(index: Int) {
        if (index !in _tabs.indices) return
        _tabs.removeAt(index)
        activeIndex = when {
            _tabs.isEmpty() -> -1
            activeIndex >= _tabs.size -> _tabs.lastIndex
            else -> activeIndex
        }
    }

    fun updateActiveContent(newContent: String, autoCloseBrackets: Boolean = false, tabSize: Int = 4) {
        val tab = activeTab ?: return
        if (tab.isReadOnly || tab.content == newContent) return
        val processed = applySmartEdit(tab.content, newContent, autoCloseBrackets, tabSize)
        _tabs[activeIndex] = tab.copy(
            content = processed,
            undoStack = (tab.undoStack + tab.content).takeLast(60),
            redoStack = emptyList()
        )
    }

    private fun applySmartEdit(oldText: String, newText: String, autoClose: Boolean, tabSize: Int): String {
        // Apply lightweight Acode-style auto-indent when a single newline is appended at end of input
        if (newText.length == oldText.length + 1 && newText.endsWith("\n") && newText.startsWith(oldText)) {
            val prevLine = oldText.substringAfterLast('\n')
            val leadingSpaces = prevLine.takeWhile { it == ' ' || it == '\t' }
            val extra = if (prevLine.trimEnd().endsWith("{") || prevLine.trimEnd().endsWith(":")) " ".repeat(tabSize) else ""
            return newText + leadingSpaces + extra
        }
        // Auto-close brackets when a single opening bracket is typed at end
        if (autoClose && newText.length == oldText.length + 1 && newText.startsWith(oldText)) {
            val ch = newText.last()
            val closing = when (ch) {
                '{' -> '}'
                '(' -> ')'
                '[' -> ']'
                else -> null
            }
            if (closing != null) return newText + closing
        }
        return newText
    }

    fun appendText(snippet: String) {
        val tab = activeTab ?: return
        if (tab.isReadOnly) return
        updateActiveContent(tab.content + snippet)
    }

    fun setEncoding(encodingName: String) {
        val tab = activeTab ?: return
        _tabs[activeIndex] = tab.copy(encodingName = encodingName)
    }

    fun undo() {
        val tab = activeTab ?: return
        if (tab.undoStack.isEmpty()) return
        _tabs[activeIndex] = tab.copy(
            content = tab.undoStack.last(),
            undoStack = tab.undoStack.dropLast(1),
            redoStack = (tab.redoStack + tab.content).takeLast(60)
        )
    }

    fun redo() {
        val tab = activeTab ?: return
        if (tab.redoStack.isEmpty()) return
        _tabs[activeIndex] = tab.copy(
            content = tab.redoStack.last(),
            undoStack = (tab.undoStack + tab.content).takeLast(60),
            redoStack = tab.redoStack.dropLast(1)
        )
    }

    fun toggleReadOnly() {
        val tab = activeTab ?: return
        _tabs[activeIndex] = tab.copy(isReadOnly = !tab.isReadOnly)
    }

    fun toggleCommentAllOrFirstLine() {
        val tab = activeTab ?: return
        if (tab.isReadOnly) return
        val prefix = tab.language.lineComment
        val lines = tab.content.lines()
        val allCommented = lines.all { it.trimStart().startsWith(prefix) || it.isBlank() }
        val updated = lines.joinToString("\n") { line ->
            if (line.isBlank()) line
            else if (allCommented) line.replaceFirst("$prefix ", "").replaceFirst(prefix, "")
            else "$prefix $line"
        }
        updateActiveContent(updated)
    }

    fun formatActiveCode(tabSize: Int) {
        val tab = activeTab ?: return
        if (tab.isReadOnly) return
        val indentUnit = " ".repeat(tabSize)
        var depth = 0
        val formatted = tab.content.lines().joinToString("\n") { raw ->
            val trimmed = raw.trim()
            if (trimmed.startsWith("}") || trimmed.startsWith("]") || trimmed.startsWith(")")) {
                depth = (depth - 1).coerceAtLeast(0)
            }
            val line = if (trimmed.isEmpty()) "" else indentUnit.repeat(depth) + trimmed
            if (trimmed.endsWith("{") || trimmed.endsWith("[") || trimmed.endsWith("(")) {
                depth++
            }
            line
        }
        updateActiveContent(formatted)
    }

    fun countMatches(query: String, ignoreCase: Boolean): Int {
        val tab = activeTab ?: return 0
        if (query.isEmpty()) return 0
        val opts = if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()
        return Regex(Regex.escape(query), opts).findAll(tab.content).count()
    }

    fun findAndReplace(findQuery: String, replacement: String, ignoreCase: Boolean): Int {
        val tab = activeTab ?: return 0
        if (tab.isReadOnly || findQuery.isEmpty()) return 0
        val opts = if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()
        val regex = Regex(Regex.escape(findQuery), opts)
        val count = regex.findAll(tab.content).count()
        if (count > 0) {
            updateActiveContent(regex.replace(tab.content, Regex.escapeReplacement(replacement)))
        }
        return count
    }

    fun saveActiveTab(): Boolean {
        val tab = activeTab ?: return false
        return saveTabAt(activeIndex)
    }

    fun saveTabAt(index: Int): Boolean {
        val tab = _tabs.getOrNull(index) ?: return false
        return runCatching {
            val charset = runCatching { Charset.forName(tab.encodingName) }.getOrDefault(Charsets.UTF_8)
            File(tab.filePath).writeText(tab.content, charset)
            _tabs[index] = tab.copy(savedContent = tab.content)
            true
        }.getOrDefault(false)
    }

    fun saveAllTabs(): Int {
        var count = 0
        for (i in _tabs.indices) {
            if (_tabs[i].isDirty && saveTabAt(i)) count++
        }
        return count
    }
}
