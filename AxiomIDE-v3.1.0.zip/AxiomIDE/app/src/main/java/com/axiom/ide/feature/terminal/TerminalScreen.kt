package com.axiom.ide.feature.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiom.ide.core.data.IdeSettings
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun TerminalScreen(
    initialWorkingDir: String,
    settings: IdeSettings
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val termuxInstalled = remember { TerminalEngine.isTermuxInstalled(context) }

    val sessions = remember {
        mutableStateListOf(
            TerminalSession(
                id = UUID.randomUUID().toString(),
                title = "Shell 1",
                workingDir = initialWorkingDir
            )
        )
    }
    var activeIdx by remember { mutableIntStateOf(0) }
    var commandInput by remember { mutableStateOf("") }
    var searchFilter by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var isRunning by remember { mutableStateOf(false) }

    val activeSession = sessions.getOrElse(activeIdx) { sessions.first() }
    val visibleLines = remember(activeSession.lines, searchFilter) {
        if (searchFilter.isBlank()) activeSession.lines
        else activeSession.lines.filter { it.contains(searchFilter, ignoreCase = true) }
    }

    LaunchedEffect(visibleLines.size) {
        if (visibleLines.isNotEmpty()) {
            listState.animateScrollToItem(visibleLines.lastIndex)
        }
    }

    fun runCurrentCommand() {
        val cmd = commandInput.trim()
        if (cmd.isEmpty() || isRunning) return
        commandInput = ""
        isRunning = true
        val current = sessions[activeIdx]
        sessions[activeIdx] = current.copy(
            lines = current.lines + "$ $cmd",
            commandHistory = (current.commandHistory + cmd).takeLast(100)
        )
        scope.launch {
            val res = TerminalEngine.executeCommand(
                command = cmd,
                workingDir = current.workingDir,
                shellPath = settings.defaultShell,
                envVars = current.envVars
            )
            val updated = sessions[activeIdx]
            val appended = buildList {
                addAll(updated.lines)
                if (res.output.isNotBlank()) addAll(res.output.lines())
                add("[exit ${res.exitCode}]")
            }
            sessions[activeIdx] = updated.copy(workingDir = res.newWorkingDir, lines = appended)
            isRunning = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            sessions.forEachIndexed { idx, session ->
                Surface(
                    color = if (idx == activeIdx) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                    else MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.clickable { activeIdx = idx }
                ) {
                    Text(session.title, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
            }
            OutlinedButton(onClick = {
                sessions.add(
                    TerminalSession(
                        id = UUID.randomUUID().toString(),
                        title = "Shell ${sessions.size + 1}",
                        workingDir = activeSession.workingDir
                    )
                )
                activeIdx = sessions.lastIndex
            }) { Text("+") }

            OutlinedButton(onClick = { showSearch = !showSearch }) { Text("Find") }

            OutlinedButton(onClick = {
                sessions[activeIdx] = activeSession.copy(lines = listOf("Terminal cleared."))
            }) { Text("Clear") }

            if (termuxInstalled) {
                Button(onClick = { TerminalEngine.launchTermux(context) }) { Text("Termux") }
            }
        }

        Text(
            text = "CWD: ${activeSession.workingDir}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (showSearch) {
            OutlinedTextField(
                value = searchFilter,
                onValueChange = { searchFilter = it },
                label = { Text("Filter") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(visibleLines) { line ->
                Text(
                    text = line,
                    fontFamily = FontFamily.Monospace,
                    fontSize = settings.terminalFontSizeSp.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Input row stays pinned above keyboard via imePadding()
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                label = { Text("Command") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { runCurrentCommand() })
            )
            Button(enabled = !isRunning && commandInput.isNotBlank(), onClick = { runCurrentCommand() }) {
                Text(if (isRunning) "..." else "Run")
            }
        }
    }
}
