package com.axiom.ide.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.axiom.ide.AxiomApp
import com.axiom.ide.core.data.IdeSettings
import com.axiom.ide.core.data.SecureStorage
import com.axiom.ide.core.data.db.ProjectEntity
import com.axiom.ide.feature.ai.AiAssistantScreen
import com.axiom.ide.feature.editor.EditorScreen
import com.axiom.ide.feature.extensions.ExtensionsScreen
import com.axiom.ide.feature.github.GitHubScreen
import com.axiom.ide.feature.home.HomeScreen
import com.axiom.ide.feature.home.HubScreen
import com.axiom.ide.feature.onboarding.OnboardingScreen
import com.axiom.ide.feature.preview.WebPreviewScreen
import com.axiom.ide.feature.projects.FileExplorerScreen
import com.axiom.ide.feature.projects.ProjectsScreen
import com.axiom.ide.feature.runner.RunAndConsoleScreen
import com.axiom.ide.feature.settings.AboutPrivacyScreen
import com.axiom.ide.feature.settings.SettingsScreen
import com.axiom.ide.feature.terminal.TerminalScreen
import com.axiom.ide.feature.tools.DevToolsScreen
import kotlinx.coroutines.launch
import java.io.File

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val PROJECTS = "projects"
    const val EXPLORER = "explorer"
    const val EDITOR = "editor"
    const val TERMINAL = "terminal"
    const val HUB = "hub"
    const val GITHUB = "github"
    const val EXTENSIONS = "extensions"
    const val SETTINGS = "settings"
    const val PREVIEW = "preview"
    const val RUNNER = "runner"
    const val TOOLS = "tools"
    const val AI = "ai"
    const val ABOUT = "about"
}

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

private val primaryTabs = listOf(
    NavTab(Routes.HOME, "Home", Icons.Default.Home),
    NavTab(Routes.PROJECTS, "Projects", Icons.Default.Folder),
    NavTab(Routes.EDITOR, "Editor", Icons.Default.Code),
    NavTab(Routes.TERMINAL, "Shell", Icons.Default.Terminal),
    NavTab(Routes.HUB, "Hub", Icons.Default.Apps)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AxiomRoot(app: AxiomApp, settings: IdeSettings) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: Routes.HOME

    val projects by app.projectRepository.observeProjects().collectAsState(initial = emptyList())
    val recentFiles by app.projectRepository.observeRecentFiles().collectAsState(initial = emptyList())
    val extensions by app.database.extensionDao().observeAll().collectAsState(initial = emptyList())

    var activeProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var previewFile by remember { mutableStateOf<File?>(null) }
    var runTargetFile by remember { mutableStateOf<File?>(null) }
    var terminalDir by remember { mutableStateOf(app.projectRepository.projectsRoot.absolutePath) }
    var editorRevision by remember { mutableIntStateOf(0) }
    var storageBytes by remember { mutableLongStateOf(0L) }

    LaunchedEffect(projects.size) { storageBytes = app.projectRepository.calculateStorageBytes() }

    val startDest = if (settings.onboardingCompleted) Routes.HOME else Routes.ONBOARDING
    val primaryRoutes = remember { primaryTabs.map { it.route }.toSet() }
    val showChrome = currentRoute != Routes.ONBOARDING
    val isSecondaryScreen = showChrome && currentRoute !in primaryRoutes
    val isTablet = LocalConfiguration.current.screenWidthDp >= 600
    val isKeyboardVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    val topBarTitle = when (currentRoute) {
        Routes.HOME -> "Axiom IDE"
        Routes.PROJECTS -> "Projects"
        Routes.EXPLORER -> activeProject?.name ?: "File Explorer"
        Routes.EDITOR -> app.editorController.activeTab?.fileName ?: "Editor"
        Routes.TERMINAL -> "Terminal"
        Routes.HUB -> "Workspace Hub"
        Routes.GITHUB -> "GitHub"
        Routes.EXTENSIONS -> "Extensions"
        Routes.SETTINGS -> "Settings"
        Routes.PREVIEW -> "Web Preview"
        Routes.RUNNER -> "Run & Console"
        Routes.TOOLS -> "Dev Toolbox"
        Routes.AI -> "AI Assistant"
        Routes.ABOUT -> "About & Privacy"
        else -> "Axiom IDE"
    }

    val openFileInEditor: (File, String) -> Unit = { file, projectName ->
        app.editorController.openFile(file)
        editorRevision++
        scope.launch { app.projectRepository.recordRecentFile(file, projectName) }
        navController.navigate(Routes.EDITOR)
    }

    Scaffold(
        topBar = {
            if (showChrome && currentRoute != Routes.EDITOR) {
                TopAppBar(
                    title = { Text(topBarTitle) },
                    navigationIcon = {
                        if (isSecondaryScreen) {
                            IconButton(onClick = { navController.popBackStack() }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                    actions = {
                        if (currentRoute != Routes.SETTINGS) {
                            IconButton(onClick = { navController.navigate(Routes.SETTINGS) }) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings")
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (showChrome && !isTablet && !isKeyboardVisible) {
                NavigationBar {
                    primaryTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (showChrome && isTablet) {
                NavigationRail {
                    primaryTabs.forEach { tab ->
                        NavigationRailItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                NavHost(
                    navController = navController,
                    startDestination = startDest,
                    enterTransition = { fadeIn(animationSpec = tween(220)) },
                    exitTransition = { fadeOut(animationSpec = tween(180)) }
                ) {
                    composable(Routes.ONBOARDING) {
                        OnboardingScreen(
                            onStartCoding = {
                                scope.launch { app.settingsRepository.setOnboardingCompleted(true) }
                                navController.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                            }
                        )
                    }
                    composable(Routes.HOME) {
                        HomeScreen(
                            githubUsername = app.secureStorage.getSecret(SecureStorage.KEY_GITHUB_USERNAME),
                            projects = projects,
                            recentFiles = recentFiles,
                            installedExtensionsCount = extensions.size,
                            storageBytes = storageBytes,
                            onCreateProject = { navController.navigate(Routes.PROJECTS) },
                            onOpenProjects = { navController.navigate(Routes.PROJECTS) },
                            onOpenProject = { project ->
                                activeProject = project
                                scope.launch { app.projectRepository.touchProject(project) }
                                navController.navigate(Routes.EXPLORER)
                            },
                            onOpenRecentFile = { recent -> openFileInEditor(File(recent.filePath), recent.projectName) },
                            onOpenTerminal = { navController.navigate(Routes.TERMINAL) },
                            onOpenTools = { navController.navigate(Routes.TOOLS) }
                        )
                    }
                    composable(Routes.HUB) {
                        HubScreen(
                            githubUsername = app.secureStorage.getSecret(SecureStorage.KEY_GITHUB_USERNAME),
                            onOpenGitHub = { navController.navigate(Routes.GITHUB) },
                            onOpenTools = { navController.navigate(Routes.TOOLS) },
                            onOpenRunner = { navController.navigate(Routes.RUNNER) },
                            onOpenPreview = { navController.navigate(Routes.PREVIEW) },
                            onOpenAi = { navController.navigate(Routes.AI) },
                            onOpenExtensions = { navController.navigate(Routes.EXTENSIONS) },
                            onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                            onOpenAbout = { navController.navigate(Routes.ABOUT) }
                        )
                    }
                    composable(Routes.PROJECTS) {
                        ProjectsScreen(
                            projects = projects,
                            repository = app.projectRepository,
                            onOpenExplorer = { project ->
                                activeProject = project
                                scope.launch { app.projectRepository.touchProject(project) }
                                navController.navigate(Routes.EXPLORER)
                            }
                        )
                    }
                    composable(Routes.EXPLORER) {
                        FileExplorerScreen(
                            project = activeProject,
                            onOpenFile = openFileInEditor,
                            onOpenWebPreview = { file ->
                                previewFile = file
                                navController.navigate(Routes.PREVIEW)
                            },
                            onOpenTerminalAt = { dir ->
                                terminalDir = dir
                                navController.navigate(Routes.TERMINAL)
                            }
                        )
                    }
                    composable(Routes.EDITOR) {
                        EditorScreen(
                            controller = app.editorController,
                            activeProject = activeProject,
                            db = app.database,
                            settings = settings,
                            settingsRepo = app.settingsRepository,
                            editorRevision = editorRevision,
                            onMutated = { editorRevision++ },
                            onOpenFileFromSidebar = openFileInEditor,
                            onRunFile = { file ->
                                runTargetFile = file
                                navController.navigate(Routes.RUNNER)
                            },
                            onPreviewHtml = { file ->
                                previewFile = file
                                navController.navigate(Routes.PREVIEW)
                            },
                            onOpenTerminal = { navController.navigate(Routes.TERMINAL) },
                            onOpenProjects = { navController.navigate(Routes.PROJECTS) }
                        )
                    }
                    composable(Routes.TERMINAL) {
                        TerminalScreen(initialWorkingDir = terminalDir, settings = settings)
                    }
                    composable(Routes.GITHUB) {
                        GitHubScreen(secureStorage = app.secureStorage)
                    }
                    composable(Routes.EXTENSIONS) {
                        ExtensionsScreen(db = app.database)
                    }
                    composable(Routes.SETTINGS) {
                        SettingsScreen(
                            settings = settings,
                            settingsRepo = app.settingsRepository,
                            onOpenAbout = { navController.navigate(Routes.ABOUT) }
                        )
                    }
                    composable(Routes.PREVIEW) {
                        WebPreviewScreen(targetHtmlFile = previewFile)
                    }
                    composable(Routes.RUNNER) {
                        RunAndConsoleScreen(
                            targetFile = runTargetFile,
                            settings = settings,
                            settingsRepo = app.settingsRepository,
                            onOpenWebPreview = { file ->
                                previewFile = file
                                navController.navigate(Routes.PREVIEW)
                            }
                        )
                    }
                    composable(Routes.TOOLS) {
                        DevToolsScreen()
                    }
                    composable(Routes.AI) {
                        AiAssistantScreen(
                            settings = settings,
                            settingsRepo = app.settingsRepository,
                            secureStorage = app.secureStorage
                        )
                    }
                    composable(Routes.ABOUT) {
                        AboutPrivacyScreen()
                    }
                }
            }
        }
    }
}
