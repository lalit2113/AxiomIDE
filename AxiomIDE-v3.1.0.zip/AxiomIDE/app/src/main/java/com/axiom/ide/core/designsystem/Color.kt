package com.axiom.ide.core.designsystem

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0B0F17)
val DarkSurface = Color(0xFF131926)
val DarkSurfaceVariant = Color(0xFF1C2434)
val DarkOutline = Color(0xFF2B3548)
val DarkOnSurface = Color(0xFFE6EDF3)
val DarkOnSurfaceVariant = Color(0xFF8B98AD)

val OledBackground = Color(0xFF000000)
val OledSurface = Color(0xFF0A0D12)
val OledSurfaceVariant = Color(0xFF141923)

val LightBackground = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAEFF5)
val LightOutline = Color(0xFFD0D8E2)
val LightOnSurface = Color(0xFF171D26)
val LightOnSurfaceVariant = Color(0xFF566374)

enum class AccentPreset(val label: String, val primary: Color, val secondary: Color) {
    SKY("Axiom Sky", Color(0xFF38BDF8), Color(0xFF0284C7)),
    EMERALD("Terminal Green", Color(0xFF22C55E), Color(0xFF16A34A)),
    INDIGO("Studio Indigo", Color(0xFF818CF8), Color(0xFF4F46E5)),
    AMBER("Compiler Amber", Color(0xFFF59E0B), Color(0xFFD97706)),
    CORAL("Syntax Coral", Color(0xFFFB7185), Color(0xFFE11D48)),
    TEAL("Prism Teal", Color(0xFF2DD4BF), Color(0xFF0D9488));

    companion object {
        fun fromName(name: String): AccentPreset =
            entries.firstOrNull { it.name == name } ?: SKY
    }
}

enum class AppThemeMode(val label: String) {
    DARK("Dark"),
    LIGHT("Light"),
    OLED("OLED Black");

    companion object {
        fun fromName(name: String): AppThemeMode =
            entries.firstOrNull { it.name == name } ?: DARK
    }
}

object SyntaxColors {
    val keywordDark = Color(0xFFFF7B72)
    val stringDark = Color(0xFFA5D6FF)
    val commentDark = Color(0xFF7D899C)
    val numberDark = Color(0xFF79C0FF)
    val typeDark = Color(0xFFFFA657)
    val annotationDark = Color(0xFFD2A8FF)

    val keywordLight = Color(0xFFCF222E)
    val stringLight = Color(0xFF0A3069)
    val commentLight = Color(0xFF6E7781)
    val numberLight = Color(0xFF0550AE)
    val typeLight = Color(0xFF953800)
    val annotationLight = Color(0xFF8250DF)
}
