package com.axiom.ide.feature.onboarding

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class OnboardingPage(val title: String, val subtitle: String, val detail: String)

private val pages = listOf(
    OnboardingPage(
        title = "Welcome to Axiom IDE",
        subtitle = "Open-source, offline-first Android IDE",
        detail = "Edit projects across 40+ languages with slide-out file tree, command palette, extra coding keys, custom snippets, ZIP import/export, and Storage Access Framework."
    ),
    OnboardingPage(
        title = "Real Shell, Live Preview & Tools",
        subtitle = "Zero accounts, zero paywalls, zero clutter",
        detail = "Run Android shell commands, launch Termux, preview live HTML/CSS/JS with console logs, and use 19 built-in developer tools completely offline."
    )
)

@Composable
fun OnboardingScreen(onStartCoding: () -> Unit) {
    var pageIndex by remember { mutableIntStateOf(0) }
    val page = pages[pageIndex]

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Spacer(Modifier.height(28.dp))
            Text("${pageIndex + 1} / ${pages.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(page.title, style = MaterialTheme.typography.headlineMedium)
            Text(page.subtitle, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(page.detail, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(16.dp))
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (pageIndex > 0) {
                OutlinedButton(onClick = { pageIndex-- }, modifier = Modifier.weight(1f)) { Text("Back") }
            }
            if (pageIndex < pages.lastIndex) {
                Button(onClick = { pageIndex++ }, modifier = Modifier.weight(1f)) { Text("Next") }
            } else {
                Button(onClick = onStartCoding, modifier = Modifier.weight(1f)) { Text("Start Coding") }
            }
        }
    }
}
