package com.axiom.ide.feature.terminal

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class TerminalSession(
    val id: String,
    val title: String,
    val workingDir: String,
    val lines: List<String> = listOf(
        "Axiom Android Shell (/system/bin/sh)",
        "Sandboxed Android shell. Install Termux for full Linux toolchains (git, python, node, clang)."
    ),
    val commandHistory: List<String> = emptyList(),
    val envVars: Map<String, String> = mapOf("TERM" to "xterm-256color")
)

data class ShellExecutionResult(
    val output: String,
    val exitCode: Int,
    val newWorkingDir: String
)

object TerminalEngine {

    suspend fun executeCommand(
        command: String,
        workingDir: String,
        shellPath: String = "/system/bin/sh",
        envVars: Map<String, String> = emptyMap(),
        timeoutSeconds: Long = 20L
    ): ShellExecutionResult = withContext(Dispatchers.IO) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return@withContext ShellExecutionResult("", 0, workingDir)

        if (trimmed == "cd" || trimmed.startsWith("cd ")) {
            val arg = trimmed.removePrefix("cd").trim()
            val target = when {
                arg.isEmpty() -> File(workingDir)
                arg.startsWith("/") -> File(arg)
                else -> File(workingDir, arg).canonicalFile
            }
            return@withContext if (target.exists() && target.isDirectory) {
                ShellExecutionResult("Changed directory to ${target.absolutePath}", 0, target.absolutePath)
            } else {
                ShellExecutionResult("cd: no such directory: $arg", 1, workingDir)
            }
        }

        val dirFile = File(workingDir).let { if (it.exists() && it.isDirectory) it else File("/") }
        val resolvedShell = if (File(shellPath).canExecute()) shellPath else "/system/bin/sh"

        try {
            val pb = ProcessBuilder(resolvedShell, "-c", trimmed)
                .directory(dirFile)
                .redirectErrorStream(true)
            pb.environment().putAll(envVars)

            val process = pb.start()
            val outputBuilder = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val completed = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)

            var line = reader.readLine()
            var count = 0
            while (line != null && count < 600) {
                outputBuilder.appendLine(line)
                line = reader.readLine()
                count++
            }

            if (!completed) {
                process.destroyForcibly()
                outputBuilder.appendLine("[Timed out after ${timeoutSeconds}s]")
                return@withContext ShellExecutionResult(outputBuilder.toString().trimEnd(), 124, workingDir)
            }

            ShellExecutionResult(outputBuilder.toString().trimEnd(), process.exitValue(), workingDir)
        } catch (e: Exception) {
            ShellExecutionResult("Shell error: ${e.message ?: e.javaClass.simpleName}", 1, workingDir)
        }
    }

    fun isTermuxInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo("com.termux", PackageManager.GET_ACTIVITIES)
        true
    } catch (_: Exception) {
        false
    }

    fun launchTermux(context: Context): Boolean {
        val intent: Intent = context.packageManager.getLaunchIntentForPackage("com.termux") ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }
}
